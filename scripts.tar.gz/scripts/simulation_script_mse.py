import argparse
import collections
import json
import math
import os
import random
import logging

logging.basicConfig(level=logging.INFO)

import pandas as pd
import numpy as np

from sklearn import metrics


def argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Extract mutants info")
    parser.add_argument("-d", "--all_tools_data_file", action="store", help="Store a file with statistics data of all tools")
    parser.add_argument("-o", "--output_file_path", action="store", help="Output file path")
    parser.add_argument("-t", "--tool", action="store", help="Tool data on which to perform")
    parser.add_argument("-f", "--path_to_failing_tests_dir", action="store", help="Store directory path to failing tests groundtruth dir")
    parser.add_argument("-m", "--mutants_sampled_range", action="store", help="Output file path")

    return parser


class Mutant(object):

    def __init__(self):
        self.mutant_ID = ""
        self.killingTests = frozenset()

        self.mutant_embedded_id = ""
        self.ochiai = 0.0
        self.jaccard = ""
        self.cosine = ""
        self.bleu = ""
        self.reviling_prob = 0.0

    def __ne__(self, other):
        return (not isinstance(other, type(self))
                or self.mutant_ID != other.mutant_ID)

    def __eq__(self, othr):
        return (isinstance(othr, type(self))
                and self.mutant_ID == othr.mutant_ID)

    def __hash__(self):
        return hash((self.mutant_ID, self.killingTests))


def parse_mutants(mutant_df, bug_tests):
    mutants = []
    mutant_dict = mutant_df.to_dict(orient="index")
    for item in mutant_dict:
        m = Mutant()
        m.bleu = mutant_dict[item]["BLEU"]
        m.cosine = mutant_dict[item]["COSINE"]
        m.jaccard = mutant_dict[item]["JACCARD"]
        m.mutant_embedded_id = mutant_dict[item]["Mutant_ID"]
        m.mutant_ID = mutant_dict[item]["GLOBAL_ID"]
        f_tests = mutant_dict[item]["FAILING_TESTS"]
        if type(f_tests) is str:
            m.killingTests = frozenset(f_tests.split(","))
        else:
            m.killingTests = frozenset()

        m.ochiai = float(mutant_dict[item]["OCHIAI"])
        m.reviling_prob = fault_reviling_prob(set(bug_tests), set(m.killingTests))

        mutants.append(m)
    return mutants


def read_pit_mutants(path):
    pit_mutants = []
    file_counter = 0
    for file in os.listdir(path):
        if "killing_tests" in file and "changed_methods" not in file:
            path_to_mutants_killing_matrics = os.path.join(path, file)
            pit_mutants_killing_tests = pd.read_csv(filepath_or_buffer=path_to_mutants_killing_matrics, index_col=0).to_dict(orient='index')
            pit_mutants.extend(parse_mutants(pit_mutants_killing_tests, "PIT"))
            if file_counter >= 1:
                print()
            file_counter += 1
    return pit_mutants


def read_ibir_mutants(path):
    ibir_mutants_killing_tests = pd.read_csv(filepath_or_buffer=path, index_col='Mutant_ID').to_dict(orient='index')
    return parse_mutants(ibir_mutants_killing_tests, "IBIR")


def read_deep_mutation_mutants(path):
    deep_mutation_df = pd.read_csv(filepath_or_buffer=path, index_col='Mutant_Name')
    deep_mutation_df = deep_mutation_df[deep_mutation_df["Num_Failing_Tests"] != -1]  # -1 is a label saying that mutant does not compile
    deep_mutation_mutants_killing_tests = deep_mutation_df.to_dict(orient='index')
    return parse_mutants(deep_mutation_mutants_killing_tests, "DEEPMUTATION")


def read_codebert_mutants(path):
    codebert_mutation_df = pd.read_csv(filepath_or_buffer=path, index_col='Mutant_Name')
    codebert_mutation_df = codebert_mutation_df[codebert_mutation_df["Num_Failing_Tests"] != -1]  # -1 is a label saying that mutant does not compile
    codebert_mutation_mutants_killing_tests = codebert_mutation_df.to_dict(orient='index')
    return parse_mutants(codebert_mutation_mutants_killing_tests, "CODEBERT")


def get_ochia_score(brokenTestsByBug: set, brokenTestsByMutant: set):
    assert brokenTestsByBug != None and len(brokenTestsByBug) != 0
    if brokenTestsByMutant == None or len(brokenTestsByMutant) == 0: return 0;
    intersectionSet = brokenTestsByBug.intersection(brokenTestsByMutant)
    prod = len(brokenTestsByBug) * len(brokenTestsByMutant)
    if prod == 0 or len(intersectionSet) == 0: return 0
    return len(intersectionSet) / np.sqrt(prod)


def fault_reviling_prob(brokenTestsByBug: set, brokenTestsByMutant: set):
    assert brokenTestsByBug != None and len(brokenTestsByBug) != 0
    if brokenTestsByMutant == None or len(brokenTestsByMutant) == 0: return 0.0;
    intersectionSet = brokenTestsByBug.intersection(brokenTestsByMutant)
    prod = len(brokenTestsByMutant)
    if prod == 0 or len(intersectionSet) == 0: return 0.0
    return len(intersectionSet) / prod


def sample_all_killed_tests(mutants):
    set_of_tests = set()
    for mutant in mutants:
        for test in mutant.killingTests:
            set_of_tests.add(test)
    return set_of_tests


def load_failing_tests_for_bug(project_, bug_, path_to_failing_tests_dir):
    failing_tests_ground_truth = pd.read_csv(
        filepath_or_buffer=os.path.join(path_to_failing_tests_dir, f'{str(project_).lower()}_bugs_failing_tests.csv'),
        names=["BUG_ID", "FAILING_TESTS"], header=None)
    failing_tests_ = failing_tests_ground_truth.loc[failing_tests_ground_truth["BUG_ID"] == int(bug_[:-1]), 'FAILING_TESTS'].values[0].split(";")
    return list(map(lambda element: element.replace("::", "."), failing_tests_))


def aggregate_semantic(mutants, agg):
    values = []
    for mutant in mutants:
        values.append(mutant.ochiai)
    if agg == "average":
        return np.mean(values)
    elif agg == "max":
        return np.max(values)
    else:
        return np.median(values)


def aggregate_rev_prob(mutants, agg):
    values = []
    for mutant in mutants:
        values.append(mutant.reviling_prob)
    if agg == "average":
        return np.mean(values)
    elif agg == "max":
        return np.max(values)
    else:
        return np.median(values)


def sample_and_sort_mutants(mutants_pool, range_to_sample):
    sampled_mutants_dict_sem = []
    sampled_mutants_dict_rev_prob = []
    sampled_mutants_dict_rev_prob_max = []
    for i in range(1000):
        mutants = random.sample(mutants_pool, range_to_sample)
        # print([m.mutant_ID for m in mutants])
        # print([m.ochiai for m in mutants])
        sampled_mutants_dict_sem.append({"score": aggregate_semantic(mutants, "average"), "mutants": mutants})
        sampled_mutants_dict_rev_prob.append({"score": aggregate_rev_prob(mutants, "average"), "mutants": mutants})
        sampled_mutants_dict_rev_prob_max.append({"score": aggregate_rev_prob(mutants, "max"), "mutants": mutants})

    sampled_mutants_dict_sem.sort(key=lambda k: k['score'])
    sampled_mutants_dict_rev_prob.sort(key=lambda k: k['score'])
    sampled_mutants_dict_rev_prob_max.sort(key=lambda k: k['score'])
    # return dict(sorted(sampled_mutants_dict_sem.items(), reverse=True)), dict(sorted(sampled_mutants_dict_rev_prob.items(), reverse=True))
    return sampled_mutants_dict_sem, sampled_mutants_dict_rev_prob, sampled_mutants_dict_rev_prob_max


def split_mutants_into_backets(sampled_mutants_dict_sem_sim, sampled_mutants_dict_fault_rev_prob, sampled_mutants_dict_fault_rev_prob_max):
    sem_mutants_buckets = {}
    # sem_mutants_buckets.update({"Q1": [element["mutants"] for element in sampled_mutants_dict_sem_sim[:250]]})
    # sem_mutants_buckets.update({"Q2": [element["mutants"] for element in sampled_mutants_dict_sem_sim[250:500]]})
    # sem_mutants_buckets.update({"Q3": [element["mutants"] for element in sampled_mutants_dict_sem_sim[500:750]]})
    # sem_mutants_buckets.update({"Q4": [element["mutants"] for element in sampled_mutants_dict_sem_sim[750:1000]]})
    sem_mutants_buckets.update({"EXTREME": [element["mutants"] for element in sampled_mutants_dict_sem_sim[900:1000]]})
    sem_mutants_buckets.update({"EXTREME_5": [element["mutants"] for element in sampled_mutants_dict_sem_sim[950:1000]]})

    rev_prob_mutants_buckets = {}
    # rev_prob_mutants_buckets.update({"Q1": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob[:250]]})
    # rev_prob_mutants_buckets.update({"Q2": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob[250:500]]})
    # rev_prob_mutants_buckets.update({"Q3": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob[500:750]]})
    # rev_prob_mutants_buckets.update({"Q4": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob[750:1000]]})
    rev_prob_mutants_buckets.update({"EXTREME": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob[900:1000]]})
    rev_prob_mutants_buckets.update({"EXTREME_5": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob[950:1000]]})

    rev_prob_mutants_buckets_max = {}
    # rev_prob_mutants_buckets_max.update({"Q1": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob_max[:250]]})
    # rev_prob_mutants_buckets_max.update({"Q2": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob_max[250:500]]})
    # rev_prob_mutants_buckets_max.update({"Q3": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob_max[500:750]]})
    # rev_prob_mutants_buckets_max.update({"Q4": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob_max[750:1000]]})
    rev_prob_mutants_buckets_max.update({"EXTREME": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob_max[900:1000]]})
    rev_prob_mutants_buckets_max.update({"EXTREME_5": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob_max[950:1000]]})

    return sem_mutants_buckets, rev_prob_mutants_buckets, rev_prob_mutants_buckets_max


def mutation_score_with_tests(list_of_mutants, tests):
    survived = 0
    killed = 0
    for mutant in list_of_mutants:
        killing_tests = mutant.killingTests
        if len(killing_tests.intersection(tests)) > 0:
            killed += 1
        else:
            survived += 1
    if survived == 0 and killed == 0:
        return "No mutants"
    else:
        return round(killed / (survived + killed) * 100, 2)


def split_and_sample_tests(number_suites, number_tests_per_suite, all_tests_pool, failing_bug_tests):
    fault_detecting_suites, passing_suits = [], []
    failing_bug_tests = set(failing_bug_tests)
    # to_sample = number_tests_per_suite + len(failing_bug_tests)
    to_sample = number_tests_per_suite * 5  # number of tests to big for random sampling, lets reduce it to 10 times the size of sum of failing tests and number of tests per suite
    all_tests_no_failing = all_tests_pool - failing_bug_tests
    if to_sample >= len(all_tests_no_failing) * 0.5:
        to_sample = len(all_tests_no_failing)

    # lets loop until we sample wanted number of test sets
    while len(fault_detecting_suites) < number_suites:
        sample_less = random.sample(all_tests_no_failing, to_sample)
        sample_less = set.union(set(sample_less), failing_bug_tests)
        sampled_tests = random.sample(sample_less, number_tests_per_suite)
        if len(set(sampled_tests).intersection(failing_bug_tests)) > 0:
            fault_detecting_suites.append(sampled_tests)

    while len(passing_suits) < number_suites:
        sampled_tests = random.sample(all_tests_no_failing, number_tests_per_suite)
        if len(set(sampled_tests).intersection(failing_bug_tests)) == 0:
            passing_suits.append(sampled_tests)

    passing_suits = passing_suits[:number_suites]  # should I cut or randomly select? I think it is the same at the end
    fault_detecting_suites = fault_detecting_suites[:number_suites]  # should I cut or randomly select? I think it is the same at the end
    return fault_detecting_suites, passing_suits


def split_and_sample_tests_uniformly(number_suites, number_tests_per_suite, all_tests_pool, failing_bug_tests):
    fault_detecting_suites, passing_suits = [], []

    ratio_not_okay = True
    exit_counter = 0

    while ratio_not_okay:
        exit_counter += 1
        for i in range(number_suites):
            sampled_tests = random.sample(all_tests_pool, number_tests_per_suite)
            if len(set(sampled_tests).intersection(failing_bug_tests)) > 0:
                fault_detecting_suites.append(sampled_tests)
            else:
                passing_suits.append(sampled_tests)

        if len(fault_detecting_suites) > 30 and len(passing_suits) > 30:
            ratio_not_okay = False
        else:
            fault_detecting_suites.clear()
            passing_suits.clear()

        if exit_counter == 100:
            logging.info("ERROR infinite loop: Probability does not hold")
            exit(0)

    return fault_detecting_suites, passing_suits


def split_and_sample_tests_no_force_balance(number_suites, number_tests_per_suite, all_tests_pool, failing_bug_tests):
    fault_detecting_suites, passing_suits = [], []

    for i in range(number_suites):
        sampled_tests = random.sample(all_tests_pool, number_tests_per_suite)
        if len(set(sampled_tests).intersection(failing_bug_tests)) > 0:
            fault_detecting_suites.append(sampled_tests)
        else:
            passing_suits.append(sampled_tests)

    return fault_detecting_suites, passing_suits


def sample_tests_no_force_balance(number_suites, number_tests_per_suite, all_tests_pool):
    test_suites = []

    for i in range(number_suites):
        sampled_tests = random.sample(all_tests_pool, number_tests_per_suite)
        test_suites.append(sampled_tests)

    return test_suites


if __name__ == '__main__':
    arguments = argument_parser().parse_args()

    assert os.path.exists(arguments.all_tools_data_file), "Provide valid csv file with all tools statistics"
    assert os.path.exists(arguments.path_to_failing_tests_dir), "Provide valid directory path to failing tests ground truth dir"
    assert os.path.exists(arguments.output_file_path), "Provide valid directory path to output dir"

    all_tools_data_file_path, path_to_failing_tests_dir_ = arguments.all_tools_data_file, arguments.path_to_failing_tests_dir

    logging.info("Creating output file for mistakes")
    os.makedirs(os.path.join(arguments.output_file_path, "calculation_mistakes"), exist_ok=True)
    mistakes_writer_path = os.path.join(arguments.output_file_path, "calculation_mistakes",
                                        f"calculation_mistakes.csv")
    logging.info(f"Output file path: {mistakes_writer_path}")
    logging.info("Output file for mistakes")

    mistakes_writer = open(mistakes_writer_path, "a+")
    if os.stat(mistakes_writer_path).st_size == 0:
        mistakes_writer.write("Project_ID,Bug_ID,Mutant_ID,Mistakes,Hits,MSE,Ochiai,FDP\n")

    logging.info("Loading all tool data")
    data_df = pd.read_csv(filepath_or_buffer=all_tools_data_file_path)

    tools = data_df["Tool"].unique()
    logging.info("Data loaded")
    logging.info(f"All unique tools: {'|'.join(list(tools))}")
    # for tool_id, tool in enumerate(tools):
    # if tool not in ["pit", "codebert"]: continue
    tool_data = data_df[data_df["Tool"] == arguments.tool]
    # tool_data = data_df[data_df["Tool"] == "pit"]  # DEBUG
    projects = tool_data["Project_ID"].unique()
    # projects = ["Codec"]  # DEBUG

    bugs_one_test_or_more = collections.defaultdict(list)
    counter = 0

    # projects = random.sample(list(projects), 3)
    for project_id, project in enumerate(projects):
        project_data = tool_data[tool_data["Project_ID"] == project]
        bugs = project_data["Bug_ID"].unique()
        # bugs = ["12f"]  # DEBUG
        # if project == "Cli": continue
        # bugs = random.sample(list(bugs), 4)
        for bug_id, bug in enumerate(bugs):
            bug_data = project_data[project_data["Bug_ID"] == bug]
            counter += 1
            # LOAD FAILING TESTS FOR A BUG
            failing_tests = load_failing_tests_for_bug(project, bug, path_to_failing_tests_dir_)

            bug_mutants = parse_mutants(mutant_df=bug_data, bug_tests=failing_tests)
            test_pool = sample_all_killed_tests(bug_mutants)
            logging.info(f"INFO: Failing tests: {len(failing_tests)} - Test pool: {len(test_pool)} - Project: {project} - Bug: {bug}")

            if not set(failing_tests).issubset(test_pool):
                logging.info("Warning: Failing tests is not subset of test pool")
                continue
            if not len(set(failing_tests).intersection(test_pool)) > 0:
                logging.info("Warning: Fault intersection does not exist")
                continue

            logging.info(f"INFO: Failing tests: {len(failing_tests)} - Mutants: {len(bug_mutants)} - Test pool: {len(test_pool)}")

            if len(failing_tests) == 1:
                continue

            test_suites_dict = {}
            for number_of_suites in [1000]:  # lets sample 1000 mutants
                logging.info(f"Start test sampling<<<")
                den = len(failing_tests) / len(test_pool)
                number_of_tests_to_select = round(0.5 / den)

                test_suites = sample_tests_no_force_balance(number_of_suites, number_of_tests_to_select, test_pool)

            matrix = collections.defaultdict(dict)
            bug_hit_list = [1 if len(set(T).intersection(set(failing_tests))) > 0 else 0 for T in test_suites]
            for m in bug_mutants:
                matrix[m.mutant_ID].update({"Suites": [1 if len(set(T).intersection(set(m.killingTests))) > 0 else 0 for T in test_suites]})
                matrix[m.mutant_ID].update({"Ochiai": m.ochiai})
                matrix[m.mutant_ID].update({"FDP": m.reviling_prob})

            mistakes_scores = {}
            for mutant_name in matrix:
                mistakes = 0
                for test_suite_id, hit in enumerate(matrix[mutant_name]["Suites"]):
                    if hit != bug_hit_list[test_suite_id]:
                        mistakes += 1
                hits = 1000 - mistakes
                mse = metrics.mean_squared_error(bug_hit_list, matrix[mutant_name]["Suites"])
                mistakes_writer.write(
                    f"{project},{bug},{mutant_name},{mistakes},{hits},{mse},{matrix[mutant_name]['Ochiai']},{matrix[mutant_name]['FDP']}\n")
