import argparse
import csv
import os
import pandas as pd
import numpy as np

GLOBAL_COUNTER = 0


def argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Extract mutants info")
    parser.add_argument("-b", "--comparison_class_level_execution_file", action="store", help="Store a file with statistics data of scores")
    parser.add_argument("-p", "--path_to_data_dir", action="store", help="Store directory path to parsed mutants")
    parser.add_argument("-f", "--path_to_failing_tests_dir", action="store", help="Store directory path to failing tests groundtruth dir")
    parser.add_argument("-t", "--other_tools_similarity_files_path", action="store", help="Store directory path to other tools similarity files")

    return parser


class Mutant(object):

    def __init__(self, mutant_id):
        self.mutant_ID = mutant_id
        self.killingTests = frozenset()

        self.mutant_embedded_id = ""
        self.ochiai = ""
        self.jaccard = ""
        self.cosine = ""
        self.bleu = ""

    def __ne__(self, other):
        return (not isinstance(other, type(self))
                or self.mutant_ID != other.mutant_ID)

    def __eq__(self, othr):
        return (isinstance(othr, type(self))
                and self.mutant_ID == othr.mutant_ID)

    def __hash__(self):
        return hash((self.mutant_ID, self.killingTests))


def parse_mutants(mutants_with_killing_tests, tool, mutants_data_dict):
    global GLOBAL_COUNTER
    mutants_list = []
    for mutant_id in mutants_with_killing_tests:
        if tool == "PIT":
            mutantID = f'{GLOBAL_COUNTER}_PIT'
            TESTS_HEADER = "Killing_tests"
        elif tool == "IBIR":
            mutantID = f'{GLOBAL_COUNTER}_IBIR'
            TESTS_HEADER = "Killing_tests"
        elif tool == "DEEPMUTATION":
            mutantID = f'{GLOBAL_COUNTER}_DEEPMUTATION'
            TESTS_HEADER = "Failing_Tests"
        else:
            mutantID = f'{GLOBAL_COUNTER}_CODEBERT'
            TESTS_HEADER = "Failing_Tests"

        GLOBAL_COUNTER += 1
        mutant = Mutant(mutantID)
        killing_tests_string = mutants_with_killing_tests[mutant_id][TESTS_HEADER]

        mutant.mutant_embedded_id = mutant_id

        if mutant_id not in mutants_data_dict:
            print("Mutant does not exist in information about syntactic similarity")
            continue
        mutant.ochiai = mutants_data_dict[mutant_id]["OCHIAI"]
        mutant.jaccard = mutants_data_dict[mutant_id]["JACCARD"]
        mutant.cosine = mutants_data_dict[mutant_id]["COSINE"]
        mutant.bleu = mutants_data_dict[mutant_id]["BLEU"]

        killing_tests = []
        if killing_tests_string == 'None':
            killing_tests = []
        else:
            if "," in killing_tests_string:
                killing_tests = killing_tests_string.split(',')
            else:
                killing_tests.append(killing_tests_string)
            killing_tests = [test.split("(")[0] for test in killing_tests]
        mutant.killingTests = frozenset(killing_tests)
        mutants_list.append(mutant)
    return mutants_list


def read_pit_mutants(path, mutants_syntactic_data):
    pit_mutants = []
    file_counter = 0
    for file in os.listdir(path):
        if "killing_tests" in file and "changed_methods" not in file:
            path_to_mutants_killing_matrics = os.path.join(path, file)
            pit_mutants_killing_tests = pd.read_csv(filepath_or_buffer=path_to_mutants_killing_matrics, index_col=0).to_dict(orient='index')

            per_modified_class = mutants_syntactic_data[mutants_syntactic_data["Modified_Class"] == file[:-18]]  # remove _killing_tests.csv extension

            if len(per_modified_class) == 0:
                print("Class mutants info does not exist in file with syntactic info")
                continue

            mutants_data_dict_temp = per_modified_class.set_index("Mutant_ID").to_dict(orient="index")

            pit_mutants.extend(parse_mutants(pit_mutants_killing_tests, "PIT", mutants_data_dict_temp))
            if file_counter >= 1:
                print()
            file_counter += 1
    return pit_mutants


def read_ibir_mutants(path, mutants_syntactic_data):
    ibir_mutants_killing_tests = pd.read_csv(filepath_or_buffer=path, index_col='Mutant_ID').to_dict(orient='index')

    mutants_data_dict_temp = mutants_syntactic_data.set_index("Mutant_ID").to_dict(orient="index")
    mutants_data_dict = {int((k.split("_")[1]).split(".")[0]): v for k, v in mutants_data_dict_temp.items()}

    return parse_mutants(ibir_mutants_killing_tests, "IBIR", mutants_data_dict)


def read_deep_mutation_mutants(path, mutants_syntactic_data):
    deep_mutation_df = pd.read_csv(filepath_or_buffer=path, index_col='Mutant_Name')
    deep_mutation_df = deep_mutation_df[deep_mutation_df["Num_Failing_Tests"] != -1]  # -1 is a label saying that mutant does not compile
    deep_mutation_mutants_killing_tests = deep_mutation_df.to_dict(orient='index')

    mutants_data_dict_temp = mutants_syntactic_data.set_index("Mutant_ID").to_dict(orient="index")

    return parse_mutants(deep_mutation_mutants_killing_tests, "DEEPMUTATION", mutants_data_dict_temp)


def read_codebert_mutants(path, mutants_syntactic_data):
    codebert_mutation_df = pd.read_csv(filepath_or_buffer=path, index_col='Mutant_Name')
    codebert_mutation_df = codebert_mutation_df[codebert_mutation_df["Num_Failing_Tests"] != -1]  # -1 is a label saying that mutant does not compile
    codebert_mutation_mutants_killing_tests = codebert_mutation_df.to_dict(orient='index')

    mutants_data_dict_temp = mutants_syntactic_data.set_index("Mutant_ID").to_dict(orient="index")

    return parse_mutants(codebert_mutation_mutants_killing_tests, "CODEBERT", mutants_data_dict_temp)


def load_failing_tests_for_bug(project_, bug_, path_to_failing_tests_dir):
    failing_tests_ground_truth = pd.read_csv(
        filepath_or_buffer=os.path.join(path_to_failing_tests_dir, f'{str(project_).lower()}_bugs_failing_tests.csv'),
        names=["BUG_ID", "FAILING_TESTS"], header=None)
    failing_tests_ = failing_tests_ground_truth.loc[failing_tests_ground_truth["BUG_ID"] == int(bug_[:-1]), 'FAILING_TESTS'].values[0].split(";")
    return list(map(lambda element: element.replace("::", "."), failing_tests_))


def get_ochia_score(brokenTestsByBug: set, brokenTestsByMutant: set):
    assert brokenTestsByBug != None and len(brokenTestsByBug) != 0
    if brokenTestsByMutant == None or len(brokenTestsByMutant) == 0: return 0;
    intersectionSet = brokenTestsByBug.intersection(brokenTestsByMutant)
    prod = len(brokenTestsByBug) * len(brokenTestsByMutant)
    if prod == 0 or len(intersectionSet) == 0: return 0
    return len(intersectionSet) / np.sqrt(prod)


if __name__ == '__main__':
    arguments = argument_parser().parse_args()

    assert os.path.exists(arguments.comparison_class_level_execution_file), "Provide valid csv file with statistics data of scores, with columns: Project_ID," \
                                                                            "Bug_ID,Modified_Class,Mutant_ID,Mutant_Not_Killed,OCHIAI,JACCARD,COSINE,BLEU," \
                                                                            "MODIFIED_CLASSES "
    assert os.path.exists(arguments.path_to_data_dir), "Provide valid directory path to parsed mutants"
    assert os.path.exists(arguments.path_to_failing_tests_dir), "Provide valid directory path to failing tests ground truth dir"
    assert os.path.exists(arguments.other_tools_similarity_files_path), "Provide valid directory path to failing tests ground truth dir"

    path_to_data_dir_, path_to_failing_tests_dir_ = arguments.path_to_data_dir, arguments.path_to_failing_tests_dir

    tools_information_path = os.path.join(".", "all_tools_data.csv")
    tools_information = open(tools_information_path, "a+")
    if os.stat(tools_information_path).st_size == 0:
        tools_information.write(
            "Project_ID,Bug_ID,Tool,Mutant_ID,GLOBAL_ID,OCHIAI,JACCARD,COSINE,BLEU,FAILING_TESTS\n")

    # lets perform only for existing bugs, now we don't need intersection of bugs
    # for mutants_path, tool_info in [("parsed_pit_mutants", "pit"), ("ibir_mutants_info", "ibir"), ("deep-mutation_mutants_info", "deepmutation"),
    #                                 ("codebert_mutants_info", "codebert")]:
    for mutants_path, tool_info in [("parsed_pit_mutants", "pit")]:
        # for each tool and bug, load overall similarity file, and for each mutant of a tool, load syntactic scores

        if "pit" not in mutants_path:
            data_overall_similarity_df = pd.read_csv(
                filepath_or_buffer=os.path.join(arguments.other_tools_similarity_files_path, tool_info, "overallsimilarity.txt"))
        else:
            data_overall_similarity_df = pd.read_csv(filepath_or_buffer=arguments.comparison_class_level_execution_file)

        counter = 1
        print("Tool: ", tool_info)

        unique_projects = data_overall_similarity_df["Project_ID"].unique()
        for project in unique_projects:
            project_data = data_overall_similarity_df[data_overall_similarity_df["Project_ID"] == project]
            project_bugs = project_data["Bug_ID"].unique()
            print("Project: ", project)
            for bug in project_bugs:
                print("\tBug: ", bug, " - Exists", counter)
                bug_data = project_data[project_data["Bug_ID"] == bug]

                # check if exists for bug
                if tool_info == "pit":
                    bug_path = os.path.join(path_to_data_dir_, mutants_path, f'{project}_{bug[:-1]}')
                    if not os.path.isdir(bug_path):
                        continue
                else:
                    bug_path = os.path.join(path_to_data_dir_, mutants_path, f'{project}_{bug[:-1]}.csv')
                    if not os.path.exists(bug_path):
                        continue

                # LOAD FAILING TESTS FOR A BUG
                failing_tests = load_failing_tests_for_bug(project, bug, path_to_failing_tests_dir_)

                counter += 1
                # parse mutants
                mutants = []
                if "pit" in mutants_path:
                    mutants = read_pit_mutants(bug_path, bug_data)
                elif "ibir" in mutants_path:
                    mutants = read_ibir_mutants(bug_path, bug_data)
                elif "deep" in mutants_path:
                    mutants = read_deep_mutation_mutants(bug_path, bug_data)
                elif "codebert" in mutants_path:
                    mutants = read_codebert_mutants(bug_path, bug_data)

                if len(mutants) == 0:
                    print("No mutants compile")

                for mutant in mutants:
                    mutant.ochiai = get_ochia_score(set(failing_tests), set(mutant.killingTests))
                    tools_information.write(
                        '{Project_ID},{Bug_ID},{Tool},{Mutant_ID},{GLOBAL_ID},{OCHIAI},{JACCARD},{COSINE},{BLEU},"{FAILING_TESTS}"\n'.format(Project_ID=project,
                                                                                                                                             Bug_ID=bug,
                                                                                                                                             Tool=tool_info,
                                                                                                                                             Mutant_ID=mutant.mutant_embedded_id,
                                                                                                                                             GLOBAL_ID=mutant.mutant_ID,
                                                                                                                                             OCHIAI=mutant.ochiai,
                                                                                                                                             JACCARD=mutant.jaccard,
                                                                                                                                             COSINE=mutant.cosine,
                                                                                                                                             BLEU=mutant.bleu,
                                                                                                                                             FAILING_TESTS=",".join(
                                                                                                                                                 mutant.killingTests)))