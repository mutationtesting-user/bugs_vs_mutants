import argparse
import collections
import json
import logging
import os

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.stats as stats
import seaborn as sns

from statistical_analysis import a12, wilcoxon

from statistics import variance, stdev, mean, median, harmonic_mean

logging.basicConfig(level=logging.INFO)


from sklearn import metrics


"""
    Plot simulation data per bucket, group by test selection
"""
def plot_simulation_groups_by_buckets():
    data_df = pd.read_csv(filepath_or_buffer=arguments.path_to_data_file)

    tools = data_df["Tool"].unique()

    data_df.Test_Category = data_df.Test_Category.replace({"failing": "Failing Tests", "passing": "Passing Tests"})
    data_df.Bucket = data_df.Bucket.replace({"first": "Q1", "second": "Q2", "third": "Q3", "fourth": "Q4"})
    my_pal = {'Failing Tests': 'palegreen', 'Passing Tests': 'cornflowerblue'}

    for tool in tools:
        tool_data = data_df[data_df["Tool"] == tool]

        sampled_ranges = tool_data["Sampled_Range"].unique()

        for sampled_range in sampled_ranges:
            if sampled_range not in [20, 30, 50]: continue
            sampled_range_data = tool_data[tool_data["Sampled_Range"] == sampled_range]

            buckets = sampled_range_data["Bucket"].unique()
            for bucket in buckets:
                bucket_data = sampled_range_data[sampled_range_data["Bucket"] == bucket]

                fig = plt.figure(figsize=(15, 8))
                axes = sns.boxplot(x="Number_Of_Tests", y="MS", hue="Test_Category", data=bucket_data, palette=my_pal)

                axes.set_alpha(0.5)
                axes.set_ylabel("Mutation Score (%)", fontsize=22)
                axes.set_xlabel("Number of selected tests", fontsize=22)
                axes.tick_params(labelsize=22)
                axes.set_title(label=f'Quartile: {bucket} - Sampled mutants: {sampled_range}'.format(bucket=bucket, sampled_range=sampled_range), fontsize=22)
                axes.legend(loc="upper left", fontsize=26)
                # plt.tight_layout()
                # os.makedirs("plots", exist_ok=True)
                # plt.savefig(os.path.join("plots", f"{arguments.tool_name}_BoxPlot_simulation_Quartile_{bucket}_MutantsSelection_{sampled_range}.png"),
                #             format="png")
                # plt.savefig(os.path.join("plots", f"{arguments.tool_name}_BoxPlot_simulation_Quartile_{bucket}_MutantsSelection_{sampled_range}.pdf"),
                #             format="pdf")
                # plt.close()


def plot_simulation_by_testcategory():
    print()
    data_df = pd.read_csv(filepath_or_buffer=arguments.path_to_data_file)

    tools = data_df["Tool"].unique()

    data_df.Test_Category = data_df.Test_Category.replace({"failing": "Failing Tests", "passing": "Passing Tests"})
    data_df.Bucket = data_df.Bucket.replace({"first": "Q1", "second": "Q2",
                                             "third": "Q3", "fourth": "Q4"})
    # my_pal = {'Failing Tests': 'palegreen', 'Passing Tests': 'cornflowerblue'}

    for tool in tools:
        tool_data = data_df[data_df["Tool"] == tool]

        sampled_ranges = tool_data["Sampled_Range"].unique()

        for sampled_range in sampled_ranges:
            if sampled_range not in [20, 30, 50]: continue
            sampled_range_data = tool_data[tool_data["Sampled_Range"] == sampled_range]

            test_categories = sampled_range_data["Test_Category"].unique()
            for test_category in test_categories:
                test_category_data = sampled_range_data[sampled_range_data["Test_Category"] == test_category]

                fig = plt.figure(figsize=(15, 8))
                axes = sns.boxplot(x="Number_Of_Tests", y="MS", hue="Bucket", data=test_category_data)

                axes.set_alpha(0.5)
                axes.set_ylabel("Mutation Score (%)", fontsize=22)
                axes.set_xlabel("Number of selected tests", fontsize=22)
                axes.tick_params(labelsize=22)
                axes.set_title(label=f'Test category: {test_category} - Sampled mutants: {sampled_range}', fontsize=22)
                axes.legend(loc="upper left", fontsize=26)
                plt.tight_layout()
                # os.makedirs("plots", exist_ok=True)
                # plt.savefig(os.path.join("plots", f"{arguments.tool_name}_BoxPlot_simulation_Test_Category_{test_category}_MutantsSelection_{sampled_range}.png"),
                #             format="png")
                # plt.savefig(os.path.join("plots", f"{arguments.tool_name}_BoxPlot_simulation_Test_Category_{test_category}_MutantsSelection_{sampled_range}.pdf"),
                #             format="pdf")
                # plt.close()


"""
   Out of grid results - calculate sweet point suggested by biggest median difference 
"""
def calculate_best_simulation_performance():
    global best_df
    data_df = pd.read_csv(filepath_or_buffer=arguments.path_to_data_file)

    tools = data_df["Tool"].unique()
    data_df.Test_Category = data_df.Test_Category.replace({"failing": "Failing Tests", "passing": "Passing Tests"})
    my_pal = {'Failing Tests': 'palegreen', 'Passing Tests': 'cornflowerblue'}

    best_project = ""
    best_bucket = ""
    best_test_selection = 0
    best_mutant_range = 0
    best_bug = ""
    best_mean_diff = 0
    best_median_diff = 0

    for tool in tools:
        tool_data = data_df[data_df["Tool"] == tool]

        projects = tool_data["Project_ID"].unique()

        for project_id, project in enumerate(projects):
            project_data = tool_data[tool_data["Project_ID"] == project]
            bugs = project_data["Bug_ID"].unique()

            for bug_id, bug in enumerate(bugs):
                bug_data = project_data[project_data["Bug_ID"] == bug]

                sampled_ranges = bug_data["Sampled_Range"].unique()

                for sampled_range in sampled_ranges:
                    if sampled_range not in [20, 30, 50]: continue
                    sampled_range_data = bug_data[bug_data["Sampled_Range"] == sampled_range]

                    selected_tests = sampled_range_data["Number_Of_Tests"].unique()
                    for test in selected_tests:
                        test_data = sampled_range_data[sampled_range_data["Number_Of_Tests"] == test]

                        # buckets = test_data["Bucket"].unique()
                        # for bucket in buckets:
                        #     bucket_data = test_data[test_data["Bucket"] == bucket]

                        test_data_mean_dict = test_data.groupby('Test_Category')["MS"].mean().to_dict()
                        test_data_median_dict = test_data.groupby('Test_Category')["MS"].median().to_dict()

                        mean_diff = test_data_mean_dict["Failing Tests"] - test_data_mean_dict["Passing Tests"]
                        median_diff = test_data_median_dict["Failing Tests"] - test_data_median_dict["Passing Tests"]
                        print(f''
                              f'Project: {project} - Bug: {bug} - '
                              f'Test sel: {test} - Sampled m: {sampled_range}'
                              # f' | Bucket: {bucket} |'
                              f'F mean: {test_data_mean_dict["Failing Tests"]} - P mean: {test_data_mean_dict["Passing Tests"]} (diff: {mean_diff})| '
                              f'F median: {test_data_median_dict["Failing Tests"]} - P median: {test_data_median_dict["Passing Tests"]} (diff: {median_diff})')

                        if mean_diff > best_mean_diff:
                            best_mean_diff = test_data_mean_dict["Failing Tests"] - test_data_mean_dict["Passing Tests"]

                        if median_diff > best_median_diff:
                            best_median_diff = test_data_median_dict["Failing Tests"] - test_data_median_dict["Passing Tests"]
                            best_project = project
                            # best_bucket = bucket
                            best_bug = bug
                            best_test_selection = test
                            best_mutant_range = sampled_range
                            best_df = test_data.copy()

        fig = plt.figure(figsize=(15, 8))
        axes = sns.boxplot(x="Bucket", y="MS", hue="Test_Category", data=best_df, palette=my_pal)

        axes.set_alpha(0.5)
        axes.set_ylabel("Mutation Score (%)", fontsize=22)
        axes.set_xlabel("Number of selected tests", fontsize=22)
        axes.tick_params(labelsize=22)
        axes.set_title(label=f'Test selected: {best_test_selection} - Sampled mutants: {best_mutant_range}', fontsize=22)
        axes.legend(loc="upper left", fontsize=26)
        plt.tight_layout()
        os.makedirs("plots", exist_ok=True)
        plt.savefig(os.path.join("plots", f"{arguments.tool_name}_BoxPlot_simulation_Best_bug_results_{best_project}_{best_bug}.png"),
                    format="png")
        plt.savefig(os.path.join("plots", f"{arguments.tool_name}_BoxPlot_simulation_Best_bug_results_{best_project}_{best_bug}.pdf"),
                    format="pdf")
        print(f"Best median diff: {best_median_diff} | Best mean diff: {best_mean_diff}")
        print(
            f"Best project: {best_project} | Best bucket: {best_bucket} | Best bug: {best_bug} | Best selection: {best_test_selection} | Best m range: {best_mutant_range}")
        plt.show()
        plt.close()


"""
    Plot simulation data splitted on bugs that are reviled by one test and many tests
"""
def plot_simulation_split_on_bugs_with_one_or_more_tests_merge_version():
    print()
    # [UPDATE] load data about bugs reviled by == 1 or > 1 failing tests
    data_bug_reviling_tests = json.load(open(arguments.bugs_id_split_file))
    bugs_one_test_project_bug = [f'{element["Project"]}{element["Bug"]}' for element in data_bug_reviling_tests["One_test_failing"]]
    bugs_more_tests_project_bug = [f'{element["Project"]}{element["Bug"]}' for element in data_bug_reviling_tests["More_tests_failing"]]

    for mutant_selection in [arguments.mutants_pool]:
        for test_selection in [2, 4, 10, 14]:
            # load simulation data
            logging.info(f"Calculation Starts: M_selection_{mutant_selection} | Test_selection_{test_selection}")

            path_2_file = os.path.join(arguments.path_to_data_file, f"simulation_data_extension_{mutant_selection}_tests_{test_selection}.csv")
            # path_2_file = arguments.path_to_data_file
            logging.info(f"Path: {path_2_file}")
            data_df = pd.read_csv(filepath_or_buffer=path_2_file)

            tools = data_df["Tool"].unique()

            data_df.Test_Category = data_df.Test_Category.replace({"failing": "Failing Tests", "passing": "Passing Tests"})
            # data_df.Bucket = data_df.Bucket.replace({"first": "Q1", "second": "Q2", "third": "Q3", "fourth": "Q4"})
            my_pal = {'Failing Tests': 'palegreen', 'Passing Tests': 'cornflowerblue'}

            # PROPS = {
            #     'boxprops': {'facecolor': 'none', 'edgecolor': 'red'},
            #     'medianprops': {'color': 'green'},
            #     'whiskerprops': {'color': 'blue'},
            #     'capprops': {'color': 'yellow'}
            # }
            #
            # sns.boxplot(x='variable', y='value', data=_to_plot, showfliers=False, linewidth=0.75, **PROPS)

            # for tool in tools:
            #     tool_data = data_df[data_df["Tool"] == tool]
            # sampled_ranges = tool_data["Sampled_Range"].unique()
            #
            # for sampled_range in sampled_ranges:
            #     sampled_range_data = tool_data[tool_data["Sampled_Range"] == sampled_range]
            #
            #     selected_tests = sampled_range_data["Number_Of_Tests"].unique()
            #     for test in selected_tests:
            #         test_data = sampled_range_data[sampled_range_data["Number_Of_Tests"] == test]

            groups = data_df["Group"].unique()
            for group in groups:
                group_data = data_df[data_df["Group"] == group]

                logging.info(f"Merge starts")
                # create a list of bugs such as that we can split data frame
                # fn = lambda row: f"{row.Project_ID}_{row.Bug_ID}"  # define a function for the new column
                # col = group_data.apply(fn, axis=1)  # get column data with an index
                # group_data = group_data.assign(mergeProjectBug=col.values)  # assign values to column 'c'
                # group_data['mergeProjectBug'] = group_data[['Project_ID', 'Bug_ID']].agg('_'.join, axis=1)
                group_data['mergeProjectBug'] = group_data['Project_ID'] + group_data['Bug_ID']
                # [UPDATE] split data on bugs reviled by == 1 or > 1 failing tests
                logging.info(f"Merge done: {len(group_data)}")

                for category_name, filter_list in [("One", bugs_one_test_project_bug), ("More", bugs_more_tests_project_bug)]:
                    category_data = group_data.loc[group_data['mergeProjectBug'].isin(filter_list)]
                    logging.info(f"For category: {category_name} - Size: {len(category_data)}")

                    fig = plt.figure(figsize=(15, 8))
                    axes = sns.boxplot(x="Bucket", y="MS", hue="Test_Category", data=category_data, palette=my_pal)

                    axes.set_alpha(0.5)
                    axes.set_ylabel("Mutation Score (%)", fontsize=22)
                    axes.set_xlabel("Buckets", fontsize=22, labelpad=10)
                    axes.tick_params(labelsize=22)
                    # axes.set_title(label=f'Test selection: {test} - Sampled mutants: {sampled_range} - Group: {group}'.format(test=test, sampled_range=sampled_range, group=group), fontsize=22)
                    axes.legend(loc="upper left", fontsize=26)

                    plt.tight_layout()
                    os.makedirs(arguments.output_dir, exist_ok=True)
                    plt.savefig(os.path.join(arguments.output_dir,
                                             f"Categorized_{category_name}_{arguments.tool_name}_BoxPlot_simulation_TestSelection_{test_selection}_MutantsSelection_{mutant_selection}_{group}.png"),
                                format="png")
                    # plt.savefig(os.path.join("plots_new",
                    #                          f"{arguments.tool_name}_BoxPlot_simulation_TestSelection_{test}_MutantsSelection_{sampled_range}_{group}.pdf"),
                    #             format="pdf")
                    # plt.show()
                    plt.close()
                # data_q4 = test_data[test_data["Bucket"] == "Q4"]
                #
                # f_tests = data_q4[data_q4["Test_Category"] == "Failing Tests"]["MS"].tolist()
                # p_tests = data_q4[data_q4["Test_Category"] == "Passing Tests"]["MS"].tolist()
                #
                # indexes = random.sample(list(range(1, len(f_tests))), 10000)
                # failing_tests = [f_tests[index] for index in indexes]
                # passing_tests = [p_tests[index] for index in indexes]
                #
                # print(len(failing_tests))
                # print(len(passing_tests))
                #
                # print(
                #     f"BoxPlot_simulation_TestSelection_{test}_MutantsSelection_{sampled_range} - A12: {a12(failing_tests, passing_tests, pairwise=False, rev=True)} -"
                #     f"p-value: {wilcoxon(failing_tests, passing_tests, isranksum=True).pvalue}")


"""
    Plot simulation data splitted on bugs that are reviled by one test and many tests - data has a column of failing tests
"""
def plot_simulation_split_on_bugs_with_one_or_more_tests():
    print()

    for mutant_selection in [arguments.mutants_pool]:
        for test_selection in [5, 10, 20, 30]:
            # load simulation data
            logging.info(f"Calculation Starts: M_selection_{mutant_selection} | Test_selection_{test_selection}")

            path_2_file = os.path.join(arguments.path_to_data_file, f"simulation_data_extension_{mutant_selection}_tests_{test_selection}.csv")
            # path_2_file = arguments.path_to_data_file
            logging.info(f"Path: {path_2_file}")
            data_df = pd.read_csv(filepath_or_buffer=path_2_file)

            data_df.Test_Category = data_df.Test_Category.replace({"failing": "Failing Tests", "passing": "Passing Tests"})
            # data_df.Bucket = data_df.Bucket.replace({"first": "Q1", "second": "Q2", "third": "Q3", "fourth": "Q4"})
            my_pal = {'Failing Tests': 'palegreen', 'Passing Tests': 'cornflowerblue'}

            groups = data_df["Group"].unique()
            for group in groups:
                group_data = data_df[data_df["Group"] == group]

                for category in ["One", "More"]:
                    category_data = group_data[group_data["Number_Of_Failing_Tests"] == 1] if category == "One" else group_data[
                        group_data["Number_Of_Failing_Tests"] > 1]

                    fig = plt.figure(figsize=(15, 8))
                    axes = sns.boxplot(x="Bucket", y="MS", hue="Test_Category", data=category_data, palette=my_pal)

                    axes.set_alpha(0.5)
                    axes.set_ylabel("Mutation Score (%)", fontsize=22)
                    axes.set_xlabel("Buckets", fontsize=22, labelpad=10)
                    axes.tick_params(labelsize=22)
                    axes.set_title(label=f'Test selection: {test_selection} - Sampled mutants: {mutant_selection} - Group: {group} - Category: {category}',
                                   fontsize=22)
                    axes.legend(loc="upper left", fontsize=26)

                    plt.tight_layout()
                    os.makedirs(arguments.output_dir, exist_ok=True)
                    plt.savefig(os.path.join(arguments.output_dir,
                                             f"{category}_BoxPlot_simulation_TestSelection_{test_selection}_MutantsSelection_{mutant_selection}_{group}.png"),
                                format="png")
                    # plt.savefig(os.path.join("plots_new",
                    #                          f"{arguments.tool_name}_BoxPlot_simulation_TestSelection_{test}_MutantsSelection_{sampled_range}_{group}.pdf"),
                    #             format="pdf")
                    plt.show()
                    plt.close()


"""
    Calculate A12 and other metrics for each instance of a grid (mutant, test selection)
    Calculate:
            - for each group 
            - for each bug for Q4 and EXTREME quartile calculate A12 and other metrics
"""
def calculate_statistics_for_each_bug_per_group():
    print()

    # load each instance of grid data from simulation_script_extension.py - each file is split into one value of mutant pool and value of tests sampled
    for mutant_selection in [arguments.mutants_pool]:
        for test_selection in [5]:
            logging.info(f"Calculation Starts: M_selection_{mutant_selection} | Test_selection_{test_selection}")

            path_2_file = os.path.join(arguments.path_to_data_file, f"simulation_data_extension_{mutant_selection}_tests_{test_selection}.csv")
            logging.info(f"Path: {path_2_file}")
            data_df = pd.read_csv(filepath_or_buffer=path_2_file)

            groups = data_df["Group"].unique()
            group_output_dict = dict()
            for group in groups:  # split data by groups
                group_data = data_df[data_df["Group"] == group]

                project_output_dict = collections.defaultdict(list)  # calculate scores for each bug and
                projects = group_data["Project_ID"].unique()
                for project in projects:
                    project_data = group_data[group_data["Project_ID"] == project]

                    bugs = project_data["Bug_ID"].unique()
                    for bug in bugs:
                        bug_data = project_data[project_data["Bug_ID"] == bug]

                        for quartile in ["Q4", "EXTREME"]:  # calculate for 2 quartiles
                            data_q4 = bug_data[bug_data["Bucket"] == quartile]

                            f_tests_ms = data_q4[data_q4["Test_Category"] == "failing"]["MS"].tolist()
                            p_tests_ms = data_q4[data_q4["Test_Category"] == "passing"]["MS"].tolist()

                            print(len(f_tests_ms))
                            print(len(p_tests_ms))
                            # indexes = random.sample(list(range(1, len(f_tests))), 10000)
                            # failing_tests = [f_tests[index] for index in indexes]
                            # passing_tests = [p_tests[index] for index in indexes]

                            _A12 = a12(f_tests_ms, p_tests_ms, pairwise=False, rev=True)
                            p_value = wilcoxon(f_tests_ms, p_tests_ms, isranksum=True).pvalue
                            pearson_corr, pearson_p = stats.pearsonr(f_tests_ms, p_tests_ms)
                            kendall_corr, kendall_p = stats.kendalltau(f_tests_ms, p_tests_ms)

                            project_output_dict[f"A12_{quartile}"].append(_A12)
                            project_output_dict[f"A12_p_{quartile}"].append(p_value)
                            project_output_dict[f"Pearson_corr_{quartile}"].append(pearson_corr)
                            project_output_dict[f"Pearson_p_{quartile}"].append(pearson_p)
                            project_output_dict[f"Kendall_corr_{quartile}"].append(kendall_corr)
                            project_output_dict[f"Kendall_p_{quartile}"].append(kendall_p)
                            delta = np.array(f_tests_ms) - np.array(p_tests_ms)
                            delta_absolute = np.absolute(delta)
                            project_output_dict[f"MS_Delta_med_{quartile}"].append(np.median(delta_absolute))
                            project_output_dict[f"MS_Delta_min_{quartile}"].append(np.min(delta_absolute))
                            project_output_dict[f"MS_Delta_max_{quartile}"].append(np.max(delta_absolute))
                            project_output_dict[f"MS_Delta_avg_{quartile}"].append(np.mean(delta_absolute))

                            logging.info(
                                f"Calculation Starts: QUARTILE: {quartile} - M_selection_{mutant_selection} | Test_selection_{test_selection} | Bug: {project}_{bug}")

                group_output_dict.update({group: project_output_dict})  # for each group we calculate values per each bug, so that we can compare groups
                logging.info(f"Calculation Done: M_selection_{mutant_selection} | Test_selection_{test_selection} | Group_{group}")

            os.makedirs(f"{arguments.path_to_data_file}/statistic_analysis_data_defects4j", exist_ok=True)
            for group_name, group_data in group_output_dict.items():  # export data for each group
                pd.DataFrame(group_data).to_csv(os.path.join(arguments.path_to_data_file,
                                                             f"statistic_analysis_data_defects4j/M_selection_{mutant_selection}_Test_selection_{test_selection}_group_name_{group_name}.csv"))
                logging.info(f"Outputting Done: M_selection_{mutant_selection} | Test_selection_{test_selection} | Group_{group_name}")


def plot_statistics_our_dataset():
    # [UPDATE] load data about bugs reviled by == 1 or > 1 failing tests
    data_bug_reviling_tests = json.load(open(arguments.bugs_id_split_file))
    bugs_one_test_project_bug = [int(element["ID"]) for element in data_bug_reviling_tests["One_test_failing"]]
    bugs_more_tests_project_bug = [int(element["ID"]) for element in data_bug_reviling_tests["More_tests_failing"]]

    red_circle = dict(markerfacecolor='red', marker='o', markeredgecolor='white')
    for m_selection in [10, 20, 30, 50]:
        for test in [2, 4, 10, 14]:
            for group in ["semantic", "fault_prob", "fault_prob_max"]:
                logging.info(f"Statistics Data Plotting Starts: M_selection_{m_selection} | Test_selection_{test} | Group_{group}")

                path_2_file = os.path.join(arguments.path_to_data_file, f"M_selection_{m_selection}_Test_selection_{test}_group_name_{group}.csv")
                logging.info(f"Path: {path_2_file}")
                data_df = pd.read_csv(filepath_or_buffer=path_2_file, index_col=0)
                # data_df = pd.read_csv(filepath_or_buffer=arguments.path_to_data_file, index_col=0)

                for category_name, filter_list in [("One", bugs_one_test_project_bug), ("More", bugs_more_tests_project_bug)]:
                    category_data = data_df[data_df.index.isin(filter_list)]
                    logging.info(f"For category: {category_name} - Size: {len(category_data)}")

                    fig, axes = plt.subplots(nrows=1, ncols=7, figsize=(12, 5))

                    axes[0].boxplot(x=category_data["A12"], flierprops=red_circle, widths=0.3)
                    axes[0].set_ylim(top=1)
                    axes[0].set_ylim(bottom=0)
                    axes[0].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
                    axes[0].set_xlabel("$A_{12}$")
                    axes[0].set_ylabel("Effect Size Score")
                    axes[1].boxplot(x=category_data["A12_p"], flierprops=red_circle, widths=0.3)
                    axes[1].set_ylim(top=0.1)
                    axes[1].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
                    axes[1].set_xlabel("$A_{12} p$")
                    axes[1].set_ylabel("P value")
                    axes[2].boxplot(x=category_data["Pearson_corr"], flierprops=red_circle, widths=0.3)
                    axes[2].set_ylim(top=1)
                    axes[2].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
                    axes[2].set_xlabel("Pearson")
                    axes[2].set_ylabel("Correlation Score")
                    axes[3].boxplot(x=category_data["Kendall_corr"], flierprops=red_circle, widths=0.3)
                    axes[3].set_ylim(top=1)
                    axes[3].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
                    axes[3].set_xlabel("Kendall")
                    axes[3].set_ylabel("Correlation Score")
                    axes[4].boxplot(x=category_data["MS_Delta_med"], flierprops=red_circle, widths=0.3)
                    axes[4].set_ylim(top=100)
                    axes[4].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
                    axes[4].set_xlabel("\u0394 MS Median")
                    axes[4].set_ylabel("Mutation Score Value")
                    axes[5].boxplot(x=category_data["MS_Delta_max"], flierprops=red_circle, widths=0.3)
                    axes[5].set_ylim(top=100)
                    axes[5].set_ylim(bottom=0)
                    axes[5].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
                    axes[5].set_xlabel("\u0394 MS Max")
                    axes[5].set_ylabel("Mutation Score Value")
                    axes[6].boxplot(x=category_data["MS_Delta_avg"], flierprops=red_circle, widths=0.3)
                    axes[6].set_ylim(top=100)
                    axes[6].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
                    axes[6].set_xlabel("\u0394 MS Avg")
                    axes[6].set_ylabel("Mutation Score Value")

                    plt.tight_layout()
                    # df.plot(kind='box', color={'medians': 'blue'},
                    #         medianprops={'linestyle': '--', 'linewidth': 5})
                    os.makedirs("statistics_plots_categorized", exist_ok=True)
                    plt.savefig(os.path.join("statistics_plots_categorized",
                                             f"Categorized_{category_name}_M_selection_{m_selection}_Test_selection_{test}_group_name_{group}.png"),
                                format="png")

                    # plt.show()
                    plt.close()


def plot_statistics_defects4j_extended():
    # data_bug_reviling_tests = json.load(open(arguments.bugs_id_split_file))
    # bugs_one_test_project_bug = [int(element["ID"]) for element in data_bug_reviling_tests["One_test_failing"]]
    # bugs_more_tests_project_bug = [int(element["ID"]) for element in data_bug_reviling_tests["More_tests_failing"]]

    statistics = dict()
    output_dict = []

    # for group_1, group_2 in [("semantic", "fault_prob"), ("semantic", "fault_prob_max"), ("fault_prob", "fault_prob_max")]:
    for group_1, group_2 in [("semantic", "fault_prob"), ("semantic", "fault_prob_max")]:
        statistics_data_12 = collections.defaultdict(list)
        statistics_data_wilcoxon = collections.defaultdict(list)
        statistics_data_pearson = collections.defaultdict(list)
        statistics_data_kendall = collections.defaultdict(list)
        for m_selection in [10, 20, 30, 50]:
            for test in [5, 10, 20]:
                logging.info(f"Statistics Data Plotting Starts: M_selection_{m_selection} | Test_selection_{test} | Groups_{group_1}_{group_2}")

                path_2_file_group_1 = os.path.join(arguments.path_to_data_file, f"M_selection_{m_selection}_Test_selection_{test}_group_name_{group_1}.csv")
                path_2_file_group_2 = os.path.join(arguments.path_to_data_file, f"M_selection_{m_selection}_Test_selection_{test}_group_name_{group_2}.csv")
                logging.info(f"Path group 1: {path_2_file_group_1}")
                logging.info(f"Path group 2: {path_2_file_group_2}")
                data_df_group_1 = pd.read_csv(filepath_or_buffer=path_2_file_group_1, index_col=0)
                data_df_group_2 = pd.read_csv(filepath_or_buffer=path_2_file_group_2, index_col=0)

                columns = data_df_group_1.columns
                for quartile, cut in [("Q4", 3), ("EXTREME", 8)]:
                    columns_filter = [column for column in columns if quartile in column]
                    data_group_1_quartile = data_df_group_1[columns_filter].copy()
                    data_group_2_quartile = data_df_group_2[columns_filter].copy()

                    data_group_1_quartile.rename(columns=lambda x: x[:-cut], inplace=True)
                    data_group_2_quartile.rename(columns=lambda x: x[:-cut], inplace=True)

                    logging.info(f"Quartile: {quartile}")

                    a12_group = a12(data_group_1_quartile["A12"].tolist(), data_group_2_quartile["A12"].tolist(), pairwise=True)
                    # vd_ = VD_A(data_group_1_quartile["A12"].tolist(), data_group_2_quartile["A12"].tolist())

                    prob_wilcoxon = stats.wilcoxon(data_group_1_quartile["A12"].tolist(), data_group_2_quartile["A12"].tolist()).pvalue
                    # logging.info(f"A12: {a12_group} - Wilcoxon: {prob_wilcoxon} - vd_ {vd_[0]} - {vd_[1]}")
                    logging.info(f"A12: {a12_group} - Wilcoxon: {prob_wilcoxon}")

                    pearson_corr, pearson_p = stats.pearsonr(data_group_1_quartile["A12"].tolist(), data_group_2_quartile["A12"].tolist())
                    kendall_corr, kendall_p = stats.kendalltau(data_group_1_quartile["A12"].tolist(), data_group_2_quartile["A12"].tolist())

                    statistics_data_12[quartile].append(a12_group)
                    statistics_data_wilcoxon[quartile].append(prob_wilcoxon)
                    statistics_data_pearson[quartile].append(pearson_corr)
                    statistics_data_kendall[quartile].append(kendall_corr)

                    output_dict.append({"Group": f'{group_1}_{group_2}', "Mutants": m_selection, "Tests": test, "Quartile": quartile,
                                        "A12": a12_group, "Wilcoxon": prob_wilcoxon,
                                        "Pearson": pearson_corr, "Kendall": kendall_corr})

        statistics[f'{group_1}_{group_2}'] = (statistics_data_12, statistics_data_wilcoxon, statistics_data_pearson, statistics_data_kendall)
    pd.DataFrame(output_dict).to_csv("./output_pairwise_plus_corr.csv")

    sem_fault_prob_data_12 = statistics["semantic_fault_prob"][0]
    sem_fault_prob_data_pearson = statistics["semantic_fault_prob"][2]
    sem_fault_prob_data_kendal = statistics["semantic_fault_prob"][3]

    sem_fault_prob_max_data_12 = statistics["semantic_fault_prob_max"][0]
    sem_fault_prob_max_data_pearson = statistics["semantic_fault_prob_max"][2]
    sem_fault_prob_max_data_kendal = statistics["semantic_fault_prob_max"][3]

    # red_circle = dict(markerfacecolor='red', marker='o', markeredgecolor='white')
    # flierprops = dict(marker='+', markerfacecolor='g', markersize=15, linestyle='none', markeredgecolor='r')
    red_circle = dict(markerfacecolor='red', marker='o', markeredgecolor='white')
    meanlineprops = dict(linewidth=2.5, color='purple')

    font = {'family': 'normal',
            # 'weight': 'bold',
            'size': 16}

    matplotlib.rc('font', **font)

    fig, axes = plt.subplots(nrows=1, ncols=4, figsize=(8, 6))

    ax1_dict = {'fontsize': 16}
    axes[0].boxplot(x=sem_fault_prob_data_12["EXTREME"], medianprops=meanlineprops, flierprops=red_circle, widths=0.4, showmeans=True)
    axes[0].set_title('FDP', fontdict=ax1_dict, pad=10)
    axes[0].set_ylim(top=1)
    axes[0].set_ylim(bottom=0)
    axes[0].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
    axes[0].set_xlabel("$A_{12}$", fontdict=ax1_dict, labelpad=10)

    axes[1].boxplot(x=sem_fault_prob_max_data_12["EXTREME"], medianprops=meanlineprops, flierprops=red_circle, widths=0.4, showmeans=True)
    axes[1].set_title('FDP Max', fontdict=ax1_dict, pad=10)
    axes[1].set_ylim(top=1)
    axes[1].set_ylim(bottom=0)
    axes[1].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
    axes[1].set_xlabel("$A_{12}$", fontdict=ax1_dict, labelpad=10)

    axes[2].boxplot(x=sem_fault_prob_data_kendal["EXTREME"], medianprops=meanlineprops, flierprops=red_circle, widths=0.4, showmeans=True)
    axes[2].set_title('FDP', fontdict=ax1_dict, pad=10)
    axes[2].set_ylim(top=1)
    axes[2].set_ylim(bottom=0)
    axes[2].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
    axes[2].set_xlabel(r"Kendall $\tau$", labelpad=10, fontdict=ax1_dict)

    axes[3].boxplot(x=sem_fault_prob_max_data_kendal["EXTREME"], medianprops=meanlineprops, flierprops=red_circle, widths=0.4, showmeans=True)
    axes[3].set_title('FDP Max', fontdict=ax1_dict, pad=10)
    axes[3].set_ylim(top=1)
    axes[3].set_ylim(bottom=0)
    axes[3].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
    axes[3].set_xlabel(r"Kendall $\tau$", labelpad=10, fontdict=ax1_dict)

    fig.suptitle(f"Semantic Similarity versus", fontsize=16)
    plt.tight_layout()
    # df.plot(kind='box', color={'medians': 'blue'},
    #         medianprops={'linestyle': '--', 'linewidth': 5})
    os.makedirs("statistics_plots_defects4j", exist_ok=True)
    plt.savefig(os.path.join("statistics_plots_defects4j", f"Discussion_Grid_data_pairwise_corr_test.png"), format="png")

    plt.show()
    plt.close()

    # for group_name, group_tuple in statistics.items():
    #     # if group_name in ["semantic_fault_prob"]: continue
    #     group_data_12, group_data_wilcoxon = group_tuple[0], group_tuple[1]
    #     fig, axes = plt.subplots(nrows=1, ncols=4, figsize=(10, 5))
    #
    #     axes[0].boxplot(x=group_data_12["Q4"], flierprops=red_circle, widths=0.3)
    #     axes[0].set_title('Q4')
    #     axes[0].set_ylim(top=1)
    #     axes[0].set_ylim(bottom=0)
    #     axes[0].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
    #     axes[0].set_xlabel("$A_{12}$")
    #
    #     axes[1].boxplot(x=group_data_wilcoxon["Q4"], flierprops=red_circle, widths=0.3)
    #     axes[1].set_title('Q4')
    #     # axes[1].set_ylim(top=0.1)
    #     axes[1].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
    #     axes[1].set_xlabel("wilcoxon p value")
    #
    #     axes[2].boxplot(x=group_data_12["EXTREME"], flierprops=red_circle, widths=0.3)
    #     axes[2].set_title('EXTREME')
    #     axes[2].set_ylim(top=1)
    #     axes[2].set_ylim(bottom=0)
    #     axes[2].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
    #     axes[2].set_xlabel("$A_{12}$")
    #
    #     axes[3].boxplot(x=group_data_wilcoxon["EXTREME"], flierprops=red_circle, widths=0.3)
    #     axes[3].set_title('EXTREME')
    #     # axes[3].set_ylim(top=0.00001)
    #     axes[3].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
    #     axes[3].set_xlabel("Wilcoxon p value")
    #
    #     fig.suptitle(f"Observed groups: {group_name}", fontsize=16)
    #     plt.tight_layout()
    #     # df.plot(kind='box', color={'medians': 'blue'},
    #     #         medianprops={'linestyle': '--', 'linewidth': 5})
    #     os.makedirs("statistics_plots_defects4j", exist_ok=True)
    #     plt.savefig(os.path.join("statistics_plots_defects4j", f"Grid_data_{group_name}_pairwise_corr.png"), format="png")
    #
    #     plt.show()
    #     plt.close()


def calculate_semantic_fdp_mse():
    print()
    path_2_file = os.path.join(arguments.path_to_data_file, f"calculation_mistakes_ours.csv")
    logging.info(f"Path group: {path_2_file}")
    assert os.path.exists(path_2_file), f"Path does not exists >>> {path_2_file}"
    data_df = pd.read_csv(filepath_or_buffer=path_2_file)

    data_df = data_df[data_df["Ochiai"] != 0]

    projects = data_df["Project_ID"].unique()
    bug_correlation = collections.defaultdict(list)
    for project in projects:
        project_data_df = data_df[data_df["Project_ID"] == project]
        bugs = project_data_df["Bug_ID"].unique()
        for bug in bugs:
            bug_data_df = project_data_df[project_data_df["Bug_ID"] == bug]

            bug_data_df["ParcentageHits"] = bug_data_df["Hits"] / 1000

            semantic_scores = bug_data_df["Ochiai"].tolist()
            fdp_scores = bug_data_df["FDP"].tolist()

            sem_mse = metrics.mean_squared_error(semantic_scores, bug_data_df["ParcentageHits"].tolist())
            fdp_mse = metrics.mean_squared_error(fdp_scores, bug_data_df["ParcentageHits"].tolist())

            bug_correlation["sem_mse"].append(sem_mse)
            bug_correlation["fdp_mse"].append(fdp_mse)


    df = pd.DataFrame(bug_correlation)
    df.dropna(subset=["sem_mse", "fdp_mse"], inplace=True)
    # df.plot.scatter(x="Weighted_semantic", y="Weighted_fdp")
    # print()
    red_circle = dict(markerfacecolor='red', marker='o', markeredgecolor='white')
    meanlineprops = dict(linewidth=2.5, color='purple')

    font = {'family': 'normal',
            # 'weight': 'bold',
            'size': 16}

    matplotlib.rc('font', **font)
    ax1_dict = {'fontsize': 16}

    fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(8, 6))
    axes[0].boxplot(x=df["sem_mse"], medianprops=meanlineprops, flierprops=red_circle, widths=0.4, showmeans=True)
    axes[0].set_title('Semantic MSE', fontdict=ax1_dict, pad=10)
    axes[0].set_ylim(top=0.3)
    axes[0].set_ylim(bottom=0)
    axes[0].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
    # axes[0].set_xlabel("$A_{12}$", fontdict=ax1_dict, labelpad=10)

    axes[1].boxplot(x=df["fdp_mse"], medianprops=meanlineprops, flierprops=red_circle, widths=0.4, showmeans=True)
    axes[1].set_title('FDP MSE', fontdict=ax1_dict, pad=10)
    axes[1].set_ylim(top=0.3)
    axes[1].set_ylim(bottom=0)
    axes[1].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)

    value = wilcoxon(df["sem_mse"].tolist(), df["fdp_mse"].tolist()).pvalue
    a12_value = a12(df["fdp_mse"].tolist(), df["sem_mse"].tolist())
    plt.suptitle("Wilcoxon: {0} A12: {1:.3f}".format(value, a12_value))

    plt.tight_layout()

    # os.makedirs("correlation_data_plots", exist_ok=True)
    plt.savefig(os.path.join(".", f"BoxPlot_correlation_scores.png"), format="png")

    plt.show()
    plt.close()


def calculate_correlation_ms_fault_detection():
    dataset = "defects4j_percentages"
    # pit_selection = [2, 4, 10, 14]
    defects4j_selection = [1, 2, 3, 4, 5]
    # data_path = os.path.join(dataset, "only_extreme_cases")
    data_path = "defects4j_percentages"

    m_selection_data = collections.defaultdict(dict)
    for m_selection in [30]:
        test_selection_data = collections.defaultdict(dict)
        for test in defects4j_selection:
            logging.info(f"Statistics Data Plotting Starts: M_selection_{m_selection} | Test_selection_{test}")

            path_2_file_group = os.path.join(arguments.path_to_data_file, data_path, f"simulation_data_extension_{m_selection}_tests_{test}.csv")
            logging.info(f"Path group: {path_2_file_group}")
            assert os.path.exists(path_2_file_group), f"Path does not exists >>> {path_2_file_group}"
            data_df = pd.read_csv(filepath_or_buffer=path_2_file_group)

            # data_df = data_df[data_df["Number_Of_Failing_Tests"] == 1]

            buckets = data_df["Bucket"].unique()
            bucket_data = collections.defaultdict(dict)

            # number_of_failing_per_bug = collections.defaultdict(list)
            # number_of_passing_per_bug = collections.defaultdict(list)

            for bucket in buckets:
                bucket_data_df = data_df[data_df["Bucket"] == bucket]

                group_data = collections.defaultdict(dict)
                for group in ["semantic", "fault_prob", "fault_prob_max"]:
                    group_data_df = bucket_data_df[bucket_data_df["Group"] == group]

                    pearson_data = collections.defaultdict(list)
                    kendall_data = collections.defaultdict(list)
                    variance_data = collections.defaultdict(list)
                    stdev_data = collections.defaultdict(list)
                    mean_data = collections.defaultdict(list)
                    median_data = collections.defaultdict(list)
                    harmonic_mean_data = collections.defaultdict(list)
                    projects = group_data_df["Project_ID"].unique()
                    for project in projects:
                        project_data_df = group_data_df[group_data_df["Project_ID"] == project]
                        bugs = project_data_df["Bug_ID"].unique()
                        for bug in bugs:
                            bug_data_df = project_data_df[project_data_df["Bug_ID"] == bug]

                            # bug_data.Test_Category.replace({"failing": 1, "passing": 0}, inplace=True)
                            # Applying the condition
                            bug_data_df["Test_Category"] = np.where(bug_data_df["Test_Category"] == "failing", 1, 0)
                            ms_scores = bug_data_df["MS"].tolist()
                            detection_scores = bug_data_df["Test_Category"].tolist()

                            # if bucket == "EXTREME" and group == "semantic":
                            #     zeros = bug_data_df[bug_data_df["Test_Category"] == 0]["Test_Category"]
                            #     ones = bug_data_df[bug_data_df["Test_Category"] == 1]["Test_Category"]
                            #     number_of_failing_per_bug[f"{project}_{bug}"].extend(zeros.tolist())
                            #     number_of_passing_per_bug[f"{project}_{bug}"].extend(ones.tolist())

                            pearson_corr, pearson_p = stats.pearsonr(ms_scores, detection_scores)
                            kendall_corr, kendall_p = stats.kendalltau(ms_scores, detection_scores)

                            pearson_data["Pearson"].append(pearson_corr)
                            pearson_data["Pearson_p"].append(pearson_p)
                            kendall_data["Kendall"].append(kendall_corr)
                            kendall_data["Kendall_p"].append(kendall_p)
                            variance_data["Variance"].append(variance(ms_scores))
                            stdev_data["StdDev"].append(stdev(ms_scores))
                            mean_data["Mean"].append(mean(ms_scores))
                            median_data["Median"].append(median(ms_scores))
                            harmonic_mean_data["HarmonicMean"].append(harmonic_mean(ms_scores))

                    group_data[group].update(pearson_data)
                    group_data[group].update(kendall_data)
                    group_data[group].update(variance_data)
                    group_data[group].update(stdev_data)
                    group_data[group].update(mean_data)
                    group_data[group].update(median_data)
                    group_data[group].update(harmonic_mean_data)

                bucket_data[bucket].update(group_data)

            test_selection_data[test].update(bucket_data)

        m_selection_data[m_selection].update(test_selection_data)

    for mutants in m_selection_data:
        for test in m_selection_data[mutants]:
            for bucket in m_selection_data[mutants][test]:

                for corr_coff in ["Pearson", "Kendall"]:
                    d_p = {"Semantic": m_selection_data[mutants][test][bucket]['semantic'][f'{corr_coff}'],
                           "Semantic_p": m_selection_data[mutants][test][bucket]['semantic'][f'{corr_coff}_p'],
                           "Semantic_Variance": m_selection_data[mutants][test][bucket]['semantic']["Variance"],
                           "Semantic_StdDev": m_selection_data[mutants][test][bucket]['semantic']["StdDev"],
                           "Semantic_Mean": m_selection_data[mutants][test][bucket]['semantic']["Mean"],
                           "Semantic_Median": m_selection_data[mutants][test][bucket]['semantic']["Median"],
                           "Semantic_HarmonicMean": m_selection_data[mutants][test][bucket]['semantic']["HarmonicMean"],
                           "FDP": m_selection_data[mutants][test][bucket]['fault_prob'][f'{corr_coff}'],
                           "FDP_p": m_selection_data[mutants][test][bucket]['fault_prob'][f'{corr_coff}_p'],
                           "FDP_Variance": m_selection_data[mutants][test][bucket]['fault_prob']["Variance"],
                           "FDP_StdDev": m_selection_data[mutants][test][bucket]['fault_prob']["StdDev"],
                           "FDP_Mean": m_selection_data[mutants][test][bucket]['fault_prob']["Mean"],
                           "FDP_Median": m_selection_data[mutants][test][bucket]['fault_prob']["Median"],
                           "FDP_HarmonicMean": m_selection_data[mutants][test][bucket]['fault_prob']["HarmonicMean"],
                           "FDP_Max": m_selection_data[mutants][test][bucket]['fault_prob_max'][f'{corr_coff}'],
                           "FDP_Max_p": m_selection_data[mutants][test][bucket]['fault_prob_max'][f'{corr_coff}_p'],
                           "FDP_Max_Variance": m_selection_data[mutants][test][bucket]['fault_prob_max']["Variance"],
                           "FDP_Max_StdDev": m_selection_data[mutants][test][bucket]['fault_prob_max']["StdDev"],
                           "FDP_Max_Mean": m_selection_data[mutants][test][bucket]['fault_prob_max']["Mean"],
                           "FDP_Max_Median": m_selection_data[mutants][test][bucket]['fault_prob_max']["Median"],
                           "FDP_Max_HarmonicMean": m_selection_data[mutants][test][bucket]['fault_prob_max']["HarmonicMean"]
                           }

                    export_df = pd.DataFrame(d_p)
                    export_df.to_csv(os.path.join(arguments.output_dir, f"Data_correlation_{dataset}_{mutants}_{corr_coff}_{bucket}_{test}.csv"))

    print()
    # for bug in number_of_failing_per_bug:
    #     print(f"{bug},{len(number_of_failing_per_bug[bug])},{len(number_of_passing_per_bug[bug])}")


def plot_correlation_ms_fault_detection():

    # pit_selection = [2, 4, 10, 14]
    defects4j_selection = [1, 2, 3, 4, 5]
    dataset = "defects4j_percentages"
    for mutants in [30]:
        for bucket in ["EXTREME", "EXTREME_5"]:
            for test in defects4j_selection:
                for corr_coeff in ["Pearson", "Kendall"]:
                    data_df = pd.read_csv(os.path.join(f"correlation_data_percentages", f"Data_correlation_{dataset}_{mutants}_{corr_coeff}_{bucket}_{test}.csv"))
                    data_df.dropna(subset=['Semantic', 'FDP'], how='all', inplace=True)
                    red_circle = dict(markerfacecolor='red', marker='o', markeredgecolor='white')
                    meanlineprops = dict(linewidth=2.5, color='purple')

                    font = {'family': 'normal',
                            # 'weight': 'bold',
                            'size': 16}

                    matplotlib.rc('font', **font)
                    ax1_dict = {'fontsize': 16}

                    fig, axes = plt.subplots(nrows=1, ncols=9, figsize=(18, 6))
                    # Semantic_Variance, Semantic_StdDev, Semantic_Mean, Semantic_Median, Semantic_HarmonicMean
                    # FDP_Variance, FDP_StdDev, FDP_Mean, FDP_Median, FDP_HarmonicMean,
                    # FDP_Max_Variance, FDP_Max_StdDev, FDP_Max_Mean, FDP_Max_Median, FDP_Max_HarmonicMean
                    axes[0].boxplot(x=data_df["Semantic_Variance"], medianprops=meanlineprops, flierprops=red_circle, widths=0.4, showmeans=True)
                    axes[0].set_title('Semantic_Variance', fontdict=ax1_dict, pad=10)
                    # axes[0].set_ylim(top=1)
                    # axes[0].set_ylim(bottom=0)
                    axes[0].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)
                    # axes[0].set_xlabel("$A_{12}$", fontdict=ax1_dict, labelpad=10)

                    axes[1].boxplot(x=data_df["FDP_Variance"], medianprops=meanlineprops, flierprops=red_circle, widths=0.4, showmeans=True)
                    axes[1].set_title('FDP_Variance', fontdict=ax1_dict, pad=10)
                    # axes[1].set_ylim(top=1)
                    # axes[1].set_ylim(bottom=0)
                    axes[1].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)

                    axes[2].boxplot(x=data_df["FDP_Max_Variance"], medianprops=meanlineprops, flierprops=red_circle, widths=0.4, showmeans=True)
                    axes[2].set_title('FDP_Max_Variance', fontdict=ax1_dict, pad=10)
                    # axes[2].set_ylim(top=1)
                    # axes[2].set_ylim(bottom=0)
                    axes[2].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)

                    axes[3].boxplot(x=data_df["Semantic_StdDev"], medianprops=meanlineprops, flierprops=red_circle, widths=0.4, showmeans=True)
                    axes[3].set_title('Semantic_StdDev', fontdict=ax1_dict, pad=10)
                    # axes[3].set_ylim(top=1)
                    # axes[3].set_ylim(bottom=0)
                    axes[3].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)

                    axes[4].boxplot(x=data_df["FDP_StdDev"], medianprops=meanlineprops, flierprops=red_circle, widths=0.4, showmeans=True)
                    axes[4].set_title('FDP_StdDev', fontdict=ax1_dict, pad=10)
                    # axes[4].set_ylim(top=1)
                    # axes[4].set_ylim(bottom=0)
                    axes[4].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)

                    axes[5].boxplot(x=data_df["FDP_Max_StdDev"], medianprops=meanlineprops, flierprops=red_circle, widths=0.4, showmeans=True)
                    axes[5].set_title('FDP_Max_StdDev', fontdict=ax1_dict, pad=10)
                    # axes[5].set_ylim(top=1)
                    # axes[5].set_ylim(bottom=0)
                    axes[5].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)

                    axes[6].boxplot(x=data_df["Semantic_Median"], medianprops=meanlineprops, flierprops=red_circle, widths=0.4, showmeans=True)
                    axes[6].set_title('Semantic_Median', fontdict=ax1_dict, pad=10)
                    # axes[6].set_ylim(top=1)
                    # axes[6].set_ylim(bottom=0)
                    axes[6].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)

                    axes[7].boxplot(x=data_df["FDP_Median"], medianprops=meanlineprops, flierprops=red_circle, widths=0.4, showmeans=True)
                    axes[7].set_title('FDP_Median', fontdict=ax1_dict, pad=10)
                    # axes[7].set_ylim(top=1)
                    # axes[7].set_ylim(bottom=0)
                    axes[7].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)

                    axes[8].boxplot(x=data_df["FDP_Max_Median"], medianprops=meanlineprops, flierprops=red_circle, widths=0.4, showmeans=True)
                    axes[8].set_title('FDP_Max_Median', fontdict=ax1_dict, pad=10)
                    # axes[8].set_ylim(top=1)
                    # axes[8].set_ylim(bottom=0)
                    axes[8].tick_params(axis='x', bottom=False, labelbottom=False, pad=0)

                    # sig_sem = wilcoxon(data_df["Semantic"].tolist(), data_df["FDP"].tolist()).pvalue
                    # sig_sem_max = wilcoxon(data_df["Semantic"].tolist(), data_df["FDP_Max"].tolist()).pvalue
                    # fig.suptitle(f"F_{mutants}_{test} W_{round(sig_sem, 4)}_{round(sig_sem_max, 4)}_{bucket}", fontsize=16)

                    plt.tight_layout()

                    # os.makedirs("correlation_data_plots", exist_ok=True)
                    plt.savefig(os.path.join(".", f"Data_correlation_{dataset}_{mutants}_{corr_coeff}_{bucket}_{test}_stats.png"), format="png")

                    plt.show()
                    plt.close()


def argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Data path")
    parser.add_argument("-p", "--path_to_data_file", action="store", help="Store directory path to parsed mutants")
    parser.add_argument("-o", "--output_dir", action="store", help="Store directory for output")
    parser.add_argument("-b", "--bugs_id_split_file", action="store", help="Store file for bugs ids")
    parser.add_argument("-n", "--tool_name", action="store", help="Store name of a tool")
    parser.add_argument("-m", "--mutants_pool", action="store", help="Store number of mutants")

    return parser


if __name__ == '__main__':
    arguments = argument_parser().parse_args()

    # plot_simulation_groups_by_buckets()  # Plot simulation data per bucket, group by test selection
    # plot_simulation_by_testcategory()  # Plot simulation data per test selection, group by buckets
    # calculate_best_simulation_performance()  # Out of grid results - calculate sweet point suggested by biggest median difference
    # plot_simulation_split_on_bugs_with_one_or_more_tests_merge_version()  # Plot simulation data splitted on bugs that are reviled by one test and many tests
    # plot_simulation_split_on_bugs_with_one_or_more_tests()  # Plot simulation data splitted on bugs that are reviled by one test and many tests - data has a column of failing tests
    # calculate_statistics_for_each_bug_per_group()

    # plot_statistics_our_dataset()
    # plot_statistics_defects4j()

    # calculate_correlation_ms_fault_detection()

    # plot_statistics_defects4j_extended()

    # plot_correlation_ms_fault_detection()
