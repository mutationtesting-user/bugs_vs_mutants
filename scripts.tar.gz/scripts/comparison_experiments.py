import argparse
import re

import pandas as pd
import collections
import random
import numpy as np
import os

GLOBAL_COUNTER = 0


class Mutant(object):

    def __init__(self, mutant_id, mutant_identification):
        self.mutant_ID = mutant_id
        self.killingTests = frozenset()
        self.mutant_identification = mutant_identification
        self.mutant_operator = ""
        self.lineNumbers = []
        self.modifiedClass = ""
        self.ochiai = 0

    def __ne__(self, other):
        return (not isinstance(other, type(self))
                or self.mutant_ID != other.mutant_ID)

    def __eq__(self, othr):
        return (isinstance(othr, type(self))
                and self.mutant_ID == othr.mutant_ID)

    def __hash__(self):
        return hash((self.mutant_ID, self.killingTests))


def parse_mutants(mutants_with_killing_tests, tool, failing_tests, additional_info=None):
    global GLOBAL_COUNTER
    mutants_list = []
    for mutant_id in mutants_with_killing_tests:
        if tool == "PIT":
            mutantID = f'{GLOBAL_COUNTER}_PIT'
            TESTS_HEADER = "Killing_tests"
        elif tool == "IBIR":
            mutantID = f'{GLOBAL_COUNTER}_IBIR'
            TESTS_HEADER = "Killing_tests"
        elif tool == "DEEPMUTATION":
            mutantID = f'{GLOBAL_COUNTER}_DEEPMUTATION'
            TESTS_HEADER = "Failing_Tests"
        else:
            mutantID = f'{GLOBAL_COUNTER}_CODEBERT'
            TESTS_HEADER = "Failing_Tests"

        GLOBAL_COUNTER += 1
        mutant = Mutant(mutantID, mutant_id)
        killing_tests_string = mutants_with_killing_tests[mutant_id][TESTS_HEADER]

        if tool == "PIT" and additional_info is not None:
            mutant.mutant_operator = additional_info[mutant_id]["Operator"]
            mutant.lineNumbers.append(additional_info[mutant_id]["Line_number"])
            mutant.modifiedClass = additional_info[mutant_id]["Source_file"].split(".")[0].strip()
        if tool == "IBIR":
            mutant.modifiedClass = mutants_with_killing_tests[mutant_id]["Modified_Class"].split(".")[0].strip()
            lines = mutants_with_killing_tests[mutant_id]["LinesRange"]
            lines_parsed = set()
            [lines_parsed.update(list(range(e[0], e[1] + 1))) for e in eval(lines)]
            fll = list(map(int, re.findall(r'\d+', mutants_with_killing_tests[mutant_id]["FlLines"])))
            lines_changed = {fll[0]}
            fll_without_first_two = fll[2:]
            for fault_localization_line_start in fll_without_first_two[::2]:
                if fault_localization_line_start in lines_parsed:
                    lines_changed.add(fault_localization_line_start)
            mutant.lineNumbers.extend(list(lines_changed))
        if tool == "CODEBERT" and additional_info is not None:
            mutant.modifiedClass = mutant_id.split("_")[0].strip()
            if mutant_id not in additional_info:
                lines = 0
            else:
                lines = additional_info[mutant_id]["Changed_Lines"]
            mutant.lineNumbers.append(int(lines))

        killing_tests = []
        if killing_tests_string == 'None':
            killing_tests = []
        else:
            if "," in killing_tests_string:
                killing_tests = killing_tests_string.split(',')
            else:
                killing_tests.append(killing_tests_string)
            killing_tests = [test.split("(")[0] for test in killing_tests]
        mutant.killingTests = frozenset(killing_tests)

        mutant.ochiai = get_ochia_score(set(failing_tests), set(mutant.killingTests))

        mutants_list.append(mutant)
    return mutants_list


def get_ochia_score(brokenTestsByBug: set, brokenTestsByMutant: set):
    assert brokenTestsByBug != None and len(brokenTestsByBug) != 0
    if brokenTestsByMutant == None or len(brokenTestsByMutant) == 0: return 0;
    intersectionSet = brokenTestsByBug.intersection(brokenTestsByMutant)
    prod = len(brokenTestsByBug) * len(brokenTestsByMutant)
    if prod == 0 or len(intersectionSet) == 0: return 0
    return len(intersectionSet) / np.sqrt(prod)


def read_pit_mutants(path, failing_tests):
    pit_mutants = []
    file_counter = 0
    for file in os.listdir(path):
        if "killing_tests" in file and "changed_methods" not in file:
            path_to_mutants_killing_matrics = os.path.join(path, file)
            pit_mutants_killing_tests = pd.read_csv(filepath_or_buffer=path_to_mutants_killing_matrics, index_col=0).to_dict(orient='index')

            if len(pit_mutants_killing_tests) == 0: continue
            # read mutants info - operator and save it
            path_to_mutants_info = os.path.join(path, f'{file[:-18]}_mutants.json')
            mutants_info = pd.read_json(path_or_buf=path_to_mutants_info).set_index("Mutant_ID").to_dict(orient="index")
            # mutants_info = None

            pit_mutants.extend(parse_mutants(pit_mutants_killing_tests, "PIT", failing_tests, additional_info=mutants_info))
            if file_counter >= 1:
                print()
            file_counter += 1
    return pit_mutants


def read_ibir_mutants(path, failing_tests):
    ibir_mutants_killing_tests = pd.read_csv(filepath_or_buffer=path, index_col='Mutant_ID').to_dict(orient='index')
    return parse_mutants(ibir_mutants_killing_tests, "IBIR", failing_tests)


def read_deep_mutation_mutants(path, failing_tests):
    deep_mutation_df = pd.read_csv(filepath_or_buffer=path, index_col='Mutant_Name')
    deep_mutation_df = deep_mutation_df[deep_mutation_df["Num_Failing_Tests"] != -1]  # -1 is a label saying that mutant does not compile
    deep_mutation_mutants_killing_tests = deep_mutation_df.to_dict(orient='index')
    return parse_mutants(deep_mutation_mutants_killing_tests, "DEEPMUTATION", failing_tests)


def read_codebert_mutants(path, additional_info, failing_tests):
    codebert_mutation_df = pd.read_csv(filepath_or_buffer=path, index_col='Mutant_Name')
    codebert_mutation_df = codebert_mutation_df[codebert_mutation_df["Num_Failing_Tests"] != -1]  # -1 is a label saying that mutant does not compile
    codebert_mutation_mutants_killing_tests = codebert_mutation_df.to_dict(orient='index')
    return parse_mutants(codebert_mutation_mutants_killing_tests, "CODEBERT", failing_tests, additional_info)


def load_failing_tests_for_bug(project_, bug_, path_to_failing_tests_dir):
    failing_tests_ground_truth = pd.read_csv(
        filepath_or_buffer=os.path.join(path_to_failing_tests_dir, f'{str(project_).lower()}_bugs_failing_tests.csv'),
        names=["BUG_ID", "FAILING_TESTS"], header=None)
    failing_tests_ = failing_tests_ground_truth.loc[failing_tests_ground_truth["BUG_ID"] == int(bug_[:-1]), 'FAILING_TESTS'].values[0].split(";")
    return list(map(lambda element: element.replace("::", "."), failing_tests_))


def calculate_rq_3b_simulation_deep_mutation_controlled_numbers(data_path):
    data = pd.read_csv(filepath_or_buffer=data_path)
    unique_projects = data["Project_ID"].unique()

    project_comparing_maps = collections.defaultdict(list)

    for project in unique_projects:
        project_data = data[data["Project_ID"] == project]
        project_bugs = project_data["Bug_ID"].unique()
        print("Project: ", project)

        for bug in project_bugs:
            print("\tBug: ", bug)
            bug_data = project_data[project_data["Bug_ID"] == bug]

            bug_tools = bug_data["Tool"].unique()

            if len(set(bug_tools).intersection({"deepmutation", "ibir", "codebert", "pit"})) != len({"deepmutation", "ibir", "codebert", "pit"}):
                continue

            deepmutation_data = bug_data[bug_data["Tool"] == "deepmutation"]
            deepmutation_data_ochiais = deepmutation_data["OCHIAI"].tolist()

            ibir_data = bug_data[bug_data["Tool"] == "ibir"]
            ibir_data_ochiais = ibir_data["OCHIAI"].tolist()

            codebert_data = bug_data[bug_data["Tool"] == "codebert"]
            codebert_data_ochiais = codebert_data["OCHIAI"].tolist()

            pit_data = bug_data[bug_data["Tool"] == "pit"]
            pit_data_ochiais = pit_data["OCHIAI"].tolist()

            selection_threadshold = min([len(deepmutation_data_ochiais), len(ibir_data_ochiais), len(codebert_data_ochiais), len(pit_data_ochiais)])

            deepmutation_run = []
            ibir_run = []
            pit_run = []
            mubert_run = []
            for repetition in range(100):
                ochiais_pick_deepmutation = random.sample(deepmutation_data_ochiais, selection_threadshold)
                deepmutation_run.append(1 if 1 in ochiais_pick_deepmutation else 0)

                ochiais_pick_ibir = random.sample(ibir_data_ochiais, selection_threadshold)
                ibir_run.append(1 if 1 in ochiais_pick_ibir else 0)

                ochiais_pick_pit = random.sample(pit_data_ochiais, selection_threadshold)
                pit_run.append(1 if 1 in ochiais_pick_pit else 0)

                ochiais_pick_mubert = random.sample(codebert_data_ochiais, selection_threadshold)
                mubert_run.append(1 if 1 in ochiais_pick_mubert else 0)

            deepmutation_simulation_mean = np.mean(deepmutation_run)
            ibir_simulation_mean = np.mean(ibir_run)
            pit_simulation_mean = np.mean(pit_run)
            mubert_simulation_mean = np.mean(mubert_run)

            project_comparing_maps["DeepMutation"].append(deepmutation_simulation_mean)
            project_comparing_maps["Ibir"].append(ibir_simulation_mean)
            project_comparing_maps["Pit"].append(pit_simulation_mean)
            project_comparing_maps["Codebert"].append(mubert_simulation_mean)

    for project in project_comparing_maps:
        print(f"Project - {project}: {np.mean(project_comparing_maps[project])}")


def calculate_rq_3b_simulation_ibir_controlled_numbers(data_path):
    data = pd.read_csv(filepath_or_buffer=data_path)
    unique_projects = data["Project_ID"].unique()

    project_comparing_maps = collections.defaultdict(list)

    for project in unique_projects:
        project_data = data[data["Project_ID"] == project]
        project_bugs = project_data["Bug_ID"].unique()
        print("Project: ", project)

        for bug in project_bugs:
            print("\tBug: ", bug)
            bug_data = project_data[project_data["Bug_ID"] == bug]

            bug_tools = bug_data["Tool"].unique()

            # if len(set(bug_tools).intersection({"deepmutation", "ibir", "codebert", "pit"})) != len({"deepmutation", "ibir", "codebert", "pit"}):
            #     continue
            if len(set(bug_tools).intersection({"ibir", "codebert", "pit"})) != len({"ibir", "codebert", "pit"}):
                continue

            ibir_data = bug_data[bug_data["Tool"] == "ibir"]
            ibir_data_ochiais = ibir_data["OCHIAI"].tolist()

            codebert_data = bug_data[bug_data["Tool"] == "codebert"]
            codebert_data_ochiais = codebert_data["OCHIAI"].tolist()

            pit_data = bug_data[bug_data["Tool"] == "pit"]
            pit_data_ochiais = pit_data["OCHIAI"].tolist()

            selection_threadshold = min([len(ibir_data_ochiais), len(codebert_data_ochiais), len(pit_data_ochiais)])

            ibir_run = []
            pit_run = []
            mubert_run = []
            for repetition in range(100):

                ochiais_pick_ibir = random.sample(ibir_data_ochiais, selection_threadshold)
                ibir_run.append(1 if 1 in ochiais_pick_ibir else 0)

                ochiais_pick_pit = random.sample(pit_data_ochiais, selection_threadshold)
                pit_run.append(1 if 1 in ochiais_pick_pit else 0)

                ochiais_pick_mubert = random.sample(codebert_data_ochiais, selection_threadshold)
                mubert_run.append(1 if 1 in ochiais_pick_mubert else 0)

            ibir_simulation_mean = np.mean(ibir_run)
            pit_simulation_mean = np.mean(pit_run)
            mubert_simulation_mean = np.mean(mubert_run)

            project_comparing_maps["Ibir"].append(ibir_simulation_mean)
            project_comparing_maps["Pit"].append(pit_simulation_mean)
            project_comparing_maps["Codebert"].append(mubert_simulation_mean)

    for project in project_comparing_maps:
        print(f"Project - {project}: {np.mean(project_comparing_maps[project])}")


def calculate_rq_3b_simulation_controlled_numbers_generic(data_path):
    data = pd.read_csv(filepath_or_buffer=data_path)
    unique_projects = data["Project_ID"].unique()

    project_comparing_maps = collections.defaultdict(list)

    for project in unique_projects:
        project_data = data[data["Project_ID"] == project]
        project_bugs = project_data["Bug_ID"].unique()
        print("Project: ", project)

        for bug in project_bugs:
            print("\tBug: ", bug)
            bug_data = project_data[project_data["Bug_ID"] == bug]

            bug_tools = bug_data["Tool"].unique()

            for pairs_tuple in [("deepmutation", ["pit", "ibir", "codebert"]), ("ibir", ["pit", "codebert"]), ("codebert", ["pit"]), ("pit", [])]:
                pair_key, comparing_list = pairs_tuple

                list_temp = list(comparing_list)
                list_temp.append(pair_key)
                if len(set(bug_tools).intersection(set(list_temp))) == len(list_temp):

                    pair_key_data = bug_data[bug_data["Tool"] == pair_key]
                    pair_key_mutants_with_sem_sim = pair_key_data["OCHIAI"].tolist()
                    pair_key_ratio_mutants_with_sem_sim = 0 if pair_key_mutants_with_sem_sim.count(1) == 0 else 1

                    comparing_dict = dict()
                    for comparing_pair in comparing_list:
                        comparing_pair_data = bug_data[bug_data["Tool"] == comparing_pair]
                        comparing_pair_mutants_sem = comparing_pair_data["OCHIAI"].tolist()
                        list_of_repetition = []
                        if len(comparing_pair_data) < len(pair_key_data):
                            print()
                        sample_k = len(pair_key_data) if len(pair_key_data) <= len(comparing_pair_data) else len(comparing_pair_data)

                        for i in range(100):
                            sample = random.sample(comparing_pair_mutants_sem, sample_k)
                            sem_sim_mutant_in_sample = 0 if sample.count(1) == 0 else 1
                            list_of_repetition.append(sem_sim_mutant_in_sample)
                        ratio_of_mutants_sem_after_sampling = np.mean(list_of_repetition)
                        comparing_dict.update({comparing_pair: ratio_of_mutants_sem_after_sampling})

                    comparing_dict.update({pair_key: pair_key_ratio_mutants_with_sem_sim})
                    project_comparing_maps[pair_key].append(comparing_dict)

    print(project_comparing_maps)
    for project_key, project_comparing_dict in project_comparing_maps.items():
        print("Project key:", project_key)
        df_data = pd.DataFrame(project_comparing_dict)
        for comparing_project in df_data.keys():
            print(f"Project comparing: {comparing_project} - {df_data[comparing_project].mean()}")


def calculate_rq_3b_simulation_ibir_controlled_lines(data_path, mutants_path, path_to_failing_tests_dir):
    data = pd.read_csv(filepath_or_buffer=data_path)
    unique_projects = data["Project_ID"].unique()

    project_comparing_maps = collections.defaultdict(list)

    codebert_mutants_lines = pd.read_csv(filepath_or_buffer=os.path.join(mutants_path, "all_compilable_mutants_processed_codebert.csv"))
    codebert_mutants_lines = codebert_mutants_lines[codebert_mutants_lines["Tool"] == "codebert"]
    codebert_mutants_lines['Changed_Lines'] = codebert_mutants_lines['Changed_Lines'].fillna(0)

    for project in unique_projects:
        project_data = data[data["Project_ID"] == project]
        project_bugs = project_data["Bug_ID"].unique()
        print("Project: ", project)

        codebert_mutants_lines_project_df = codebert_mutants_lines[codebert_mutants_lines["Project"] == project]

        for bug in project_bugs:
            print("\tBug: ", bug)

            bug_data = project_data[project_data["Bug_ID"] == bug]
            codebert_mutants_lines_bug_df = codebert_mutants_lines_project_df[codebert_mutants_lines_project_df["BugID"] == bug]
            bug_tools = bug_data["Tool"].unique()

            if len(set(bug_tools).intersection({"deepmutation", "ibir", "codebert", "pit"})) != len({"deepmutation", "ibir", "codebert", "pit"}):
                continue

            # LOAD FAILING TESTS FOR A BUG
            failing_tests = load_failing_tests_for_bug(project, bug, path_to_failing_tests_dir)

            # LOAD DATA OF THE BUG FROM EACH TOOL
            # WE NEED TO VALIDATE IF THE PROJECT BUG EXIST UNDER ALL TOOLS
            # check if exists in PIT dir
            pit_bug_path = os.path.join(mutants_path, 'parsed_pit_mutants', f'{project}_{bug[:-1]}')
            if not os.path.exists(pit_bug_path):
                raise FileNotFoundError(f"Bug directory does not exist: {pit_bug_path}")
            pit_mutants = read_pit_mutants(pit_bug_path, failing_tests)

            # check if exists in IBIR
            ibir_bug_path = os.path.join(mutants_path, 'ibir_mutants_info_with_lines', f'{project}_{bug[:-1]}.csv')
            if not os.path.exists(ibir_bug_path):
                raise FileNotFoundError(f"Bug directory does not exist: {ibir_bug_path}")
            ibir_mutants = read_ibir_mutants(ibir_bug_path, failing_tests)

            # check if exists in CodeBert
            codebert_bug_path = os.path.join(mutants_path, 'codebert_mutants_info', f'{project}_{bug[:-1]}.csv')
            if not os.path.exists(codebert_bug_path):
                raise FileNotFoundError(f"Bug directory does not exist: {codebert_bug_path}")
            codebert_mutants_lines_bug_df.set_index('Mutant', inplace=True)
            codebert_mutants_lines_bug_df_dict = codebert_mutants_lines_bug_df.to_dict(orient="index")
            codebert_mutants = read_codebert_mutants(codebert_bug_path, codebert_mutants_lines_bug_df_dict, failing_tests)

            # check if exists in DeepMutation
            deep_mutation_bug_path = os.path.join(mutants_path, 'deep-mutation_mutants_info', f'{project}_{bug[:-1]}.csv')
            if not os.path.exists(deep_mutation_bug_path):
                raise FileNotFoundError(f"Bug directory does not exist: {codebert_bug_path}")
            deep_mutation_mutants = read_deep_mutation_mutants(deep_mutation_bug_path, failing_tests)

            print("Passing")
            # CHECK WHICH LINES ARE TOUCHED BY IBIR
            ibir_file_lines = collections.defaultdict(set)
            for m in ibir_mutants:
                ibir_file_lines[m.modifiedClass].update(m.lineNumbers)

            codebert_file_lines = collections.defaultdict(set)
            for m in codebert_mutants:
                codebert_file_lines[m.modifiedClass].update(m.lineNumbers)

            # FILTER OUT THOSE THAT ARE NOT ON THE LINE
            pit_mutants_filtered = []
            for key in ibir_file_lines:
                pit_mutants_filtered.extend(
                    [m for m in pit_mutants if len(set(m.lineNumbers).intersection(ibir_file_lines[key])) > 0 and key == m.modifiedClass])

            codebert_mutants_filtered = []
            for key in ibir_file_lines:
                codebert_mutants_filtered.extend(
                    [m for m in codebert_mutants if len(set(m.lineNumbers).intersection(ibir_file_lines[key])) > 0 and key == m.modifiedClass])


            print()
            # TAKE A MINIMUM NUMBER OF MUTANTS AND PERFORM SIMULATION
            # selection_threadshold = min([len(ibir_mutants), len(pit_mutants_filtered), len(codebert_mutants_filtered)])
            selection_threadshold = min([len(ibir_mutants), len(pit_mutants_filtered), len(codebert_mutants_filtered), len(deep_mutation_mutants)])
            # selection_threadshold = min([len(codebert_mutants), len(pit_mutants_filtered)])

            ibir_run = []
            pit_run = []
            mubert_run = []
            for repetition in range(100):
                pick_ibir = random.sample(ibir_mutants, selection_threadshold)
                ochiais_pick_ibir = [m.ochiai for m in pick_ibir]
                ibir_run.append(1 if 1 in ochiais_pick_ibir else 0)

                pick_pit = random.sample(pit_mutants_filtered, selection_threadshold)
                ochiais_pick_pit = [m.ochiai for m in pick_pit]
                pit_run.append(1 if 1 in ochiais_pick_pit else 0)

                pick_mubert = random.sample(codebert_mutants_filtered, selection_threadshold)
                ochiais_pick_mubert = [m.ochiai for m in pick_mubert]
                mubert_run.append(1 if 1 in ochiais_pick_mubert else 0)

            ibir_simulation_mean = np.mean(ibir_run)
            pit_simulation_mean = np.mean(pit_run)
            mubert_simulation_mean = np.mean(mubert_run)

            print(
                f"Ibir mutants: {len(ibir_mutants)} - PitMutants: {len(pit_mutants)}-{len(pit_mutants_filtered)} - Codebert: {len(codebert_mutants)}-{len(codebert_mutants_filtered)}")

            # print(
            #     f"Ibir mutants: {len(ibir_mutants)} - PitMutants: {len(pit_mutants)}-{len(pit_mutants_filtered)} - Codebert: {len(codebert_mutants)}")

            print(f"Ibir mutants: {ibir_simulation_mean} - PitMutants: {pit_simulation_mean} - Codebert: {mubert_simulation_mean}")

            project_comparing_maps["Ibir"].append(ibir_simulation_mean)
            project_comparing_maps["Pit"].append(pit_simulation_mean)
            project_comparing_maps["Codebert"].append(mubert_simulation_mean)

            # COMPARING MUTANTS WITHOUT SIMULATION
            # ibir_ochiais = [m.ochiai for m in ibir_mutants]
            # pit_ochiais = [m.ochiai for m in pit_mutants_filtered]
            # codebert_ochiais = [m.ochiai for m in codebert_mutants_filtered]
            #
            # project_comparing_maps["Ibir"].append(1 if 1 in ibir_ochiais else 0)
            # project_comparing_maps["Pit"].append(1 if 1 in pit_ochiais else 0)
            # project_comparing_maps["Codebert"].append(1 if 1 in codebert_ochiais else 0)

    for project in project_comparing_maps:
        print(f"Project - {project}: {np.mean(project_comparing_maps[project])}")


def argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Data path")
    parser.add_argument("-p", "--path_to_data_file", action="store", help="Store directory path to parsed mutants")
    parser.add_argument("-o", "--output_dir", action="store", help="Store directory for output")
    parser.add_argument("-d", "--mutants_path_dir", action="store", help="Store path to mutants dir")
    parser.add_argument("-f", "--path_to_failing_tests_dir", action="store", help="Path to failing tests")

    return parser


if __name__ == '__main__':
    arguments = argument_parser().parse_args()

    calculate_rq_3b_simulation_deep_mutation_controlled_numbers(arguments.path_to_data_file)
    calculate_rq_3b_simulation_ibir_controlled_numbers(arguments.path_to_data_file)
    calculate_rq_3b_simulation_controlled_numbers_generic(
        arguments.path_to_data_file)  # perform simulation and sample mutants controlled by a tool with least number seeded
    calculate_rq_3b_simulation_ibir_controlled_lines(arguments.path_to_data_file, arguments.mutants_path_dir,
                                                     arguments.path_to_failing_tests_dir)  # perform simulation and sample mutants controlled by a tool with least number seeded
