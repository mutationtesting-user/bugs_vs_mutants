import argparse
import collections
import json
import random

import matplotlib
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats
import matplotlib.gridspec as gridspec
import numpy as np
import os

from matplotlib_venn import venn2_circles, venn2

from statistical_analysis import a12, wilcoxon, VD_A

import logging

logging.basicConfig(level=logging.INFO)

sns.set_theme(style="ticks")  # , palette="pastel"

technique = "PiTest"


class SeabornFig2Grid():

    def __init__(self, seaborngrid, fig, subplot_spec):
        self.fig = fig
        self.sg = seaborngrid
        self.subplot = subplot_spec
        if isinstance(self.sg, sns.axisgrid.FacetGrid) or \
                isinstance(self.sg, sns.axisgrid.PairGrid):
            self._movegrid()
        elif isinstance(self.sg, sns.axisgrid.JointGrid):
            self._movejointgrid()
        self._finalize()

    def _movegrid(self):
        """ Move PairGrid or Facetgrid """
        self._resize()
        n = self.sg.axes.shape[0]
        m = self.sg.axes.shape[1]
        self.subgrid = gridspec.GridSpecFromSubplotSpec(n, m, subplot_spec=self.subplot)
        for i in range(n):
            for j in range(m):
                self._moveaxes(self.sg.axes[i, j], self.subgrid[i, j])

    def _movejointgrid(self):
        """ Move Jointgrid """
        h = self.sg.ax_joint.get_position().height
        h2 = self.sg.ax_marg_x.get_position().height
        r = int(np.round(h / h2))
        self._resize()
        self.subgrid = gridspec.GridSpecFromSubplotSpec(r + 1, r + 1, subplot_spec=self.subplot)

        self._moveaxes(self.sg.ax_joint, self.subgrid[1:, :-1])
        self._moveaxes(self.sg.ax_marg_x, self.subgrid[0, :-1])
        self._moveaxes(self.sg.ax_marg_y, self.subgrid[1:, -1])

    def _moveaxes(self, ax, gs):
        # https://stackoverflow.com/a/46906599/4124317
        ax.remove()
        ax.figure = self.fig
        self.fig.axes.append(ax)
        self.fig.add_axes(ax)
        ax._subplotspec = gs
        ax.set_position(gs.get_position(self.fig))
        ax.set_subplotspec(gs)

    def _finalize(self):
        plt.close(self.sg.fig)
        self.fig.canvas.mpl_connect("resize_event", self._resize)
        self.fig.canvas.draw()

    def _resize(self, evt=None):
        self.sg.fig.set_size_inches(self.fig.get_size_inches())


def in_loop():
    projects = ["Lang", "Collections"]
    for project in projects:
        print("Project: ", project)
        comparison_types = ["Class Level", "Function Level"]
        for comparison_type in comparison_types:
            print("Comparison type: ", comparison_type)
            data = pd.read_csv(filepath_or_buffer=f'./execution_results/comparison_{comparison_type.replace(" ", "_").lower()}_{project}.csv')
            plotting_types = ["All", "Killed"]
            for plotting_type in plotting_types:
                print("Plotting type: ", plotting_type)
                data_1 = data.copy()
                if plotting_type == "Killed":
                    data_1 = data_1.loc[data_1['Mutant_Not_Killed'] == 0]
                filtering_styles = ["No Filter", "SemanticGT.8", "SynctacticGT.8"]
                for filtering_style in filtering_styles:
                    print("Filtering style: ", filtering_style)
                    data_2 = data_1.copy()
                    if filtering_style == "SemanticGT.8":
                        data_2 = data_2.loc[data_2['OCHIAI'] >= 0.8]
                    elif filtering_style == "SynctacticGT.8":
                        data_2 = data_2.loc[(data_2['BLEU'] >= 0.8) & (data_2['JACCARD'] >= 0.8) & (data_2['COSINE'] >= 0.8)]
                    grid_types = ["Histogram", "Box plot"]
                    for grid_type in grid_types:
                        print("Grid type: ", grid_type)
                        plot_this(data_2, project_name=project, plot_description=f"{plotting_type} Mutants {filtering_style} {comparison_type} {grid_type}",
                                  jointgrid=True if grid_type == "Box plot" else False)
                # plot_this(data, project_name="Lang", plot_description="All Mutants Joint Grid", jointgrid=True)


def test_face_grid():
    fig = plt.figure()
    gs = gridspec.GridSpec(1, 3)

    # A JointGrid
    g0 = sns.jointplot("BLEU", "OCHIAI", data=data,
                       kind="reg", color="g", space=0)
    g1 = sns.jointplot("JACCARD", "OCHIAI", data=data,
                       kind="reg", color="g", space=0)
    g2 = sns.jointplot("COSINE", "OCHIAI", data=data,
                       kind="reg", color="g", space=0)
    mg0 = SeabornFig2Grid(g0, fig, gs[0])
    mg1 = SeabornFig2Grid(g1, fig, gs[1])
    mg2 = SeabornFig2Grid(g2, fig, gs[2])
    gs.tight_layout(fig)


def plot_this(df, plot_description, project_name, filenamesuffix="ScatterPlot", jointgrid=False):
    # df = df.sort_values(['OCHIAI', 'BLEU'], ascending=True)
    # df = df.reset_index(drop=True)
    # hist_dist(df, "plot-" + technique, filenamesuffix)
    scatter_plot(df, "BLEU", "OCHIAI", f'{filenamesuffix}_bleu_ochiai', plot_description, project_name, jointgrid)
    # scatter_plot(df, "M1_M2_BLEU", "M1_M2_OCHIAI", f'{filenamesuffix}:bleu_ochiai', plot_description, project_name, jointgrid)
    # scatter_plot(df, "JACCARD_B", "OCHIAI_B", f'{filenamesuffix}:jaccard_ochiai', plot_description, project_name, jointgrid)
    # scatter_plot(df, "M1_M2_JACCARD", "M1_M2_OCHIAI", f'{filenamesuffix}:jaccard_ochiai', plot_description, project_name, jointgrid)
    # scatter_plot(df, "COSINE_B", "OCHIAI_B", f'{filenamesuffix}:cosine_ochiai', plot_description, project_name, jointgrid)
    # scatter_plot(df, "M1_M2_COSINE", "M1_M2_OCHIAI", f'{filenamesuffix}:cosine_ochiai', plot_description, project_name, jointgrid)


def scatter_plot(data, parax, paray, filenamesuffix, plot_description, project_name, jointgrid):
    if jointgrid:
        axe = sns.JointGrid(data=data, x=parax, y=paray)
        axe.plot(sns.regplot, sns.boxplot)
        # axe = sns.JointGrid(data=data, x=parax, y=paray)
        # axe.plot_joint(sns.histplot)
        # axe.plot_marginals(sns.boxplot)
    else:
        axe = sns.jointplot(data=data, x=parax, y=paray, kind="reg")
        # axe = (sns.jointplot(data=data, x=parax, y=paray, color='g').plot_joint(sns.kdeplot, zorder=0, n_levels=6))

    axe.set_axis_labels(xlabel=parax, ylabel=paray, fontsize=17)
    # axe.set_axis_labels(xlabel=f'Δ{parax.split("_")[-1]} |M2 - M1|', ylabel=f'Δ{paray.split("_")[-1]} |M2 - M1|', fontsize=12)
    pr_axeLeft, pp_axeLeft = stats.pearsonr(data[parax], data[paray])
    kr_axeLeft, kp_axeLeft = stats.kendalltau(data[parax], data[paray])

    # if you choose to write your own legend, then you should adjust the properties then
    phantom_axeLeft, = axe.ax_joint.plot([], [], linestyle="", alpha=0)
    # here graph is not a ax but a joint grid, so we access the axis through ax_joint method
    label_axeLeft = 'pearson: r={:.3f}, p={:.3f}\nkendall: r={:.3f}, p={:.3f}'.format(
        round(pr_axeLeft, 3),
        round(pp_axeLeft, 3),
        round(kr_axeLeft, 3),
        round(kp_axeLeft, 3))

    axe.ax_joint.legend([phantom_axeLeft], [label_axeLeft], fontsize="17")

    plt.tick_params(axis='both', which='minor', labelsize=16)
    plt.tight_layout()
    # plt.suptitle('Semantic vs Syntactic - ' + plot_description)
    os.makedirs(os.path.join(".", project_name), exist_ok=True)
    plt.savefig(os.path.join(".", f'{project_name}_{filenamesuffix}_{plot_description.replace(" ", "_")}.png'), format='png')
    plt.show()
    # print()


def calculate_rq_1d(data_path):
    data = pd.read_csv(filepath_or_buffer=data_path)

    syntactic_semantic_proxy_path = os.path.join(".", "RQ1_semantic_different_quartiles.csv")

    unique_projects = data["Project_ID"].unique()

    quartiles_dict = collections.defaultdict(list)
    ovarall_list = list()
    for project in unique_projects:
        project_data = data[data["Project_ID"] == project]
        project_bugs = project_data["Bug_ID"].unique()
        print("Project: ", project)
        for bug in project_bugs:
            print("\tBug: ", bug)
            bug_data = project_data[project_data["Bug_ID"] == bug]

            # bug_data[np.isclose(bug_data['BLEU_B'], 0.95, 0.001)]
            # number_of_mutants_blue_1 = len(bug_data[bug_data["BLEU_B"] == 1.0])
            # statistics.write(f'{project},{bug},{len(bug_data)},{number_of_mutants_blue_1}\n')

            bug_data = bug_data[bug_data["BLEU"] != 1.0]
            bug_data = bug_data[bug_data["OCHIAI"] != 0.0]

            bug_data_sorted = bug_data.sort_values(by="BLEU", ignore_index=True)
            Q1, Q2, Q3, Q4 = np.split(bug_data_sorted, [int(.25 * len(bug_data_sorted)), int(.5 * len(bug_data_sorted)), int(.75 * len(bug_data_sorted))])

            for row in Q1.iterrows():
                quartiles_dict["Q1"].append(row[1]['OCHIAI'])
                ovarall_list.append(row[1]['OCHIAI'])
                # syntactic_semantic_proxy_ovarall.write(f'{row[1]["OCHIAI_B"]}\n')

            for row in Q2.iterrows():
                quartiles_dict["Q2"].append(row[1]['OCHIAI'])
                ovarall_list.append(row[1]['OCHIAI'])

            for row in Q3.iterrows():
                quartiles_dict["Q3"].append(row[1]['OCHIAI'])
                ovarall_list.append(row[1]['OCHIAI'])

            for row in Q4.iterrows():
                quartiles_dict["Q4"].append(row[1]['OCHIAI'])
                ovarall_list.append(row[1]['OCHIAI'])

    quartiles_dict["Overall"] = ovarall_list

    df = pd.DataFrame({key: pd.Series(value) for key, value in quartiles_dict.items()})
    df = df[['Overall', "Q1", "Q2", "Q3", "Q4"]]
    # df = pd.DataFrame.from_dict(dict(quartiles_dict))
    df.to_csv(syntactic_semantic_proxy_path, columns=["Overall", "Q1", "Q2", "Q3", "Q4"], index=False)
    # df = pd.read_csv(open(syntactic_semantic_proxy_path))

    # df_overall = pd.read_csv(open(syntactic_semantic_proxy_overall_path))
    df["Overall"] = df["Overall"][df["Overall"] != 0.0]
    df["Q1"] = df["Q1"][df["Q1"] != 0.0]
    df["Q2"] = df["Q2"][df["Q2"] != 0.0]
    df["Q3"] = df["Q3"][df["Q3"] != 0.0]
    df["Q4"] = df["Q4"][df["Q4"] != 0.0]

    red_circle = dict(markerfacecolor='red', marker='o', markeredgecolor='white')

    fig, axes = plt.subplots(nrows=1, ncols=1)
    meanlineprops = dict(linewidth=2.5, color='purple')

    axes.boxplot([vals.dropna() for col, vals in df.iteritems()], medianprops=meanlineprops, flierprops=red_circle, labels=['Overall', "Q1", "Q2", "Q3", "Q4"],
                 showmeans=True)
    # axes = sns.boxplot(data=plot_df, palette="mako")

    # df.boxplot(ax=axes, flierprops=red_circle)

    axes.set_ylim(top=1)
    axes.set_ylabel("OCHIAI [> 0.0]", fontsize=17)
    plt.xticks(fontsize=17)
    plt.savefig(os.path.join(".", "BoxPlot_RQ1d_semantic_over_different_levels_of_syntactic.png"), format='png')
    plt.show()


def calculate_venn_diagram_intersection_of_mutants(data_path):
    data = pd.read_csv(filepath_or_buffer=data_path)

    failing_tests_df = pd.read_csv("/Volumes/My_Data_Pas/mutants_sensitivity/defects4J_bugs_failing_tests/all_faults_with_tests.csv")
    failing_tests_df['number_of_failing_tests'] = failing_tests_df.apply(lambda row: row['failing_tests'].count("::"), axis=1)

    failing_tests_df = failing_tests_df[failing_tests_df["number_of_failing_tests"] != 1]
    list_of_bugs = failing_tests_df["project_bug_id"].tolist()

    data["project_bug_id"] = data.apply(lambda row: f"{row['Project_ID']}_{row['Bug_ID']}", axis=1)
    data = data[data["project_bug_id"].isin(list_of_bugs)]

    data_filtered = data[(data["OCHIAI"] != 0) & (data["FDP"] != 0)]
    data = data_filtered[(data_filtered["OCHIAI"] == 1) | (data_filtered["FDP"] == 1)]

    data_mutants = data[["GLOBAL_ID", "OCHIAI", "FDP"]]
    # data_mutants = data_mutants.astype({'OCHIAI': 'float64', 'FDP': 'float64'})
    # data_mutants['OCHIAI'] = data_mutants['OCHIAI'].astype(int)
    # data_mutants['FDP'] = data_mutants['FDP'].astype(int)

    # data_mutants['OCHIAI'] = np.where(data_mutants['OCHIAI'] > 1, 0, data_mutants['OCHIAI'])
    # data_mutants['FDP'] = np.where(data_mutants['FDP'] > 1, 0, data_mutants['FDP'])

    MUTANTS_OCHIAI_1 = set(data_mutants[data_mutants["OCHIAI"] >= 0.8]["GLOBAL_ID"].tolist())
    MUTANTS_FDP_1 = set(data_mutants[data_mutants["FDP"] >= 0.8]["GLOBAL_ID"].tolist())

    total = len(data_mutants)

    vd2 = venn2([set(MUTANTS_OCHIAI_1), set(MUTANTS_FDP_1)], set_labels=("Mutants with OCHIAI over 0.8", "Mutants with FDP over 0.8"), set_colors=("orange", "darkgrey"), alpha=0.8,
                subset_label_formatter=lambda x: f"{(x/total):1.0%}")
                # subset_label_formatter=lambda x: str(x) + "\n(" + f"{(x/total):1.0%}" + ")")
    venn2_circles([set(MUTANTS_OCHIAI_1), set(MUTANTS_FDP_1)], linestyle="-.", linewidth=2, color="black")
    for text in vd2.set_labels:  # change label size
        text.set_fontsize(16)
    for text in vd2.subset_labels:  # change number size
        text.set_fontsize(16)

    plt.tight_layout()
    plt.savefig(os.path.join(".", f'VennDiagram_mutantsOverlapAndMetricsGreaterThan80perc_moreThanOneFailingTestBugs.png'), format='png', bbox_inches="tight")
    plt.show()

    print()


def calculate_rq_4a_venn_diagram(data_path):
    data = pd.read_csv(filepath_or_buffer=data_path)
    unique_projects = data["Project_ID"].unique()

    bug_intersection_set = []
    semantic_similarity_bug_list = collections.defaultdict(list)

    for project in unique_projects:
        project_data = data[data["Project_ID"] == project]
        project_bugs = project_data["Bug_ID"].unique()
        print("Project: ", project)

        for bug in project_bugs:
            print("\tBug: ", bug)
            bug_data = project_data[project_data["Bug_ID"] == bug]

            tools_bug = bug_data["Tool"].unique()

            if len(set(tools_bug).intersection(["pit", "ibir", "codebert", "deepmutation"])) == 4:
                bug_intersection_set.append(f'{project}_{bug}')
            else:
                continue

            # if each tool has at least one mutant that resembles the fault-bug, we label as 1
            for tool in tools_bug:
                tool_data = bug_data[bug_data["Tool"] == tool]

                number_of_mutants = len(tool_data)

                mutants_semantically_similar = tool_data[tool_data["FDP"] == 1.0]
                semantic_similarity_bug_list[tool].append(1 if len(mutants_semantically_similar) > 0 else 0)



    tool_names_list = list(semantic_similarity_bug_list.keys())
    # list_data = [semantic_similarity_bug_list[tool_name] for tool_name in tool_names_list]
    # df = pd.DataFrame(list_data, columns=tool_names_list)
    # df.to_csv(semantic_similarity_bugs_write)

    from venn import venn
    d_name = {"pit": "PiTest", "codebert": "\u03BCBERT", "ibir": "IBIR", "deepmutation": "DeepMutation"}
    d_output = dict()
    for key, value in semantic_similarity_bug_list.items():
        d_output.update({d_name[key]: set(np.nonzero(value)[0])})
    # d_output_sort = dict()
    # for name in ["DeepMutation", "IBIR", "\u03BCBERT", "PIT"]:
    #     d_output_sort.update({name:d_output[name]})
    cmaps = ["cool", list("rgb"), "plasma", "viridis", "Set1"]
    venn(d_output, fmt="{percentage:.1f}%", cmap=cmaps[4], legend_loc="lower right")
    plt.savefig(os.path.join(".", f'RQ4a_VennDiagram_Tool_intersection_at_least_one_FDP_1_mutant.png'), format='png')
    plt.show()
    print()


def calculate_rq_4_per_tool_OCHIAI(data_path):
    data = pd.read_csv(filepath_or_buffer=data_path)

    unique_projects = data["Project_ID"].unique()

    bug_intersection = []
    for project in unique_projects:
        project_data = data[data["Project_ID"] == project]
        project_bugs = project_data["Bug_ID"].unique()
        print("Project: ", project)

        for bug in project_bugs:
            print("\tBug: ", bug)
            bug_data = project_data[project_data["Bug_ID"] == bug]

            tools_bug = bug_data["Tool"].unique()

            if len(set(tools_bug).intersection(["pit", "ibir", "codebert", "deepmutation"])) == 4:
                bug_intersection.append((project, bug))
            else:
                continue

    unique_tools = data["Tool"].unique()
    tool_info = []

    for tool in unique_tools:
        tool_data = data[data["Tool"] == tool]

        sem_sim_at_least_one = []
        exactly_the_same_mutants = []
        number_of_mutants_list = []

        quartiles_dict = collections.defaultdict(list)
        ovarall_list = list()

        number_of_bugs = 0
        bugs_with_ochiai1_counter = 0
        bug_ochiai_q1 = 0
        bug_ochiai_q2 = 0
        bug_ochiai_q3 = 0
        bug_ochiai_q4 = 0

        mutants_with_ochiai_1 = []
        mutants_with_ochiai_1_q1 = []
        mutants_with_ochiai_1_q2 = []
        mutants_with_ochiai_1_q3 = []
        mutants_with_ochiai_1_q4 = []

        for project, bug in bug_intersection:
            project_bug_data = tool_data[(tool_data["Project_ID"] == project) & (tool_data["Bug_ID"] == bug)]
            print("Project: ", project, " Bug: ", bug)

            number_of_mutants = len(project_bug_data)
            number_of_bugs += 1

            # selected_rows = bug_data[~bug_data['FAILING_TESTS'].isnull()]
            number_of_exactly_syn_same_mutants = len(project_bug_data[project_bug_data["BLEU"] == 1.0])
            exactly_the_same_mutants.append(0 if number_of_exactly_syn_same_mutants == 0 else number_of_exactly_syn_same_mutants / len(project_bug_data))

            # project_bug_data = project_bug_data[project_bug_data["BLEU"] != 1.0]
            # project_bug_data = project_bug_data[project_bug_data["OCHIAI"] != 0.0]

            bug_data_sorted = project_bug_data.sort_values(by="BLEU", ignore_index=True)
            Q1, Q2, Q3, Q4 = np.split(bug_data_sorted, [int(.25 * len(bug_data_sorted)), int(.5 * len(bug_data_sorted)), int(.75 * len(bug_data_sorted))])

            # ratio of bugs with at least one sem sim mutant
            ochiai_values = project_bug_data["OCHIAI"].tolist()
            bug_has_ochiai1_mutant = False
            if 1 in ochiai_values:
                bugs_with_ochiai1_counter += 1
                bug_has_ochiai1_mutant = True
                mutants_with_ochiai_1.append(round(ochiai_values.count(1) / len(ochiai_values), 2))
            else:
                mutants_with_ochiai_1.append(0)

            # mean ratio of mutants with sem sim mutants per bug
            ochiai_q1_values = Q1['OCHIAI'].tolist()
            if 1 in ochiai_q1_values:
                bug_ochiai_q1 += 1
                mutants_with_ochiai_1_q1.append(round(ochiai_q1_values.count(1) / len(ochiai_values), 2))
            else:
                mutants_with_ochiai_1_q1.append(0)

            ochiai_q2_values = Q2['OCHIAI'].tolist()
            if 1 in ochiai_q2_values:
                bug_ochiai_q2 += 1
                mutants_with_ochiai_1_q2.append(round(ochiai_q2_values.count(1) / len(ochiai_values), 2))
            else:
                mutants_with_ochiai_1_q2.append(0)

            ochiai_q3_values = Q3['OCHIAI'].tolist()
            if 1 in ochiai_q3_values:
                bug_ochiai_q3 += 1
                mutants_with_ochiai_1_q3.append(round(ochiai_q3_values.count(1) / len(ochiai_values), 2))
            else:
                mutants_with_ochiai_1_q3.append(0)

            ochiai_q4_values = Q4['OCHIAI'].tolist()
            if 1 in ochiai_q4_values:
                bug_ochiai_q4 += 1
                mutants_with_ochiai_1_q4.append(round(ochiai_q4_values.count(1) / len(ochiai_values), 2))
            else:
                mutants_with_ochiai_1_q4.append(0)

        total = 0 if bugs_with_ochiai1_counter == 0 else bugs_with_ochiai1_counter / number_of_bugs
        tool_info.append({"Tool": tool, "Bugs": number_of_bugs, "Total": total, "Exact Matches": np.mean(exactly_the_same_mutants),
                          "At_least_one_sem_sim_m_in_Q1": 0 if bug_ochiai_q1 == 0 else bug_ochiai_q1 / number_of_bugs,
                          "At_least_one_sem_sim_m_in_Q2": 0 if bug_ochiai_q2 == 0 else bug_ochiai_q2 / number_of_bugs,
                          "At_least_one_sem_sim_m_in_Q3": 0 if bug_ochiai_q3 == 0 else bug_ochiai_q3 / number_of_bugs,
                          "At_least_one_sem_sim_m_in_Q4": 0 if bug_ochiai_q4 == 0 else bug_ochiai_q4 / number_of_bugs,
                          "Ratio_mutants_sem_sim_per_bug": np.array(mutants_with_ochiai_1).mean(),
                          "Ratio_mutants_sem_sim_per_bug_in_Q1": np.array(mutants_with_ochiai_1_q1).mean(),
                          "Ratio_mutants_sem_sim_per_bug_in_Q2": np.array(mutants_with_ochiai_1_q2).mean(),
                          "Ratio_mutants_sem_sim_per_bug_in_Q3": np.array(mutants_with_ochiai_1_q3).mean(),
                          "Ratio_mutants_sem_sim_per_bug_in_Q4": np.array(mutants_with_ochiai_1_q4).mean()
                          })

    pd.DataFrame(tool_info).to_csv("./RQ4_data_per_tool_intersection_ochiai_extended_vT.csv")
    print()


def calculate_rq_4_per_tool_FDP(data_path):
    data = pd.read_csv(filepath_or_buffer=data_path)

    unique_projects = data["Project_ID"].unique()

    bug_intersection = []
    for project in unique_projects:
        project_data = data[data["Project_ID"] == project]
        project_bugs = project_data["Bug_ID"].unique()
        print("Project: ", project)

        for bug in project_bugs:
            print("\tBug: ", bug)
            bug_data = project_data[project_data["Bug_ID"] == bug]

            tools_bug = bug_data["Tool"].unique()

            if len(set(tools_bug).intersection(["pit", "ibir", "codebert", "deepmutation"])) == 4:
                bug_intersection.append((project, bug))
            else:
                continue

    unique_tools = data["Tool"].unique()
    tool_info = []

    for tool in unique_tools:
        tool_data = data[data["Tool"] == tool]

        sem_sim_at_least_one = []
        exactly_the_same_mutants = []
        number_of_mutants_list = []

        quartiles_dict = collections.defaultdict(list)
        ovarall_list = list()

        number_of_bugs = 0
        bugs_with_fdp1_counter = 0
        bug_fdp_q1 = 0
        bug_fdp_q2 = 0
        bug_fdp_q3 = 0
        bug_fdp_q4 = 0

        mutants_with_fdp_1 = []
        mutants_with_fdp_1_q1 = []
        mutants_with_fdp_1_q2 = []
        mutants_with_fdp_1_q3 = []
        mutants_with_fdp_1_q4 = []

        for project, bug in bug_intersection:
            project_bug_data = tool_data[(tool_data["Project_ID"] == project) & (tool_data["Bug_ID"] == bug)]
            print("Project: ", project, " Bug: ", bug)

            number_of_mutants = len(project_bug_data)
            number_of_bugs += 1

            # selected_rows = bug_data[~bug_data['FAILING_TESTS'].isnull()]
            number_of_exactly_syn_same_mutants = len(project_bug_data[project_bug_data["BLEU"] == 1.0])
            exactly_the_same_mutants.append(0 if number_of_exactly_syn_same_mutants == 0 else number_of_exactly_syn_same_mutants / len(project_bug_data))

            # project_bug_data = project_bug_data[project_bug_data["BLEU"] != 1.0]
            # project_bug_data = project_bug_data[project_bug_data["OCHIAI"] != 0.0]

            bug_data_sorted = project_bug_data.sort_values(by="BLEU", ignore_index=True)
            Q1, Q2, Q3, Q4 = np.split(bug_data_sorted, [int(.25 * len(bug_data_sorted)), int(.5 * len(bug_data_sorted)), int(.75 * len(bug_data_sorted))])

            # ratio of bugs with at least one sem sim mutant
            fdp_values = project_bug_data["FDP"].tolist()
            bug_has_fdp1_mutant = False
            if 1 in fdp_values:
                bugs_with_fdp1_counter += 1
                bug_has_fdp1_mutant = True
                mutants_with_fdp_1.append(round(fdp_values.count(1) / len(fdp_values), 2))
            else:
                mutants_with_fdp_1.append(0)

            # mean ratio of mutants with sem sim mutants per bug
            fdp_q1_values = Q1['FDP'].tolist()
            if 1 in fdp_q1_values:
                bug_fdp_q1 += 1
                mutants_with_fdp_1_q1.append(round(fdp_q1_values.count(1) / len(fdp_values), 2))
            else:
                mutants_with_fdp_1_q1.append(0)

            fdp_q2_values = Q2['FDP'].tolist()
            if 1 in fdp_q2_values:
                bug_fdp_q2 += 1
                mutants_with_fdp_1_q2.append(round(fdp_q2_values.count(1) / len(fdp_values), 2))
            else:
                mutants_with_fdp_1_q2.append(0)

            fdp_q3_values = Q3['FDP'].tolist()
            if 1 in fdp_q3_values:
                bug_fdp_q3 += 1
                mutants_with_fdp_1_q3.append(round(fdp_q3_values.count(1) / len(fdp_values), 2))
            else:
                mutants_with_fdp_1_q3.append(0)

            fdp_q4_values = Q4['FDP'].tolist()
            if 1 in fdp_q4_values:
                bug_fdp_q4 += 1
                mutants_with_fdp_1_q4.append(round(fdp_q4_values.count(1) / len(fdp_values), 2))
            else:
                mutants_with_fdp_1_q4.append(0)

        total = 0 if bugs_with_fdp1_counter == 0 else bugs_with_fdp1_counter / number_of_bugs
        tool_info.append({"Tool": tool, "Bugs": number_of_bugs, "Total": total, "Exact Matches": np.mean(exactly_the_same_mutants),
                          "At_least_one_sem_sim_m_in_Q1": 0 if bug_fdp_q1 == 0 else bug_fdp_q1 / number_of_bugs,
                          "At_least_one_sem_sim_m_in_Q2": 0 if bug_fdp_q2 == 0 else bug_fdp_q2 / number_of_bugs,
                          "At_least_one_sem_sim_m_in_Q3": 0 if bug_fdp_q3 == 0 else bug_fdp_q3 / number_of_bugs,
                          "At_least_one_sem_sim_m_in_Q4": 0 if bug_fdp_q4 == 0 else bug_fdp_q4 / number_of_bugs,
                          "Ratio_mutants_sem_sim_per_bug": np.array(mutants_with_fdp_1).mean(),
                          "Ratio_mutants_sem_sim_per_bug_in_Q1": np.array(mutants_with_fdp_1_q1).mean(),
                          "Ratio_mutants_sem_sim_per_bug_in_Q2": np.array(mutants_with_fdp_1_q2).mean(),
                          "Ratio_mutants_sem_sim_per_bug_in_Q3": np.array(mutants_with_fdp_1_q3).mean(),
                          "Ratio_mutants_sem_sim_per_bug_in_Q4": np.array(mutants_with_fdp_1_q4).mean()
                          })

    pd.DataFrame(tool_info).to_csv("./RQ4_data_per_tool_intersection_fdp_extended.csv")
    print()


def calculate_rq_3_FDP(data_path):
    data = pd.read_csv(filepath_or_buffer=data_path)

    unique_projects = data["Project_ID"].unique()

    project_info = []

    for project in unique_projects:
        project_data = data[data["Project_ID"] == project]
        project_bugs = project_data["Bug_ID"].unique()
        print("Project: ", project)

        sem_subsumption_at_least_one = []
        exactly_the_same_mutants = []
        number_of_mutants_list = []

        quartiles_dict = collections.defaultdict(list)
        ovarall_list = list()

        number_of_bugs = len(project_bugs)
        bugs_with_fdp1_counter = 0
        bug_fdp_q1 = 0
        bug_fdp_q2 = 0
        bug_fdp_q3 = 0
        bug_fdp_q4 = 0

        mutants_with_fdp_1 = []
        mutants_with_fdp_1_q1 = []
        mutants_with_fdp_1_q2 = []
        mutants_with_fdp_1_q3 = []
        mutants_with_fdp_1_q4 = []

        for bug in project_bugs:
            print("\tBug: ", bug)
            bug_data = project_data[project_data["Bug_ID"] == bug]
            number_of_mutants = len(bug_data)

            selected_rows = bug_data[~bug_data['FAILING_TESTS'].isnull()]
            number_of_exactly_syn_same_mutants = len(selected_rows[selected_rows["BLEU"] == 1.0])
            exactly_the_same_mutants.append(0 if number_of_exactly_syn_same_mutants == 0 else number_of_exactly_syn_same_mutants / len(bug_data))

            sem_subsumption_at_least_one.append(1 if len(bug_data[bug_data["FDP"] == 1.0]) > 0 else 0)

            bug_data = bug_data[bug_data["BLEU"] != 1.0]
            bug_data = bug_data[bug_data["FDP"] != 0.0]

            bug_data_sorted = bug_data.sort_values(by="BLEU", ignore_index=True)
            Q1, Q2, Q3, Q4 = np.split(bug_data_sorted, [int(.25 * len(bug_data_sorted)), int(.5 * len(bug_data_sorted)), int(.75 * len(bug_data_sorted))])

            # rq3-a
            fdp_values = bug_data["FDP"].tolist()
            bug_has_fdp1_mutant = False
            if 1 in fdp_values:
                bugs_with_fdp1_counter += 1
                bug_has_fdp1_mutant = True
                mutants_with_fdp_1.append(round(fdp_values.count(1) / len(fdp_values), 2))
            else:
                mutants_with_fdp_1.append(0)

            # if not bug_has_ochiai1_mutant:
            #     continue

            # FOR RQ3_b
            fdp_q1_values = Q1['FDP'].tolist()
            if 1 in fdp_q1_values:
                bug_fdp_q1 += 1
                mutants_with_fdp_1_q1.append(round(fdp_q1_values.count(1) / len(fdp_values), 2))
            else:
                mutants_with_fdp_1_q1.append(0)

            fdp_q2_values = Q2['FDP'].tolist()
            if 1 in fdp_q2_values:
                bug_fdp_q2 += 1
                mutants_with_fdp_1_q2.append(round(fdp_q2_values.count(1) / len(fdp_values), 2))
            else:
                mutants_with_fdp_1_q2.append(0)

            fdp_q3_values = Q3['FDP'].tolist()
            if 1 in fdp_q3_values:
                bug_fdp_q3 += 1
                mutants_with_fdp_1_q3.append(round(fdp_q3_values.count(1) / len(fdp_values), 2))
            else:
                mutants_with_fdp_1_q3.append(0)

            fdp_q4_values = Q4['FDP'].tolist()
            if 1 in fdp_q4_values:
                bug_fdp_q4 += 1
                mutants_with_fdp_1_q4.append(round(fdp_q4_values.count(1) / len(fdp_values), 2))
            else:
                mutants_with_fdp_1_q4.append(0)

            q1_mutants_with_fdp1_count = fdp_q1_values.count(1)
            q2_mutants_with_fdp1_count = fdp_q2_values.count(1)
            q3_mutants_with_fdp1_count = fdp_q3_values.count(1)
            q4_mutants_with_fdp1_count = fdp_q4_values.count(1)
            mutants_count = q1_mutants_with_fdp1_count + q2_mutants_with_fdp1_count + q3_mutants_with_fdp1_count + q4_mutants_with_fdp1_count

        print("Statistics for RQ3a:")
        print("Ratio of bugs with at least 1 mutant with FDP == 1:    ", 0 if bugs_with_fdp1_counter == 0 else bugs_with_fdp1_counter / number_of_bugs)
        print("Ratio of bugs with at least 1 mutant in Q1 with FDP == 1:    ", 0 if bug_fdp_q1 == 0 else bug_fdp_q1 / number_of_bugs)
        print("Ratio of bugs with at least 1 mutant in Q2 with FDP == 1:    ", 0 if bug_fdp_q2 == 0 else bug_fdp_q2 / number_of_bugs)
        print("Ratio of bugs with at least 1 mutant in Q3 with FDP == 1:    ", 0 if bug_fdp_q3 == 0 else bug_fdp_q3 / number_of_bugs)
        print("Ratio of bugs with at least 1 mutant in Q4 with FDP == 1:    ", 0 if bug_fdp_q4 == 0 else bug_fdp_q4 / number_of_bugs)

        print("Statistics for RQ3b:")
        print("Ratio of mutants with FDP == 1 per bug:    ", np.array(mutants_with_fdp_1).mean())
        print("Ratio of mutants with FDP == 1 in Q1 with FDP == 1:    ", np.array(mutants_with_fdp_1_q1).mean())
        print("Ratio of mutants with FDP == 1 in Q2 with FDP == 1:    ", np.array(mutants_with_fdp_1_q2).mean())
        print("Ratio of mutants with FDP == 1 in Q3 with FDP == 1:    ", np.array(mutants_with_fdp_1_q3).mean())
        print("Ratio of mutants with FDP == 1 in Q4 with FDP == 1:    ", np.array(mutants_with_fdp_1_q4).mean())

        total = 0 if bugs_with_fdp1_counter == 0 else bugs_with_fdp1_counter / number_of_bugs
        project_info.append({"Project": project, "Bugs": len(project_bugs), "Total": total, "Exact Matches": np.mean(exactly_the_same_mutants),
                             "At_least_one_sem_subsumed_m_in_Q1": 0 if bug_fdp_q1 == 0 else bug_fdp_q1 / number_of_bugs,
                             "At_least_one_sem_subsumed_m_in_Q2": 0 if bug_fdp_q2 == 0 else bug_fdp_q2 / number_of_bugs,
                             "At_least_one_sem_subsumed_m_in_Q3": 0 if bug_fdp_q3 == 0 else bug_fdp_q3 / number_of_bugs,
                             "At_least_one_sem_subsumed_m_in_Q4": 0 if bug_fdp_q4 == 0 else bug_fdp_q4 / number_of_bugs,
                             "Ratio_mutants_sem_subsumed_per_bug": np.array(mutants_with_fdp_1).mean(),
                             "Ratio_mutants_sem_subsumed_per_bug_in_Q1": np.array(mutants_with_fdp_1_q1).mean(),
                             "Ratio_mutants_sem_subsumed_per_bug_in_Q2": np.array(mutants_with_fdp_1_q2).mean(),
                             "Ratio_mutants_sem_subsumed_per_bug_in_Q3": np.array(mutants_with_fdp_1_q3).mean(),
                             "Ratio_mutants_sem_subsumed_per_bug_in_Q4": np.array(mutants_with_fdp_1_q4).mean()
                             })

    print()
    pd.DataFrame(project_info).to_csv("./RQ3_semantic_subsumption_fdp_extended.csv")


"""
    Calculate ratio of bugs per project
        - with at least one semantic similar mutant
        - ratio of bugs with at least one semantically similar mutants per syntactical quartiles
        - ratio of mutants that resemble the fault
        - ratio of mutants per that resemble the fault per syntactical quartiles
"""


def calculate_rq_2_OCHIAI(data_path):
    data = pd.read_csv(filepath_or_buffer=data_path)

    syntactic_semantic_proxy_path = os.path.join(".", "RQ2_bug_fix.csv")
    # syntactic_semantic_proxy = open(syntactic_semantic_proxy_path, "a+")
    # if os.stat(syntactic_semantic_proxy_path).st_size == 0:
    #     syntactic_semantic_proxy.write("Overall,Q1,Q2,Q3,Q4\n")

    unique_projects = data["Project_ID"].unique()

    project_info = []

    for project in unique_projects:
        project_data = data[data["Project_ID"] == project]
        project_bugs = project_data["Bug_ID"].unique()
        print("Project: ", project)

        sem_sim_at_least_one = []
        exactly_the_same_mutants = []
        number_of_mutants_list = []

        quartiles_dict = collections.defaultdict(list)
        ovarall_list = list()

        number_of_bugs = len(project_bugs)
        bugs_with_ochiai1_counter = 0
        bug_ochiai_q1 = 0
        bug_ochiai_q2 = 0
        bug_ochiai_q3 = 0
        bug_ochiai_q4 = 0

        mutants_with_ochiai_1 = []
        mutants_with_ochiai_1_q1 = []
        mutants_with_ochiai_1_q2 = []
        mutants_with_ochiai_1_q3 = []
        mutants_with_ochiai_1_q4 = []

        for bug in project_bugs:
            print("\tBug: ", bug)
            bug_data = project_data[project_data["Bug_ID"] == bug]
            number_of_mutants = len(bug_data)

            selected_rows = bug_data[~bug_data['FAILING_TESTS'].isnull()]
            number_of_exactly_syn_same_mutants = len(selected_rows[selected_rows["BLEU"] == 1.0])
            exactly_the_same_mutants.append(0 if number_of_exactly_syn_same_mutants == 0 else number_of_exactly_syn_same_mutants / len(bug_data))

            sem_sim_at_least_one.append(1 if len(bug_data[bug_data["OCHIAI"] == 1.0]) > 0 else 0)

            bug_data = bug_data[bug_data["BLEU"] != 1.0]
            # bug_data = bug_data[bug_data["OCHIAI"] != 0.0]

            bug_data_sorted = bug_data.sort_values(by="BLEU", ignore_index=True)
            Q1, Q2, Q3, Q4 = np.split(bug_data_sorted, [int(.25 * len(bug_data_sorted)), int(.5 * len(bug_data_sorted)), int(.75 * len(bug_data_sorted))])

            # rq3-a
            ochiai_values = bug_data["OCHIAI"].tolist()
            bug_has_ochiai1_mutant = False
            if 1 in ochiai_values:
                bugs_with_ochiai1_counter += 1
                bug_has_ochiai1_mutant = True
                mutants_with_ochiai_1.append(round(ochiai_values.count(1) / len(ochiai_values), 2))
            else:
                mutants_with_ochiai_1.append(0)

            # if not bug_has_ochiai1_mutant:
            #     continue

            # FOR RQ3_b
            ochiai_q1_values = Q1['OCHIAI'].tolist()
            if 1 in ochiai_q1_values:
                bug_ochiai_q1 += 1
                mutants_with_ochiai_1_q1.append(round(ochiai_q1_values.count(1) / len(ochiai_values), 2))
            else:
                mutants_with_ochiai_1_q1.append(0)

            ochiai_q2_values = Q2['OCHIAI'].tolist()
            if 1 in ochiai_q2_values:
                bug_ochiai_q2 += 1
                mutants_with_ochiai_1_q2.append(round(ochiai_q2_values.count(1) / len(ochiai_values), 2))
            else:
                mutants_with_ochiai_1_q2.append(0)

            ochiai_q3_values = Q3['OCHIAI'].tolist()
            if 1 in ochiai_q3_values:
                bug_ochiai_q3 += 1
                mutants_with_ochiai_1_q3.append(round(ochiai_q3_values.count(1) / len(ochiai_values), 2))
            else:
                mutants_with_ochiai_1_q3.append(0)

            ochiai_q4_values = Q4['OCHIAI'].tolist()
            if 1 in ochiai_q4_values:
                bug_ochiai_q4 += 1
                mutants_with_ochiai_1_q4.append(round(ochiai_q4_values.count(1) / len(ochiai_values), 2))
            else:
                mutants_with_ochiai_1_q4.append(0)

            q1_mutants_with_ochiai1_count = ochiai_q1_values.count(1)
            q2_mutants_with_ochiai1_count = ochiai_q2_values.count(1)
            q3_mutants_with_ochiai1_count = ochiai_q3_values.count(1)
            q4_mutants_with_ochiai1_count = ochiai_q4_values.count(1)
            mutants_count = q1_mutants_with_ochiai1_count + q2_mutants_with_ochiai1_count + q3_mutants_with_ochiai1_count + q4_mutants_with_ochiai1_count

        print("Statistics for RQ2a:")
        print("Ratio of bugs with at least 1 mutant with OCHIAI == 1:    ", 0 if bugs_with_ochiai1_counter == 0 else bugs_with_ochiai1_counter / number_of_bugs)
        print("Ratio of bugs with at least 1 mutant in Q1 with OCHIAI == 1:    ", 0 if bug_ochiai_q1 == 0 else bug_ochiai_q1 / number_of_bugs)
        print("Ratio of bugs with at least 1 mutant in Q2 with OCHIAI == 1:    ", 0 if bug_ochiai_q2 == 0 else bug_ochiai_q2 / number_of_bugs)
        print("Ratio of bugs with at least 1 mutant in Q3 with OCHIAI == 1:    ", 0 if bug_ochiai_q3 == 0 else bug_ochiai_q3 / number_of_bugs)
        print("Ratio of bugs with at least 1 mutant in Q4 with OCHIAI == 1:    ", 0 if bug_ochiai_q4 == 0 else bug_ochiai_q4 / number_of_bugs)

        print("Statistics for RQ2b:")
        print("Ratio of mutants with OCHIAI == 1 per bug:    ", np.array(mutants_with_ochiai_1).mean())
        print("Ratio of mutants with OCHIAI == 1 in Q1 with OCHIAI == 1:    ", np.array(mutants_with_ochiai_1_q1).mean())
        print("Ratio of mutants with OCHIAI == 1 in Q2 with OCHIAI == 1:    ", np.array(mutants_with_ochiai_1_q2).mean())
        print("Ratio of mutants with OCHIAI == 1 in Q3 with OCHIAI == 1:    ", np.array(mutants_with_ochiai_1_q3).mean())
        print("Ratio of mutants with OCHIAI == 1 in Q4 with OCHIAI == 1:    ", np.array(mutants_with_ochiai_1_q4).mean())

        total = 0 if bugs_with_ochiai1_counter == 0 else bugs_with_ochiai1_counter / number_of_bugs
        project_info.append({"Project": project, "Bugs": len(project_bugs), "Total": total, "Exact Matches": np.mean(exactly_the_same_mutants),
                             "At_least_one_sem_sim_m_in_Q1": 0 if bug_ochiai_q1 == 0 else bug_ochiai_q1 / number_of_bugs,
                             "At_least_one_sem_sim_m_in_Q2": 0 if bug_ochiai_q2 == 0 else bug_ochiai_q2 / number_of_bugs,
                             "At_least_one_sem_sim_m_in_Q3": 0 if bug_ochiai_q3 == 0 else bug_ochiai_q3 / number_of_bugs,
                             "At_least_one_sem_sim_m_in_Q4": 0 if bug_ochiai_q4 == 0 else bug_ochiai_q4 / number_of_bugs,
                             "Ratio_mutants_sem_sim_per_bug": np.array(mutants_with_ochiai_1).mean(),
                             "Ratio_mutants_sem_sim_per_bug_in_Q1": np.array(mutants_with_ochiai_1_q1).mean(),
                             "Ratio_mutants_sem_sim_per_bug_in_Q2": np.array(mutants_with_ochiai_1_q2).mean(),
                             "Ratio_mutants_sem_sim_per_bug_in_Q3": np.array(mutants_with_ochiai_1_q3).mean(),
                             "Ratio_mutants_sem_sim_per_bug_in_Q4": np.array(mutants_with_ochiai_1_q4).mean()
                             })

    print()
    pd.DataFrame(project_info).to_csv("./RQ2_semantic_resemblence_ochiai_extended_vT.csv")


"""
    Old function to plot semantic similarity over different levels of syntactic similarity
"""


def plot_semantic_similarity_over_different_levels_of_syntactic_similarity():
    syntactic_semantic_proxy_path = os.path.join("./plots/RQ3", "RQ3_b_over_total_mutants_per_bug_without_bleu.csv")

    df = pd.read_csv(open(syntactic_semantic_proxy_path))

    print(df.columns)
    # df = df[df["Overall"] != 0.0]
    # df = df[df["Q1"] != 0.0]
    # df = df[df["Q2"] != 0.0]
    # df = df[df["Q3"] != 0.0]
    # df = df[df["Q4"] != 0.0]
    # df = df.loc[(df != 0).any(axis=1)]

    # df_overall = df_overall.loc[(df_overall != 0).any(axis=1)]
    # df = df.dropna(how='all')
    # df["Overall"] = pd.Series(df_overall["Overall"].to_numpy())

    df = df[['Overall', "Q1", "Q2", "Q3", "Q4"]]

    fig, axes = plt.subplots(nrows=1, ncols=1)

    # axes = sns.boxplot(data=plot_df, palette="mako")
    # axes.set_ylim(top=1)
    df.boxplot(ax=axes)

    # axes.set_ylim(top=1)
    axes.set_ylabel("Semantically Same Mutants (%)")

    # plt.savefig(os.path.join(".", "Box_plot:RQ3b_over_total_mutants_per_bug_without_blue1.pdf"),
    #             format='pdf')
    # plt.savefig(os.path.join(".", "Box_plot:RQ3b_over_total_mutants_per_bug_without_blue1.png"),
    #             format='png')

    print(f'Median (Overall,Q1,Q2,Q3,Q4): {df["Overall"].median()},{df["Q1"].median()},{df["Q2"].median()},{df["Q3"].median()},{df["Q4"].median()}')
    print(f'Mean (Overall,Q1,Q2,Q3,Q4): {df["Overall"].mean()},{df["Q1"].mean()},{df["Q2"].mean()},{df["Q3"].mean()},{df["Q4"].mean()}')

    plt.show()


"""
    Old function that computes difference between semantic and syntactic on different granurality levels
"""


def plot_difference_between_semantic_and_syntactic_on_different_granurality_levels():
    data = pd.read_csv(filepath_or_buffer="./comparison_class_level_2_version_Total.csv")
    data["Syntactic_Distance"] = 1 - data["BLEU_F"]

    data = data[data["FAILING_TESTS"] != 0]

    q = data["FAILING_TESTS"].quantile(0.99)
    print(q)
    data = data[data["FAILING_TESTS"] < q]

    # q_distance = data["Syntactic_Distance"].quantile(0.99)
    # print(q_distance)
    # data = data[data["Syntactic_Distance"] < q_distance]

    # z_scores = stats.zscore(dataT)
    # abs_z_scores = np.abs(z_scores)
    # filtered_entries = (abs_z_scores < 3).all(axis=1)
    # data = dataT[filtered_entries]

    axe = sns.JointGrid(data=data, x="Syntactic_Distance", y="FAILING_TESTS")
    axe.plot(sns.regplot, sns.boxplot)
    regline = axe.ax_joint.get_lines()[0]
    regline.set_color('red')
    regline.set_zorder(5)

    axe.set_axis_labels(xlabel="Syntactic Distance (1 - BLEU)", ylabel="Failing tests (#)", fontsize=12)
    pr_axeLeft, pp_axeLeft = stats.pearsonr(data["Syntactic_Distance"], data["FAILING_TESTS"])
    kr_axeLeft, kp_axeLeft = stats.kendalltau(data["Syntactic_Distance"], data["FAILING_TESTS"])
    phantom_axeLeft, = axe.ax_joint.plot([], [], linestyle="", alpha=0)
    label_axeLeft = 'pearson: r={:f}, p={:f}\nkendall: r={:f}, p={:f}'.format(pr_axeLeft, pp_axeLeft, kr_axeLeft, kp_axeLeft)
    axe.ax_joint.legend([phantom_axeLeft], [label_axeLeft])
    plt.tight_layout()
    # plt.suptitle('Semantic vs Syntactic - ' + plot_description)
    os.makedirs(os.path.join("plots", "RQ4"), exist_ok=True)
    plt.savefig(os.path.join("plots", "RQ4", f'{"Scatter-Plot-PIT:syntactic_distance_BLEU_filtered_outliers"}:{"failing_tests"}.png'), format='png', dpi=1200)
    plt.savefig(os.path.join("plots", "RQ4", f'{"Scatter-Plot-PIT:syntactic_distance_BLEU_filtered_outliers"}:{"failing_tests"}.pdf'), format='pdf', dpi=1200)
    plt.show()


def plot_sem_syn_comparison():
    # data = pd.read_csv(filepath_or_buffer="./comparison_class_level_2_version_Total.csv")
    data = pd.read_csv(filepath_or_buffer="./comparison_function_level_2_version_Total.csv")
    # data = pd.read_csv(filepath_or_buffer="./comparison_changed_lines_mutants_difference_2_version.csv")
    # data = pd.read_csv(filepath_or_buffer="./comparison_random_mutants_difference_2_version.csv")

    plotting_type = "All"
    # plotting_type = "Changed Lines"
    # plotting_type = "Random Lines"
    filtering_style = "No Filter"  # "No Filter", "SemanticGT_8", "SynctacticGT_8"
    # comparison_type = ""
    comparison_type = "Function Level"
    # grid_type = "Histogram"
    grid_type = "Box plot_updated"

    data = data.loc[data['Mutant_Not_Killed'] == 0]
    data = data.loc[(data['BLEU_B'] >= 0.8) & (data['JACCARD_B'] >= 0.8) & (data['COSINE_B'] >= 0.8)]

    plot_this(data, project_name="RQ1", plot_description=f"{plotting_type} Mutants {filtering_style} {comparison_type} {grid_type}",
              jointgrid=True if grid_type == "Box plot_updated" else False)

    plot_this(data, project_name="Lang", plot_description="All Killed Mutants")
    plot_this(data, project_name="Lang", plot_description="All Killed Mutants Joint Grid", jointgrid=True)

    df_sem_gt80p = data.loc[data['OCHIAI'] >= 0.8]
    plot_this(df_sem_gt80p, "sem-gt80p")

    # plot_this(df_syn_gt80p, "syn-gt80p")

    df_mutants_killed_sem_gt80p = data.loc[data['OCHIAI'] >= 0.8]
    plot_this(df_mutants_killed_sem_gt80p, "mutants_killed_sem-gt80p")

    df_mutants_killed_syn_gt80p = data.loc[(data['BLEU'] >= 0.8) & (data['JACCARD'] >= 0.8) & (data['COSINE'] >= 0.8)]
    plot_this(df_mutants_killed_syn_gt80p, "mutants_killed_syn-gt80p")

    data = pd.read_csv(filepath_or_buffer="./comparison_function_level_total.csv")

    print(data.head)
    plot_this(data, "patch-based-all")

    df_sem_gt80p_function = data.loc[data['OCHIAI'] >= 0.8]
    plot_this(df_sem_gt80p_function, "sem-gt80p-functions")

    df_syn_gt80p_function = data.loc[(data['BLEU'] >= 0.8) & (data['JACCARD'] >= 0.8) & (data['COSINE'] >= 0.8)]
    plot_this(df_syn_gt80p_function, "syn-gt80p-functions")

    df_mutants_killed_function = data.loc[data['Mutant_Not_Killed'] == 0]
    plot_this(df_mutants_killed_function, "mutants_killed_function")

    df_mutants_killed_sem_gt80p_function = df_mutants_killed_function.loc[df_mutants_killed_function['OCHIAI'] >= 0.8]
    plot_this(df_mutants_killed_sem_gt80p_function, "mutants_killed_function_sem-gt80p")

    df_mutants_killed_syn_gt80p_function = df_mutants_killed_function.loc[
        (df_mutants_killed_function['BLEU'] >= 0.8) & (df_mutants_killed_function['JACCARD'] >= 0.8) & (df_mutants_killed_function['COSINE'] >= 0.8)]
    plot_this(df_mutants_killed_syn_gt80p_function, "mutants_killed_function_syn-gt80p")


def argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Data path")
    parser.add_argument("-p", "--path_to_data_file", action="store", help="Store directory path to parsed mutants")
    parser.add_argument("-o", "--output_dir", action="store", help="Store directory for output")
    parser.add_argument("-b", "--bugs_id_split_file", action="store", help="Store file for bugs ids")
    parser.add_argument("-n", "--tool_name", action="store", help="Store name of a tool")
    parser.add_argument("-m", "--mutants_pool", action="store", help="Store number of mutants")
    parser.add_argument("-d", "--mutants_path_dir", action="store", help="Store path to mutants dir")
    parser.add_argument("-f", "--path_to_failing_tests_dir", action="store", help="Path to failing tests")

    return parser


def plot_rq1a(data_path):
    data = pd.read_csv(filepath_or_buffer=data_path)

    # data = data.loc[data['Mutant_Not_Killed'] == 0]

    plot_this(data, project_name="RQ1a", plot_description="All_NoFilter_Class", jointgrid=True)


def plot_rq1b(data_path):
    data = pd.read_csv(filepath_or_buffer=data_path)

    df_syn_gt80p_function = data.loc[(data['BLEU'] >= 0.8) & (data['JACCARD'] >= 0.8) & (data['COSINE'] >= 0.8)]
    plot_this(df_syn_gt80p_function, project_name="RQ1b", plot_description="All_SynctacticGT8_Class", jointgrid=True)


def plot_rq1c(data_path):
    data = pd.read_csv(filepath_or_buffer=data_path)

    # load patch_based_mutants.csv patch_based_mutants["Project"] + patch_based_mutants["Bug_ID"]
    # for a function level
    patch_based_mutants = pd.read_csv("./data/patch_based_mutants.csv")
    data_extract_dict = collections.defaultdict(list)
    projects = patch_based_mutants["Project"].unique()
    for project in projects:
        project_data = patch_based_mutants[patch_based_mutants["Project"] == project]
        bugs = project_data["Bug_ID"].unique()
        for bug in bugs:
            bug_data = project_data[project_data["Bug_ID"] == bug]

            # bug_data['Tool'].replace('mubert', 'codebert', inplace=True)
            method_mutants_indexes = bug_data["Mutant_ID"].tolist()
            method_mutants_tool = bug_data["Tool"].tolist()

            method_mutants_compare = [f'{t}{i}' for t, i in zip(method_mutants_tool, method_mutants_indexes)]

            method_mutants_data = data[(data["Project_ID"] == project) & (data["Bug_ID"] == bug)]

            method_mutants_data["Id"] = method_mutants_data["Tool"] + method_mutants_data["Mutant_ID"].astype(str)

            method_mutants = method_mutants_data[method_mutants_data["Id"].isin(method_mutants_compare)]

            data_extract_dict["OCHIAI"].extend(method_mutants["OCHIAI"].tolist())
            data_extract_dict["BLEU"].extend(method_mutants["BLEU"].tolist())
            data_extract_dict["COSINE"].extend(method_mutants["COSINE"].tolist())
            data_extract_dict["JACCARD"].extend(method_mutants["JACCARD"].tolist())

    load_pit_data = pd.read_csv("./data/comparison_function_level_2_version_Total.csv")

    data_extract_dict["OCHIAI"].extend(load_pit_data["OCHIAI_B"].tolist())
    data_extract_dict["BLEU"].extend(load_pit_data["BLEU_B"].tolist())
    data_extract_dict["COSINE"].extend(load_pit_data["COSINE_B"].tolist())
    data_extract_dict["JACCARD"].extend(load_pit_data["JACCARD_B"].tolist())

    function_level_data = pd.DataFrame(data_extract_dict, columns=["OCHIAI", "BLEU", "COSINE", "JACCARD"])

    plot_this(function_level_data, project_name="RQ1c", plot_description="function_level_data", jointgrid=True)


if __name__ == '__main__':
    arguments = argument_parser().parse_args()

    # ============= RQ PLOTS
    print()
    # plot_rq1a(arguments.path_to_data_file)  # create scatter plots of correlations between different metrics
    # plot_rq1b(arguments.path_to_data_file)  # create scatter plots of correlations between different metrics
    # plot_rq1c(arguments.path_to_data_file)  # create scatter plots of correlations between different metrics
    # calculate_rq_1d(arguments.path_to_data_file)  # create box plot of semantic similarity over different levels of syntactic similarity

    calculate_rq_2_OCHIAI(arguments.path_to_data_file)  # Calculate ratio of bugs per project with at least one semantically similar mutant and mean ratio of mutants
    # calculate_rq_3_FDP(arguments.path_to_data_file)  # Calculate ratio of bugs per project with at least one semantically similar mutant and mean ratio of mutants
    # calculate_rq_4_per_tool_OCHIAI(arguments.path_to_data_file)  # Calculate ratio of bugs per tool with at least one semantically similar mutant and mean ratio of mutants
    # calculate_rq_4_per_tool_FDP(arguments.path_to_data_file)  # Calculate ratio of bugs per tool with at least one semantically similar mutant and mean ratio of mutants
    # calculate_rq_4a_venn_diagram(arguments.path_to_data_file)  # from intersection of bugs analysed by tools, calculate overlapping of faults
    # calculate_venn_diagram_intersection_of_mutants(arguments.path_to_data_file)  # from intersection of bugs analysed by tools, calculate overlapping of faults
