import argparse
import collections
import logging
import os
import random

from sklearn import metrics

logging.basicConfig(level=logging.INFO)

import pandas as pd
import numpy as np


def argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Extract mutants info")
    parser.add_argument("-d", "--big_all_matrices_path", action="store", help="Store a file with statistics data of all tools")
    parser.add_argument("-o", "--output_file_path", action="store", help="Output file path")

    return parser


class Mutant(object):

    def __init__(self):
        self.mutant_ID = ""
        self.killingTests = frozenset()

        self.mutant_embedded_id = ""
        self.ochiai = 0.0
        self.jaccard = ""
        self.cosine = ""
        self.bleu = ""
        self.reviling_prob = 0.0

    def __ne__(self, other):
        return (not isinstance(other, type(self))
                or self.mutant_ID != other.mutant_ID)

    def __eq__(self, othr):
        return (isinstance(othr, type(self))
                and self.mutant_ID == othr.mutant_ID)

    def __hash__(self):
        return hash(self.mutant_ID)


def parse_mutant(mutant_id, mutant_killing_tests, bug_failing_tests):
    m = Mutant()
    m.mutant_ID = f'M_{mutant_id}'
    m.killingTests = set(mutant_killing_tests)

    m.ochiai = get_ochia_score(brokenTestsByBug=set(bug_failing_tests), brokenTestsByMutant=set(mutant_killing_tests))
    m.reviling_prob = fault_reviling_prob(set(bug_failing_tests), set(m.killingTests))

    return m


def get_ochia_score(brokenTestsByBug: set, brokenTestsByMutant: set):
    assert brokenTestsByBug != None and len(brokenTestsByBug) != 0
    if brokenTestsByMutant == None or len(brokenTestsByMutant) == 0: return 0;
    intersectionSet = brokenTestsByBug.intersection(brokenTestsByMutant)
    prod = len(brokenTestsByBug) * len(brokenTestsByMutant)
    if prod == 0 or len(intersectionSet) == 0: return 0
    return len(intersectionSet) / np.sqrt(prod)


def fault_reviling_prob(brokenTestsByBug: set, brokenTestsByMutant: set):
    assert brokenTestsByBug != None and len(brokenTestsByBug) != 0
    if brokenTestsByMutant == None or len(brokenTestsByMutant) == 0: return 0.0;
    intersectionSet = brokenTestsByBug.intersection(brokenTestsByMutant)
    prod = len(brokenTestsByMutant)
    if prod == 0 or len(intersectionSet) == 0: return 0.0
    return len(intersectionSet) / prod


def sample_all_killed_tests(mutants):
    set_of_tests = set()
    for mutant in mutants:
        for test in mutant.killingTests:
            set_of_tests.add(test)
    return set_of_tests


def mutation_score_with_tests(list_of_mutants, tests):
    survived = 0
    killed = 0
    for mutant in list_of_mutants:
        killing_tests = mutant.killingTests
        if len(killing_tests.intersection(tests)) > 0:
            killed += 1
        else:
            survived += 1
    if survived == 0 and killed == 0:
        return "No mutants"
    else:
        return round(killed / (survived + killed) * 100, 2)


def mutation_score_weighted_semantic(list_of_mutants, tests):
    survived = 0
    killed = 0
    for mutant in list_of_mutants:
        killing_tests = mutant.killingTests
        if len(killing_tests.intersection(tests)) > 0:
            killed += mutant.ochiai
        else:
            survived += 1
    if survived == 0 and killed == 0:
        return "No mutants"
    else:
        return killed


def mutation_score_weighted_fdp(list_of_mutants, tests):
    survived = 0
    killed = 0
    for mutant in list_of_mutants:
        killing_tests = mutant.killingTests
        if len(killing_tests.intersection(tests)) > 0:
            killed += mutant.reviling_prob
        else:
            survived += 1
    if survived == 0 and killed == 0:
        return "No mutants"
    else:
        return killed


def split_and_sample_tests_uniformly(number_suites, number_tests_per_suite, all_tests_pool, failing_bug_tests):
    fault_detecting_suites, passing_suits = [], []

    ratio_not_okay = True
    exit_counter = 0

    while ratio_not_okay:
        exit_counter += 1
        for i in range(number_suites):
            sampled_tests = random.sample(all_tests_pool, number_tests_per_suite)
            if len(set(sampled_tests).intersection(failing_bug_tests)) > 0:
                fault_detecting_suites.append(sampled_tests)
            else:
                passing_suits.append(sampled_tests)

        if len(fault_detecting_suites) > 30 and len(passing_suits) > 30:
            ratio_not_okay = False
        else:
            fault_detecting_suites.clear()
            passing_suits.clear()

        if exit_counter == 100:
            logging.info("ERROR infinite loop: Probability does not hold")
            exit(0)

    return fault_detecting_suites, passing_suits


def split_and_sample_tests_no_force_balance(number_suites, number_tests_per_suite, all_tests_pool, failing_bug_tests):
    fault_detecting_suites, passing_suits = [], []

    for i in range(number_suites):
        sampled_tests = random.sample(all_tests_pool, number_tests_per_suite)
        if len(set(sampled_tests).intersection(failing_bug_tests)) > 0:
            fault_detecting_suites.append(sampled_tests)
        else:
            passing_suits.append(sampled_tests)

    return fault_detecting_suites, passing_suits


def sample_tests_no_force_balance(number_suites, number_tests_per_suite, all_tests_pool):
    test_suites = []

    for i in range(number_suites):
        sampled_tests = random.sample(all_tests_pool, number_tests_per_suite)
        test_suites.append(sampled_tests)

    return test_suites


if __name__ == '__main__':
    arguments = argument_parser().parse_args()

    assert os.path.exists(arguments.big_all_matrices_path), "Provide valid csv file with all tools statistics"
    assert os.path.exists(arguments.output_file_path), "Provide valid directory path to output dir"

    big_all_matrices_path, output_file_path = arguments.big_all_matrices_path, arguments.output_file_path

    logging.info("Creating output file")
    os.makedirs(os.path.join(arguments.output_file_path, "simulation_weighted"), exist_ok=True)
    simulation_data_path = os.path.join(arguments.output_file_path, "simulation_weighted",
                                        f"simulation_weighted.csv")
    logging.info(f"Output file path: {simulation_data_path}")
    logging.info("Output file created")

    simulation_data_writer = open(simulation_data_path, "a+")
    if os.stat(simulation_data_path).st_size == 0:
        simulation_data_writer.write("Project_ID,Bug_ID,Number_Of_Tests,Test_Suite_Balance,Test_Category,Number_Of_Failing_Tests,ms_fdp,ms_semantic\n")

    logging.info("Creating output file for mistakes")
    os.makedirs(os.path.join(arguments.output_file_path, "calculation_mistakes"), exist_ok=True)
    mistakes_writer_path = os.path.join(arguments.output_file_path, "calculation_mistakes",
                                        f"calculation_mistakes.csv")
    logging.info(f"Output file path: {mistakes_writer_path}")
    logging.info("Output file for mistakes")

    mistakes_writer = open(mistakes_writer_path, "a+")
    if os.stat(mistakes_writer_path).st_size == 0:
        mistakes_writer.write("Project_ID,Bug_ID,Mutant_ID,Mistakes,Hits,MSE,Ochiai,FDP\n")

    logging.info("Loading all tool data")  # load data from defects4j dataset - augmented data - warning!! many tests
    assert os.path.join(big_all_matrices_path, "big_all_matrices.csv")
    data_df = pd.read_csv(filepath_or_buffer=os.path.join(big_all_matrices_path, "big_all_matrices.csv"))

    logging.info("Data loaded")

    bugs_one_test_or_more = collections.defaultdict(list)
    counter = 0

    for index, row in data_df.iterrows():  # look trough each project
        # if row["Project_ID"] in ["Chart"]: continue
        # if row["Project_ID"] in ["Chart"] and row["Bug_ID"] not in ["17f"]: continue

        project_data_path = os.path.join(big_all_matrices_path, f"{row['Project_ID']}.{row['Bug_ID']}.big.all.Matrix.csv")  # load data from matrices
        assert os.path.exists(project_data_path), f"This path does not exist: {project_data_path}"
        project_df = pd.read_csv(filepath_or_buffer=project_data_path, index_col=None)

        project_df = project_df.drop("testType", axis=1)  # remove test type
        project_df.drop(labels=0, axis=0, inplace=True)  # remove first row of operators,
        project_df = project_df.set_index("test").T  # transpose it so that tests are indexes instead of

        failing_tests = []
        mutants = []

        for index_, row_ in project_df.iterrows():  # extract killing tests for each mutant and a failing tests for a bug
            if index_ == "bug":
                failing_tests = [e[0] for e in row_.iteritems() if int(e[1]) == 1]
            else:
                killing_tests = [e[0] for e in row_.iteritems() if int(e[1]) == 1]
                mutants.append(parse_mutant(mutant_id=index_, mutant_killing_tests=killing_tests, bug_failing_tests=failing_tests))

        failing_tests_number = len(failing_tests)
        test_pool = sample_all_killed_tests(mutants)  # take test pool from killed mutants

        # lets normalize and clean data
        if len(failing_tests) > len(test_pool) * 0.2:  # lets not consider scenario where failing tests are more than 20% of whole test suite, few instances
            logging.info("Warning: Failing tests greater than 20% of pool")
            continue
        if len(mutants) <= 50:  # lets not consider scenario with less than 50 mutants, as we are sampling 50, few instances
            logging.info("Warning: Pool of mutants less than 50")
            continue
        if len(test_pool) - len(
                failing_tests) <= 30:  # lets not consider scenario where test pool does not consider more than 30 of failing tests, since we sample 30 max
            logging.info("Warning: Pool of tests without failing tests less than 30 tests")
            continue
        # in case there is no overlapping between test pool and failing tests (no mutant killed by failing tests)
        if not set(failing_tests).issubset(test_pool):
            logging.info("Warning: Failing tests is not subset of test pool")
            continue
        if not len(set(failing_tests).intersection(test_pool)) > 0:
            logging.info("Warning: Fault intersection does not exist")
            continue

        if len(failing_tests) == 1:
            continue

        logging.info(
            f"INFO: Failing tests: {len(failing_tests)} ({len(failing_tests) / len(test_pool)}) - Test pool: {len(test_pool)} - Mutants: {len(mutants)}- Project: {row['Project_ID']} - Bug: {row['Bug_ID']}")

        # CALCULATE INTERSECTION OF MUTANTS ON TOP
        # semantic_mutants = list(mutants)
        # fdp_mutants = list(mutants)
        # print(semantic_mutants[0])
        # semantic_mutants.sort(key=lambda x: x.ochiai, reverse=True)
        # fdp_mutants.sort(key=lambda x: x.reviling_prob, reverse=True)
        # print(semantic_mutants)
        #
        # for perc in [0.01, 0.02, 0.03, 0.04, 0.05, 0.10, 0.20, 0.3]:
        #     sample_mutants = round(perc * len(mutants))
        #     print(f"Mutants: {len(mutants)} - Sampled: {sample_mutants} - Percentage: {round(perc * 100)}% ")
        #     sampled_mutants_semantic = semantic_mutants[:sample_mutants]
        #     sampled_mutants_fdp_mutants = fdp_mutants[:sample_mutants]
        #
        #     sampled_mutants_semantic_id = [m.mutant_ID for m in sampled_mutants_semantic]
        #     sampled_mutants_fdp_mutants_id = [m.mutant_ID for m in sampled_mutants_fdp_mutants]
        #     intersection = len(set(sampled_mutants_semantic_id).intersection(set(sampled_mutants_fdp_mutants_id)))
        #     print(f"Intersection: {intersection} - ({round(intersection/sample_mutants, 2)})")

        # Sort by `name` attribute, followed by `dept` attribute >> associates.sort(key=lambda x: (x.name, x.dept))

        test_suites_dict = {}
        for number_of_suites in [1000]:  # lets sample 1000 mutants
            logging.info(f"Start test sampling<<<")
            den = len(failing_tests) / len(test_pool)
            number_of_tests_to_select = round(0.5 / den)

            test_suites = sample_tests_no_force_balance(number_of_suites, number_of_tests_to_select, test_pool)

        matrix = collections.defaultdict(dict)
        bug_hit_list = [1 if len(set(T).intersection(set(failing_tests))) > 0 else 0 for T in test_suites]
        for m in mutants:
            matrix[m.mutant_ID].update({"Suites": [1 if len(set(T).intersection(set(m.killingTests))) > 0 else 0 for T in test_suites]})
            matrix[m.mutant_ID].update({"Ochiai": m.ochiai})
            matrix[m.mutant_ID].update({"FDP": m.reviling_prob})

        mistakes_scores = {}
        for mutant_name in matrix:
            mistakes = 0
            for test_suite_id, hit in enumerate(matrix[mutant_name]["Suites"]):
                if hit != bug_hit_list[test_suite_id]:
                    mistakes += 1
            hits = 1000 - mistakes
            mse = metrics.mean_squared_error(bug_hit_list, matrix[mutant_name]["Suites"])
            mistakes_writer.write(f"{row['Project_ID']},{row['Bug_ID']},{mutant_name},{mistakes},{hits},{mse},{matrix[mutant_name]['Ochiai']},{matrix[mutant_name]['FDP']}\n")
