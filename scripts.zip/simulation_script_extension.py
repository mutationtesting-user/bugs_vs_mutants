import argparse
import collections
import json
import math
import os
import random
import logging

from scipy.stats import stats

logging.basicConfig(level=logging.INFO)

import pandas as pd
import numpy as np


def argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Extract mutants info")
    parser.add_argument("-d", "--big_all_matrices_path", action="store", help="Store a file with statistics data of all tools")
    parser.add_argument("-o", "--output_file_path", action="store", help="Output file path")
    parser.add_argument("-m", "--mutants_sampled_range", action="store", help="Output file path")

    return parser


class Mutant(object):

    def __init__(self):
        self.mutant_ID = ""
        self.killingTests = frozenset()

        self.mutant_embedded_id = ""
        self.ochiai = 0.0
        self.jaccard = ""
        self.cosine = ""
        self.bleu = ""
        self.reviling_prob = 0.0

    def __ne__(self, other):
        return (not isinstance(other, type(self))
                or self.mutant_ID != other.mutant_ID)

    def __eq__(self, othr):
        return (isinstance(othr, type(self))
                and self.mutant_ID == othr.mutant_ID)

    def __hash__(self):
        return hash((self.mutant_ID, self.killingTests))


def parse_mutant(mutant_id, mutant_killing_tests, bug_failing_tests):
    m = Mutant()
    m.mutant_ID = f'M_{mutant_id}'
    m.killingTests = set(mutant_killing_tests)

    m.ochiai = get_ochia_score(brokenTestsByBug=set(bug_failing_tests), brokenTestsByMutant=set(mutant_killing_tests))
    m.reviling_prob = fault_reviling_prob(set(bug_failing_tests), set(m.killingTests))

    return m


def get_ochia_score(brokenTestsByBug: set, brokenTestsByMutant: set):
    assert brokenTestsByBug != None and len(brokenTestsByBug) != 0
    if brokenTestsByMutant == None or len(brokenTestsByMutant) == 0: return 0;
    intersectionSet = brokenTestsByBug.intersection(brokenTestsByMutant)
    prod = len(brokenTestsByBug) * len(brokenTestsByMutant)
    if prod == 0 or len(intersectionSet) == 0: return 0
    return len(intersectionSet) / np.sqrt(prod)


def fault_reviling_prob(brokenTestsByBug: set, brokenTestsByMutant: set):
    assert brokenTestsByBug != None and len(brokenTestsByBug) != 0
    if brokenTestsByMutant == None or len(brokenTestsByMutant) == 0: return 0.0;
    intersectionSet = brokenTestsByBug.intersection(brokenTestsByMutant)
    prod = len(brokenTestsByMutant)
    if prod == 0 or len(intersectionSet) == 0: return 0.0
    return len(intersectionSet) / prod


def sample_all_killed_tests(mutants):
    set_of_tests = set()
    for mutant in mutants:
        for test in mutant.killingTests:
            set_of_tests.add(test)
    return set_of_tests


def load_failing_tests_for_bug(project_df):
    # failing_tests_ground_truth = pd.read_csv(
    #     filepath_or_buffer=os.path.join(path_to_failing_tests_dir, f'{str(project_).lower()}_bugs_failing_tests.csv'),
    #     names=["BUG_ID", "FAILING_TESTS"], header=None)
    # failing_tests_ = failing_tests_ground_truth.loc[failing_tests_ground_truth["BUG_ID"] == int(bug_[:-1]), 'FAILING_TESTS'].values[0].split(";")
    return list()


def aggregate_semantic(mutants, agg):
    values = []
    for mutant in mutants:
        values.append(mutant.ochiai)
    if agg == "average":
        return np.mean(values)
    elif agg == "max":
        return np.max(values)
    else:
        return np.median(values)


def aggregate_rev_prob(mutants, agg):
    values = []
    for mutant in mutants:
        values.append(mutant.reviling_prob)
    if agg == "average":
        return np.mean(values)
    elif agg == "max":
        return np.max(values)
    else:
        return np.median(values)


def sample_and_sort_mutants(mutants_pool, range_to_sample):
    sampled_mutants_dict_sem = []
    sampled_mutants_dict_rev_prob = []
    sampled_mutants_dict_rev_prob_max = []
    for i in range(1000):
        mutants = random.sample(mutants_pool, range_to_sample)
        # print([m.mutant_ID for m in mutants])
        # print([m.ochiai for m in mutants])
        sampled_mutants_dict_sem.append({"score": aggregate_semantic(mutants, "average"), "mutants": mutants})
        sampled_mutants_dict_rev_prob.append({"score": aggregate_rev_prob(mutants, "average"), "mutants": mutants})
        sampled_mutants_dict_rev_prob_max.append({"score": aggregate_rev_prob(mutants, "max"), "mutants": mutants})

    sampled_mutants_dict_sem.sort(key=lambda k: k['score'])
    sampled_mutants_dict_rev_prob.sort(key=lambda k: k['score'])
    sampled_mutants_dict_rev_prob_max.sort(key=lambda k: k['score'])
    return sampled_mutants_dict_sem, sampled_mutants_dict_rev_prob, sampled_mutants_dict_rev_prob_max


def split_mutants_into_backets(sampled_mutants_dict_sem_sim, sampled_mutants_dict_fault_rev_prob, sampled_mutants_dict_fault_rev_prob_max):
    sem_mutants_buckets = {}
    # sem_mutants_buckets.update({"Q1": [element["mutants"] for element in sampled_mutants_dict_sem_sim[:250]]})
    # sem_mutants_buckets.update({"Q2": [element["mutants"] for element in sampled_mutants_dict_sem_sim[250:500]]})
    # sem_mutants_buckets.update({"Q3": [element["mutants"] for element in sampled_mutants_dict_sem_sim[500:750]]})
    # sem_mutants_buckets.update({"Q4": [element["mutants"] for element in sampled_mutants_dict_sem_sim[750:1000]]})
    sem_mutants_buckets.update({"EXTREME": [element["mutants"] for element in sampled_mutants_dict_sem_sim[900:1000]]})
    sem_mutants_buckets.update({"EXTREME_5": [element["mutants"] for element in sampled_mutants_dict_sem_sim[950:1000]]})

    rev_prob_mutants_buckets = {}
    # rev_prob_mutants_buckets.update({"Q1": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob[:250]]})
    # rev_prob_mutants_buckets.update({"Q2": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob[250:500]]})
    # rev_prob_mutants_buckets.update({"Q3": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob[500:750]]})
    # rev_prob_mutants_buckets.update({"Q4": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob[750:1000]]})
    rev_prob_mutants_buckets.update({"EXTREME": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob[900:1000]]})
    rev_prob_mutants_buckets.update({"EXTREME_5": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob[950:1000]]})

    rev_prob_mutants_buckets_max = {}
    # rev_prob_mutants_buckets_max.update({"Q1": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob_max[:250]]})
    # rev_prob_mutants_buckets_max.update({"Q2": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob_max[250:500]]})
    # rev_prob_mutants_buckets_max.update({"Q3": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob_max[500:750]]})
    # rev_prob_mutants_buckets_max.update({"Q4": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob_max[750:1000]]})
    rev_prob_mutants_buckets_max.update({"EXTREME": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob_max[900:1000]]})
    rev_prob_mutants_buckets_max.update({"EXTREME_5": [element["mutants"] for element in sampled_mutants_dict_fault_rev_prob_max[950:1000]]})

    return sem_mutants_buckets, rev_prob_mutants_buckets, rev_prob_mutants_buckets_max


def mutation_score_with_tests(list_of_mutants, tests):
    survived = 0
    killed = 0
    for mutant in list_of_mutants:
        killing_tests = mutant.killingTests
        if len(killing_tests.intersection(tests)) > 0:
            killed += 1
        else:
            survived += 1
    if survived == 0 and killed == 0:
        return "No mutants"
    else:
        return round(killed / (survived + killed) * 100, 2)


def split_and_sample_tests_uniformly(number_suites, number_tests_per_suite, all_tests_pool, failing_bug_tests):
    fault_detecting_suites, passing_suits = [], []

    ratio_not_okay = True
    exit_counter = 0

    while ratio_not_okay:
        exit_counter += 1
        for i in range(number_suites):
            sampled_tests = random.sample(all_tests_pool, number_tests_per_suite)
            if len(set(sampled_tests).intersection(failing_bug_tests)) > 0:
                fault_detecting_suites.append(sampled_tests)
            else:
                passing_suits.append(sampled_tests)

        if len(fault_detecting_suites) > 30 and len(passing_suits) > 30:
            ratio_not_okay = False
        else:
            fault_detecting_suites.clear()
            passing_suits.clear()

        if exit_counter == 100:
            logging.info("ERROR infinite loop: Probability does not hold")
            exit(0)

    return fault_detecting_suites, passing_suits


def split_and_sample_tests_no_force_balance(number_suites, number_tests_per_suite, all_tests_pool, failing_bug_tests):
    fault_detecting_suites, passing_suits = [], []

    for i in range(number_suites):
        sampled_tests = random.sample(all_tests_pool, number_tests_per_suite)
        if len(set(sampled_tests).intersection(failing_bug_tests)) > 0:
            fault_detecting_suites.append(sampled_tests)
        else:
            passing_suits.append(sampled_tests)

    return fault_detecting_suites, passing_suits


def split_and_sample_tests(number_suites, number_tests_per_suite, all_tests_pool, failing_bug_tests):
    fault_detecting_suites, passing_suits = [], []
    failing_bug_tests = set(failing_bug_tests)
    # to_sample = number_tests_per_suite + len(failing_bug_tests)
    to_sample = number_tests_per_suite * 5  # number of tests to big for random sampling, lets reduce it to 10 times the size of sum of failing tests and number of tests per suite
    all_tests_no_failing = all_tests_pool - failing_bug_tests
    if to_sample >= len(all_tests_no_failing) * 0.5:
        to_sample = len(all_tests_no_failing)

    # lets loop until we sample wanted number of test sets
    while len(fault_detecting_suites) < number_suites:
        sample_less = random.sample(all_tests_no_failing, to_sample)
        sample_less = set.union(set(sample_less), failing_bug_tests)
        sampled_tests = random.sample(sample_less, number_tests_per_suite)
        if len(set(sampled_tests).intersection(failing_bug_tests)) > 0:
            fault_detecting_suites.append(sampled_tests)

    while len(passing_suits) < number_suites:
        sampled_tests = random.sample(all_tests_no_failing, number_tests_per_suite)
        if len(set(sampled_tests).intersection(failing_bug_tests)) == 0:
            passing_suits.append(sampled_tests)

    passing_suits = passing_suits[:number_suites]  # should I cut or randomly select? I think it is the same at the end
    fault_detecting_suites = fault_detecting_suites[:number_suites]  # should I cut or randomly select? I think it is the same at the end
    return fault_detecting_suites, passing_suits


def write_stats():
    project_name = row['Project_ID']
    bug_name = row['Bug_ID']
    number_of_mutants = len(mutants)
    number_of_mutants_ochiai_gt_zero = len([m for m in mutants if m.ochiai > 0])
    number_of_mutants_fdp_gt_zero = len([m for m in mutants if m.reviling_prob > 0])
    number_of_mutants_ochiai_one = len([m for m in mutants if m.ochiai == 1])
    number_of_mutants_fdp_one = len([m for m in mutants if m.reviling_prob == 1])
    number_of_failing_tests = len(failing_tests)
    number_of_tests_in_pool = len(test_pool)

    number_of_mutants_fdp_gt_ochia = len([m for m in mutants if m.reviling_prob > m.ochiai])
    number_of_mutants_fdp_equals_ochia = len([m for m in mutants if m.reviling_prob == m.ochiai and m.reviling_prob > 0])

    logging.info(f"{project_name},{bug_name},{number_of_mutants},{number_of_mutants_ochiai_gt_zero},{number_of_mutants_fdp_gt_zero},"
                 f"{number_of_mutants_ochiai_one},{number_of_mutants_fdp_one},{number_of_failing_tests},{number_of_tests_in_pool},"
                 f"{number_of_mutants_fdp_gt_ochia},{number_of_mutants_fdp_equals_ochia}\n")

    mutants_writer.write(f"{project_name},{bug_name},{number_of_mutants},{number_of_mutants_ochiai_gt_zero},{number_of_mutants_fdp_gt_zero},"
                         f"{number_of_mutants_ochiai_one},{number_of_mutants_fdp_one},{number_of_failing_tests},{number_of_tests_in_pool},"
                         f"{number_of_mutants_fdp_gt_ochia},{number_of_mutants_fdp_equals_ochia}\n")

    list_ochiai = [m.ochiai for m in mutants if m.ochiai > 0]
    list_fdp = [m.reviling_prob for m in mutants if m.reviling_prob > 0]

    assert len(list_ochiai) == len(list_fdp), "ERROR: Problem with lengths"

    # pearson_corr, pearson_p = stats.pearsonr(ms_scores, detection_scores)
    kendall_corr, kendall_p = stats.kendalltau(list_ochiai, list_fdp)

    metrics_correlation_writer.write(f"{project_name},{bug_name},{kendall_corr},{kendall_p}\n")

    for m in mutants:
        if m.ochiai > 0:
            mutants_values_writer.write(f"{project_name},{bug_name},{m.mutant_ID},{m.ochiai},{m.reviling_prob}\n")

    logging.info(
        f"INFO: Failing tests: {len(failing_tests)} ({len(failing_tests) / len(test_pool)}) - Test pool: {len(test_pool)} - Mutants: {len(mutants)}- Project: {row['Project_ID']} - Bug: {row['Bug_ID']}")


if __name__ == '__main__':
    arguments = argument_parser().parse_args()

    assert os.path.exists(arguments.big_all_matrices_path), "Provide valid csv file with all tools statistics"
    assert os.path.exists(arguments.output_file_path), "Provide valid directory path to output dir"

    big_all_matrices_path, output_file_path = arguments.big_all_matrices_path, arguments.output_file_path

    logging.info("Creating output file for simulation log")
    os.makedirs(os.path.join(arguments.output_file_path, "simulation_extension_final_percentages"), exist_ok=True)
    simulation_data_path = os.path.join(arguments.output_file_path, "simulation_extension_final_percentages",
                                        f"simulation_data_extension_{arguments.mutants_sampled_range}.csv")
    logging.info(f"Output file for simulation log: {simulation_data_path}")

    simulation_data_writer = open(simulation_data_path, "a+")
    if os.stat(simulation_data_path).st_size == 0:
        simulation_data_writer.write("Project_ID,Bug_ID,Bucket,Number_Of_Tests,Test_Suite_Balance,Test_Category,Number_Of_Failing_Tests,Group,MS\n")

    logging.info("Creating output file for statistics between metrics")
    os.makedirs(os.path.join(arguments.output_file_path), exist_ok=True)
    mutants_path = os.path.join(arguments.output_file_path, "mutants_statistics_diff_fdp_ochiai.csv")
    logging.info(f"Output file for statistics between metrics: {mutants_path}")

    mutants_writer = open(mutants_path, "a+")
    if os.stat(mutants_path).st_size == 0:
        mutants_writer.write("project_name,bug_name,number_of_mutants,number_of_mutants_ochiai_gt_zero,number_of_mutants_fdp_gt_zero,"
                             "number_of_mutants_ochiai_one,number_of_mutants_fdp_one,"
                             "number_of_failing_tests,number_of_tests_in_pool,number_of_mutants_fdp_gt_ochia,number_of_mutants_fdp_equals_ochia\n")

    logging.info("Creating output file for correlation between metrics per bug")
    metrics_correlation_path = os.path.join(arguments.output_file_path, "metrics_correlation.csv")
    logging.info(f"Output file for correlation between metrics per bug: {metrics_correlation_path}")

    metrics_correlation_writer = open(metrics_correlation_path, "a+")
    if os.stat(metrics_correlation_path).st_size == 0:
        metrics_correlation_writer.write("project_name,bug_name,kendall,kendall_p\n")

    logging.info("Creating output file for mutants scores")
    mutants_values_path = os.path.join(arguments.output_file_path, "mutants_values.csv")
    logging.info(f"Output file for mutants scores: {mutants_values_path}")

    mutants_values_writer = open(mutants_values_path, "a+")
    if os.stat(mutants_values_path).st_size == 0:
        mutants_values_writer.write("project_name,bug_name,mutant,ochiai,FDP\n")

    logging.info("Loading all tool data")  # load data from defects4j dataset - augmented data - warning!! many tests
    assert os.path.join(big_all_matrices_path, "big_all_matrices.csv")
    data_df = pd.read_csv(filepath_or_buffer=os.path.join(big_all_matrices_path, "big_all_matrices.csv"))

    logging.info("Data loaded")

    bugs_one_test_or_more = collections.defaultdict(list)
    counter = 0

    for index, row in data_df.iterrows():  # look trough each project
        # if row["Project_ID"] in ["Chart"]: continue
        # if row["Project_ID"] in ["Chart"] and row["Bug_ID"] not in ["17f"]: continue

        project_data_path = os.path.join(big_all_matrices_path, f"{row['Project_ID']}.{row['Bug_ID']}.big.all.Matrix.csv")  # load data from matrices
        assert os.path.exists(project_data_path), f"This path does not exist: {project_data_path}"
        project_df = pd.read_csv(filepath_or_buffer=project_data_path, index_col=None)

        project_df = project_df.drop("testType", axis=1)  # remove test type
        project_df.drop(labels=0, axis=0, inplace=True)  # remove first row of operators,
        project_df = project_df.set_index("test").T  # transpose it so that tests are indexes instead of

        failing_tests = []
        mutants = []

        for index_, row_ in project_df.iterrows():  # extract killing tests for each mutant and a failing tests for a bug
            if index_ == "bug":
                failing_tests = [e[0] for e in row_.iteritems() if int(e[1]) == 1]
            else:
                killing_tests = [e[0] for e in row_.iteritems() if int(e[1]) == 1]
                mutants.append(parse_mutant(mutant_id=index_, mutant_killing_tests=killing_tests, bug_failing_tests=failing_tests))

        failing_tests_number = len(failing_tests)
        test_pool = sample_all_killed_tests(mutants)  # take test pool from killed mutants

        # lets normalize and clean data
        if len(failing_tests) > len(test_pool) * 0.2:  # lets not consider scenario where failing tests are more than 20% of whole test suite, few instances
            logging.info("Warning: Failing tests greater than 20% of pool")
            continue
        if len(mutants) <= 50:  # lets not consider scenario with less than 50 mutants, as we are sampling 50, few instances
            logging.info("Warning: Pool of mutants less than 50")
            continue
        if len(test_pool) - len(
                failing_tests) <= 30:  # lets not consider scenario where test pool does not consider more than 30 of failing tests, since we sample 30 max
            logging.info("Warning: Pool of tests without failing tests less than 30 tests")
            continue
        # in case there is no overlapping between test pool and failing tests (no mutant killed by failing tests)
        if not set(failing_tests).issubset(test_pool):
            logging.info("Warning: Failing tests is not subset of test pool")
            continue
        if not len(set(failing_tests).intersection(test_pool)) > 0:
            logging.info("Warning: Fault intersection does not exist")
            continue

        # write_stats() # write statistics about number of mutants and additional correlations

        logging.info(f"INFO: Failing tests: {len(failing_tests)} Test pool: {len(test_pool)} - Percentage: {len(failing_tests)/len(test_pool)}")
        logging.info(f"INFO: Failing tests: {len(failing_tests)} - Test pool: {len(test_pool)} - Project: {row['Project_ID']} - Bug: {row['Bug_ID']}")

        # for sampled_range in [10, 20, 30, 50]: # run it in grid, parameterized for the reason of jobs and faster execution
        for sampled_range in [int(arguments.mutants_sampled_range)]:
            logging.info(f"Sample mutant range: {sampled_range}")

            # lets sample and sort mutants based on different falues
            sampled_mutants_dict_sem_sim, sampled_mutants_dict_fault_rev_prob, sampled_mutants_dict_fault_rev_prob_max = sample_and_sort_mutants(
                mutants, sampled_range)
            logging.info(f"Sample mutant done<<<")

            # lets split mutants into buckets
            mutants_buckets_semantic_sim, mutants_buckets_fault_reviling, mutants_buckets_fault_reviling_max = split_mutants_into_backets(
                sampled_mutants_dict_sem_sim,
                sampled_mutants_dict_fault_rev_prob,
                sampled_mutants_dict_fault_rev_prob_max)
            logging.info(f"Splitting mutants done<<<")

            test_suites_dict = {}
            for number_of_suites in [100]:  # how many test suites should we have per category, lets have 50 for computational and size reasons
                logging.info(f"Start test sampling<<<")
                for number_of_tests in [0.01, 0.02, 0.03, 0.04, 0.05]:  # increase size of test suite from 2-20 to 5-30, since test suite is augmented
                    number_of_tests_to_select = round(number_of_tests * len(test_pool))
                    if number_of_tests_to_select <= 1:
                        number_of_tests_to_select = 2
                    # den = len(failing_tests) / len(test_pool) # take into consideration balanced probability
                    # number_of_tests_to_select = round(0.5 / den)

                    fault_detecting_test_suites, passing_test_suits = split_and_sample_tests_no_force_balance(number_of_suites, number_of_tests_to_select, test_pool,
                                                                                                       failing_tests)
                    # update test suite dict with tuple of failing and passing
                    test_suites_dict.update({number_of_tests: [("failing", fault_detecting_test_suites), ("passing", passing_test_suits)]})
            logging.info(f"Test sampling DONE<<<")

            logging.info(f"Start executing<<<")
            for group_name, backet_data in [("semantic", mutants_buckets_semantic_sim), ("fault_prob", mutants_buckets_fault_reviling),
                                            ("fault_prob_max", mutants_buckets_fault_reviling_max)]:
                logging.info(f"Group {group_name}<<<")  # we need to execute per each group

                for backet_name, backet_mutants in backet_data.items():  # each group has buckets, so we need to execute per buckets
                    logging.info(f"Backet {backet_name}<<<")

                    for mutant_set_id, mutant_set in enumerate(backet_mutants):  # each buckets, many mutants, so we need to evaluate each mutant

                        for number_of_tests, tests_categories in test_suites_dict.items():  # on each mutant, we execute different sizes of test suites
                            for test_category, test_suites in tests_categories:  # each size has failing and passing test suite

                                # assert len(test_suites) != 0, "Test suite is not non empty, something is wrong"
                                # assert len(test_suites) == 100, "Set of test suites is not 50, something is wrong man"
                                if mutant_set_id % 20 == 0:  # log on each 100 mutant
                                    logging.info(
                                        "P: {0}-{1} - B: {2} - Group: {3} - Bucket: {4} - Category: {5} - Set: - {6} - Suite: {7} - Tests: {8}".format(
                                            index,
                                            row['Project_ID'],
                                            row['Bug_ID'],
                                            group_name,
                                            backet_name,
                                            test_category,
                                            mutant_set_id,
                                            len(test_suites),
                                            number_of_tests,
                                        ))

                                for test_suite in test_suites:  # each test category has 50 test suites
                                    ms = mutation_score_with_tests(mutant_set, test_suite)  # calculate mutation score
                                    # write to the file
                                    simulation_data_writer.write(
                                        '{Project_ID},{Bug_ID},{Bucket},{Number_Of_Tests},{Test_Suite_Balance},{Test_Category},{Number_Of_Failing_Tests},'
                                        '{Group},{MS}\n'.format(
                                            Project_ID=row['Project_ID'],
                                            Bug_ID=row['Bug_ID'],
                                            Bucket=backet_name,
                                            Number_Of_Tests=number_of_tests,
                                            Test_Suite_Balance=len(test_suites),
                                            Test_Category=test_category,
                                            Number_Of_Failing_Tests=failing_tests_number,
                                            Group=group_name,
                                            MS=ms))
