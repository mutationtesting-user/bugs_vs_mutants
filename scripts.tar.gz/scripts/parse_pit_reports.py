import pandas as pd
import argparse
import os
import xml.etree.ElementTree as ET
import shutil
import collections
import json
import pandas
import numpy as np


class Mutant(object):

    def __init__(self, mutant_id, class_name, source_file, line_number, index, block, mutant_operator, mutated_method, method_description):
        self.class_name = class_name
        self.sourceFile = source_file
        self.lineNumber = line_number
        self.index = index
        self.block = block
        self.mutant_operator = mutant_operator
        self.mutatedMethod = mutated_method
        self.methodDescription = method_description
        self.killingTests = frozenset()
        self.succidingTests = frozenset()
        self.in_changed_method = 0
        self.mutant_ID = mutant_id

    def hard_to_kill_score(self) -> float:
        if len(self.killingTests) == 0:
            return 1
        return len(self.killingTests) / (len(self.killingTests) + len(self.succidingTests))

    def to_string(self) -> str:
        return "{} , {} , {} , {} , {} , {} , {}".format(
            self.class_name,
            self.lineNumber,
            self.index,
            self.block,
            self.mutant_operator,
            self.mutatedMethod,
            self.methodDescription)

    def __ne__(self, other):
        return (not isinstance(other, type(self))
                or (self.class_name) != (other.class_name)
                or (self.lineNumber) != (other.lineNumber)
                or (self.index) != (other.index)
                or (self.block) != (other.block)
                or (self.mutant_operator) != (other.mutant_operator)
                or (self.mutatedMethod) != (other.mutatedMethod)
                or (self.methodDescription) != (other.methodDescription))

    def __eq__(self, othr):
        return (isinstance(othr, type(self))
                and (self.class_name) == (othr.class_name)
                and (self.lineNumber) == (othr.lineNumber)
                and (self.index) == (othr.index)
                and (self.block) == (othr.block)
                and (self.mutant_operator) == (othr.mutant_operator)
                and (self.mutatedMethod) == (othr.mutatedMethod)
                and (self.methodDescription) == (othr.methodDescription))

    def __hash__(self):
        return hash((self.class_name, self.lineNumber, self.index, self.block, self.mutant_operator, self.mutatedMethod, self.methodDescription))


def argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Extract mutants info")
    parser.add_argument("-b", "--project_faults_map_file", action="store", help="Store file path")
    parser.add_argument("-p", "--path_to_reports_dir", action="store", help="Store directory path")
    parser.add_argument("-m", "--path_to_changed_methods_map_file", action="store", help="Store file path")
    parser.add_argument("-e", "--path_to_experiment_bugs_to_find_changed_methods", action="store", help="Store file path to experiment bugs")
    parser.add_argument("-d", "--path_to_defects4j_projects", action="store",
                        help="Store directory path for defects4j projects")

    return parser


def get_path_4_bug_modified_classes(data_frame_row, path_to_defects4j_projects):
    bug_modified_classes_path = os.path.join(path_to_defects4j_projects, data_frame_row[1][1], "modified_classes", f'{(data_frame_row[1][2])[:-1]}.src')
    print(bug_modified_classes_path)
    assert os.path.exists(bug_modified_classes_path), f"Path does not exists {bug_modified_classes_path}"
    return bug_modified_classes_path


def load_mutants(report_file):
    tree = ET.parse(report_file)
    root = tree.getroot()
    counter_ID = 1
    mutants_list = list()
    for mutant in root.findall('mutation'):
        source_file = mutant.find("sourceFile").text
        mutated_class = mutant.find("mutatedClass").text
        mutatedMethod = mutant.find("mutatedMethod").text
        lineNumber = mutant.find("lineNumber").text
        index = mutant.find("index").text
        block = mutant.find("block").text
        operator = mutant.find("mutator").text
        methodDescription = mutant.find("methodDescription").text

        succeeding_tests = mutant.find("succeedingTests").text
        succeeding_tests = succeeding_tests.split("|") if succeeding_tests is not None else []
        killing_tests = mutant.find("killingTests").text
        killing_tests = killing_tests.split("|") if killing_tests is not None else []
        m = Mutant(counter_ID, mutated_class, source_file, lineNumber, index, block, operator, mutatedMethod, methodDescription)
        m.killingTests = frozenset(killing_tests)
        m.succidingTests = frozenset(succeeding_tests)
        mutants_list.append(m)
        counter_ID += 1
    return mutants_list


def ouput_mutants_per_modified_classes(mutants, bug_modified_files, output_path):
    for clazz in bug_modified_files:
        mutants_info_dict = []
        mutants_killing_dict = []
        all_tests = set()
        for mutant in mutants:
            if mutant.sourceFile[:-5] in clazz: # remove .java extension from source file
                mutants_info_dict.append({"Mutant_ID": mutant.mutant_ID, "Source_file": mutant.sourceFile,
                                          "Class_name": mutant.class_name, "Method_name": mutant.mutatedMethod,
                                          "Line_number": mutant.lineNumber, "Method_description": mutant.methodDescription,
                                          "Index": mutant.index, "Block": mutant.block,
                                          "Operator": mutant.mutant_operator})
                mutants_killing_dict.append({"Mutant_ID": mutant.mutant_ID, "Killing_tests": "None" if len(mutant.killingTests) == 0 else ",".join(mutant.killingTests)})
                all_tests.update(set(mutant.killingTests))
                all_tests.update(set(mutant.succidingTests))

        clazz_mutants_file = open(os.path.join(output_path, f'{clazz}_mutants.json'), "w")
        json.dump(mutants_info_dict, clazz_mutants_file)
        clazz_mutants_file.close()
        df = pandas.DataFrame(mutants_killing_dict, columns=["Mutant_ID", "Killing_tests"])
        # df = df.replace(None, "None", regex=True)
        df.to_csv(os.path.join(output_path, f'{clazz}_killing_tests.csv'), header=True, index=False)
        open(os.path.join(output_path, f'{clazz}_covering_tests.txt'), 'w').write('\n'.join(all_tests))


def ouput_mutants_per_modified_methods(mutants, modified_class, output_dir, changed_methods_lines):
    mutants_info_dict = []
    mutants_killing_dict = []
    all_tests = set()
    for mutant in mutants:
        if mutant.sourceFile[:-5] == modified_class.split(".")[-1] and any([int(element[1]) <= int(mutant.lineNumber) <= int(element[2]) and element[0] == mutant.mutatedMethod for element in changed_methods_lines]):  # remove .java extension from source file
            mutants_info_dict.append({"Mutant_ID": mutant.mutant_ID, "Source_file": mutant.sourceFile,
                                      "Class_name": mutant.class_name, "Method_name": mutant.mutatedMethod,
                                      "Line_number": mutant.lineNumber, "Method_description": mutant.methodDescription,
                                      "Index": mutant.index, "Block": mutant.block,
                                      "Operator": mutant.mutant_operator})
            mutants_killing_dict.append(
                {"Mutant_ID": mutant.mutant_ID, "Killing_tests": "None" if len(mutant.killingTests) == 0 else ",".join(mutant.killingTests)})
            all_tests.update(set(mutant.killingTests))
            all_tests.update(set(mutant.succidingTests))

    if len(mutants_info_dict) != 0:
        clazz_mutants_file = open(os.path.join(output_dir, f'{modified_class}_changed_methods_m.json'), "w")
        json.dump(mutants_info_dict, clazz_mutants_file)
        clazz_mutants_file.close()
        df = pandas.DataFrame(mutants_killing_dict, columns=["Mutant_ID", "Killing_tests"])
        # df = df.replace(None, "None", regex=True)
        df.to_csv(os.path.join(output_dir, f'{modified_class}_changed_methods_killing_tests.csv'), header=True, index=False)
        open(os.path.join(output_dir, f'{modified_class}_changed_methods_covering_tests.txt'), 'w').write('\n'.join(all_tests))
        print("Mutants per method: ", len(mutants_info_dict))


if __name__ == '__main__':
    arguments = argument_parser().parse_args()
    assert os.path.exists(arguments.project_faults_map_file), "Provide valid csv file, with columns: PROJECT_GIT_NAME,PROJECT_DEFECTS4J_NAME,BUG_ID"
    assert os.path.exists(arguments.path_to_defects4j_projects), "Provide valid path to defects4j projects directory"
    assert os.path.exists(arguments.path_to_reports_dir), "Provide valid path to Pitest reports directory"
    assert os.path.exists(arguments.path_to_changed_methods_map_file), "Provide valid csv file, with columns: BUG_ID, file, CHANGED_METHODS"

    data = pd.read_csv(filepath_or_buffer=arguments.project_faults_map_file)
    changed_methods_data = pd.read_csv(filepath_or_buffer=arguments.path_to_changed_methods_map_file)

    for row in data.iterrows():
        print(f"{row[0]} - Project git name: {row[1][0]} | Project defects4j name: {row[1][1]} | Bug id: {row[1][2]}")
        output_dir = os.path.join(arguments.path_to_defects4j_projects, "parsed_pit_mutants", f'{row[1][1]}_{(row[1][2])[:-1]}')
        os.makedirs(output_dir, exist_ok=True)
        print(output_dir)
        bug_modified_classes = open(get_path_4_bug_modified_classes(row, arguments.path_to_defects4j_projects)).read().splitlines()
        print(bug_modified_classes)
        pit_report_file = os.path.join(arguments.path_to_reports_dir, row[1][0], f'{row[1][2]}-dev-pitReports', 'mutations.xml')
        assert os.path.exists(pit_report_file), f"Path to report does not exists {pit_report_file}"
        print(pit_report_file)

        mutants = load_mutants(pit_report_file)
        # ouput_mutants_per_modified_classes(mutants, bug_modified_classes, output_dir)

        changed_methods_df = changed_methods_data[changed_methods_data["BUG_ID"] == f'{row[1][1]}_{(row[1][2])[:-1]}']
        if changed_methods_df.empty:
            continue
        # changed_methods = changed_methods_df["METHOD"].unique().tolist()
        bug_changed_methods_rows = changed_methods_df.to_dict(orient="index")

        print(f'{row[1][1]}_{(row[1][2])[:-1]}')
        for modified_class in bug_modified_classes:
            changed_methods_lines = []
            for row_index in bug_changed_methods_rows:
                changed_method_name = bug_changed_methods_rows[row_index]["METHOD"].split("(")[0]
                changed_method_name_start_line = bug_changed_methods_rows[row_index]["START_LINE_NUMBER"]
                changed_method_name_end_line = bug_changed_methods_rows[row_index]["END_LINE_NUMBER"]
                changed_methods_lines.append((changed_method_name, changed_method_name_start_line, changed_method_name_end_line))
            ouput_mutants_per_modified_methods(mutants, modified_class, output_dir, changed_methods_lines)